<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-11 16:02:09 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-11 16:02:09 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:09 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:09 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:09 --> No URI present. Default controller set.
DEBUG - 2014-07-11 16:02:09 --> No URI present. Default controller set.
DEBUG - 2014-07-11 16:02:09 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:09 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:09 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:10 --> Database Driver Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-07-11 16:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:10 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:10 --> A session cookie was not found.
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:10 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:10 --> A session cookie was not found.
DEBUG - 2014-07-11 16:02:10 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:02:10 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:02:10 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:10 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:10 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:10 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:10 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:10 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:10 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:10 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:11 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:11 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:11 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:11 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:11 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:11 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:11 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:11 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:11 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:11 --> Total execution time: 0.1530
DEBUG - 2014-07-11 16:02:14 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:14 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:14 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:14 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:14 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:14 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:14 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:14 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:02:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:15 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:15 --> No URI present. Default controller set.
DEBUG - 2014-07-11 16:02:15 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:15 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:15 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:15 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:15 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:15 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:15 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:15 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:15 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:15 --> Total execution time: 0.5070
DEBUG - 2014-07-11 16:02:22 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:22 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:22 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:22 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:22 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:22 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:22 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:22 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:22 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:22 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:22 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:22 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:02:22 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:02:22 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:22 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:22 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:22 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:22 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:22 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:22 --> Total execution time: 0.3210
DEBUG - 2014-07-11 16:02:24 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:24 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:24 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:24 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:24 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:24 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:25 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:25 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:25 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:25 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:25 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:02:25 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:02:25 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:25 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:25 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:25 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:25 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:25 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:25 --> Total execution time: 0.4960
DEBUG - 2014-07-11 16:02:28 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:28 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:28 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:28 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:28 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:28 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:28 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:28 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:02:28 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:02:28 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:28 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:28 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:28 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:28 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:28 --> Total execution time: 0.1990
DEBUG - 2014-07-11 16:02:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:30 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:30 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:30 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:30 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:30 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:02:30 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:02:30 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:30 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:30 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:30 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:30 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:30 --> Total execution time: 0.2480
DEBUG - 2014-07-11 16:02:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:02:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:02:32 --> URI Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Router Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Output Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Security Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Input Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:02:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Loader Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:02:32 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:02:32 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:02:32 --> Session Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:02:32 --> Session routines successfully run
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Controller Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:02:32 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:02:32 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:02:33 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:02:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:02:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:02:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:02:33 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:02:33 --> Final output sent to browser
DEBUG - 2014-07-11 16:02:33 --> Total execution time: 0.2130
DEBUG - 2014-07-11 16:03:01 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:01 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:01 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:01 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:01 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:01 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:01 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:01 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:01 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:01 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:01 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:02 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:02 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:02 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:02 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:02 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:02 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:02 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:02 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:02 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:02 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:03:02 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:03:02 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:03:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:03:02 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:03:02 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:03:02 --> Final output sent to browser
DEBUG - 2014-07-11 16:03:02 --> Total execution time: 0.3600
DEBUG - 2014-07-11 16:03:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:07 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:07 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:07 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:07 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:07 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:07 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:07 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:07 --> Form Validation Class Initialized
ERROR - 2014-07-11 16:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 126
ERROR - 2014-07-11 16:03:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 126
DEBUG - 2014-07-11 16:03:07 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-07-11 16:03:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:03:08 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:03:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:03:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:03:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:03:08 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:03:08 --> Final output sent to browser
DEBUG - 2014-07-11 16:03:08 --> Total execution time: 0.4010
DEBUG - 2014-07-11 16:03:26 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:26 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:26 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:26 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:26 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:26 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:26 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:26 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:26 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:26 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:27 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:27 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:27 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:27 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:27 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:27 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:27 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:27 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:03:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:03:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:03:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:03:27 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:03:27 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:03:27 --> Final output sent to browser
DEBUG - 2014-07-11 16:03:27 --> Total execution time: 0.5490
DEBUG - 2014-07-11 16:03:38 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:38 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:38 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:38 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:38 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:38 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:38 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:38 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:38 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:38 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:38 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:38 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:38 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:38 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:03:38 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:03:38 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:03:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:03:38 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:03:38 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:03:38 --> Final output sent to browser
DEBUG - 2014-07-11 16:03:38 --> Total execution time: 0.2090
DEBUG - 2014-07-11 16:03:49 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:03:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:03:49 --> URI Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Router Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Output Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Security Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Input Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:03:49 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Language Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Config Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Loader Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:03:49 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:03:49 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:03:49 --> Session Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:03:49 --> Session routines successfully run
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Controller Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:03:49 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:03:49 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:03:49 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:03:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:03:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:03:49 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:03:49 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:03:49 --> Final output sent to browser
DEBUG - 2014-07-11 16:03:49 --> Total execution time: 0.2470
DEBUG - 2014-07-11 16:04:05 --> Config Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:04:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:04:05 --> URI Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Router Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Output Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Security Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Input Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:04:05 --> Language Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Language Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Config Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Loader Class Initialized
DEBUG - 2014-07-11 16:04:05 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:04:05 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:04:05 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:04:06 --> Session Class Initialized
DEBUG - 2014-07-11 16:04:06 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:04:06 --> Session routines successfully run
DEBUG - 2014-07-11 16:04:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:04:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:04:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:04:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:06 --> Controller Class Initialized
DEBUG - 2014-07-11 16:04:06 --> Inventory MX_Controller Initialized
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:04:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:04:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:04:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:04:06 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:04:06 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:04:06 --> Final output sent to browser
DEBUG - 2014-07-11 16:04:06 --> Total execution time: 0.1790
DEBUG - 2014-07-11 16:04:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:04:07 --> URI Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Router Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Output Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Security Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Input Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:04:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Loader Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:04:07 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:04:07 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:04:07 --> Session Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:04:07 --> Session routines successfully run
DEBUG - 2014-07-11 16:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Controller Class Initialized
DEBUG - 2014-07-11 16:04:07 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:04:07 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:04:07 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:04:07 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:04:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:04:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:04:07 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:04:07 --> Final output sent to browser
DEBUG - 2014-07-11 16:04:07 --> Total execution time: 0.1850
DEBUG - 2014-07-11 16:05:01 --> Config Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:05:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:05:01 --> URI Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Router Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Output Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Security Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Input Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:05:01 --> Language Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Language Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Config Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Loader Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:05:01 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:05:01 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:05:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:05:01 --> Session Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:05:01 --> Session routines successfully run
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Controller Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:05:01 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:05:01 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:05:01 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:05:01 --> Model Class Initialized
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:05:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:05:01 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:05:01 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:05:01 --> Final output sent to browser
DEBUG - 2014-07-11 16:05:01 --> Total execution time: 0.2520
DEBUG - 2014-07-11 16:21:54 --> Config Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:21:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:21:54 --> URI Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Router Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Output Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Security Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Input Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:21:54 --> Language Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Language Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Config Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Loader Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:21:54 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:21:54 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:21:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:21:54 --> Session Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:21:54 --> Session routines successfully run
DEBUG - 2014-07-11 16:21:54 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:21:54 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:21:54 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:21:54 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:54 --> Controller Class Initialized
DEBUG - 2014-07-11 16:21:55 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:21:55 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:21:55 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:21:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:21:55 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:55 --> Model Class Initialized
DEBUG - 2014-07-11 16:21:55 --> DB Transaction Failure
ERROR - 2014-07-11 16:21:55 --> Query error: Table 'vmv2.order' doesn't exist
DEBUG - 2014-07-11 16:21:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-11 16:22:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:07 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:07 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:07 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:07 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:08 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:08 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:08 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:08 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:22:08 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:08 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:08 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:08 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:08 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:08 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:08 --> Total execution time: 0.2910
DEBUG - 2014-07-11 16:22:14 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:14 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:14 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:14 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:14 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:14 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:14 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:14 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:22:14 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:14 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:14 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:14 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:14 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:14 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:14 --> Total execution time: 0.2010
DEBUG - 2014-07-11 16:22:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:16 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:16 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:16 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:16 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:16 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:22:16 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:16 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:16 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:16 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:16 --> Total execution time: 0.2700
DEBUG - 2014-07-11 16:22:27 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:27 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:27 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:27 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:27 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:27 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:27 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:27 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:22:27 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:27 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:27 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:27 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:27 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:27 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:27 --> Total execution time: 0.2040
DEBUG - 2014-07-11 16:22:29 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:29 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:29 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:29 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:29 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:29 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:29 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:29 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:22:29 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:29 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:29 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:29 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:29 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:29 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:29 --> Total execution time: 0.2060
DEBUG - 2014-07-11 16:22:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:32 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:32 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:32 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:32 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:32 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:22:32 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:32 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:32 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:32 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:32 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:32 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:32 --> Total execution time: 0.2760
DEBUG - 2014-07-11 16:22:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:39 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:39 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:39 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:39 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:39 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:39 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:39 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:39 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:39 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:39 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:39 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:39 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:39 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:39 --> Total execution time: 0.2930
DEBUG - 2014-07-11 16:22:48 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:48 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:48 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:48 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:48 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:48 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:48 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:48 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:22:48 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:48 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:48 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:48 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:48 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:48 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:48 --> Total execution time: 0.2720
DEBUG - 2014-07-11 16:22:50 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:50 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:50 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:50 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:50 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:50 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:50 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:22:50 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:50 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:50 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:50 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:50 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:50 --> Total execution time: 0.2850
DEBUG - 2014-07-11 16:22:52 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:22:52 --> URI Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Router Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Output Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Security Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Input Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:22:52 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Language Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Config Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Loader Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:22:52 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:22:52 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:22:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:22:52 --> Session Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:22:52 --> Session routines successfully run
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Controller Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:22:52 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:22:52 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:22:52 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:22:52 --> Model Class Initialized
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:22:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:22:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:22:52 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:22:52 --> Final output sent to browser
DEBUG - 2014-07-11 16:22:52 --> Total execution time: 0.2460
DEBUG - 2014-07-11 16:23:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:15 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:15 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:15 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:15 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:15 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:23:15 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:15 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:16 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:16 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:16 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:16 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:16 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:16 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:16 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:16 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:16 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:16 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:16 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:16 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:16 --> Total execution time: 0.3700
DEBUG - 2014-07-11 16:23:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:32 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:32 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:32 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:32 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:32 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:32 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:23:32 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:32 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:32 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:32 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:32 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:32 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:32 --> Total execution time: 0.2160
DEBUG - 2014-07-11 16:23:34 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:34 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:34 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:34 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:34 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:34 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:34 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:23:34 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:34 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:34 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:34 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:34 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:34 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:34 --> Total execution time: 0.2990
DEBUG - 2014-07-11 16:23:37 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:37 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:37 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:37 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:37 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:37 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:37 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:37 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:23:37 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:37 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:37 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:37 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:37 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:37 --> Total execution time: 0.2130
DEBUG - 2014-07-11 16:23:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:39 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:39 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:39 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:39 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:39 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:23:39 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:39 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:39 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:39 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:39 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:39 --> Total execution time: 0.3030
DEBUG - 2014-07-11 16:23:43 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:43 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:43 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:43 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:43 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:43 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:43 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:43 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:23:43 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:43 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:43 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:43 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:43 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:43 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:43 --> Total execution time: 0.2160
DEBUG - 2014-07-11 16:23:45 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:23:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:23:45 --> URI Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Router Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Output Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Security Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Input Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:23:45 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Language Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Config Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Loader Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:23:45 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:23:45 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:23:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:23:45 --> Session Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:23:45 --> Session routines successfully run
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Controller Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:23:45 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:23:45 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:23:45 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:23:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:23:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:23:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:23:45 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:23:45 --> Final output sent to browser
DEBUG - 2014-07-11 16:23:45 --> Total execution time: 0.2850
DEBUG - 2014-07-11 16:28:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:28:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:28:44 --> URI Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Router Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Output Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Security Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Input Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:28:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Loader Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:28:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:28:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:28:44 --> Session Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:28:44 --> Session routines successfully run
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:28:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:28:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:28:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:28:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:28:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:28:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:28:44 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:28:44 --> Final output sent to browser
DEBUG - 2014-07-11 16:28:44 --> Total execution time: 0.2980
DEBUG - 2014-07-11 16:30:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:30:32 --> URI Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Router Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Output Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Security Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Input Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:30:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Loader Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:30:32 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:30:32 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:30:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:30:32 --> Session Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:30:32 --> Session routines successfully run
DEBUG - 2014-07-11 16:30:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:30:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:30:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:30:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Controller Class Initialized
DEBUG - 2014-07-11 16:30:32 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:30:33 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:30:33 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:30:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:30:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:30:33 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:30:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:30:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:30:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:30:33 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:30:33 --> Final output sent to browser
DEBUG - 2014-07-11 16:30:33 --> Total execution time: 0.2840
DEBUG - 2014-07-11 16:31:36 --> Config Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:31:36 --> URI Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Router Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Output Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Security Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Input Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:31:36 --> Language Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Language Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Config Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Loader Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:31:36 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:31:36 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:31:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:31:36 --> Session Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:31:36 --> Session routines successfully run
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Controller Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:31:36 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:31:36 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:31:37 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:31:37 --> Model Class Initialized
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:31:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:31:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:31:37 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:31:37 --> Final output sent to browser
DEBUG - 2014-07-11 16:31:37 --> Total execution time: 0.3060
DEBUG - 2014-07-11 16:34:57 --> Config Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:34:57 --> URI Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Router Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Output Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Security Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Input Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:34:57 --> Language Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Language Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Config Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Loader Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:34:57 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:34:57 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:34:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:34:57 --> Session Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:34:57 --> Session routines successfully run
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Controller Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:34:57 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:34:57 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:34:57 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:34:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:34:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:34:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:34:57 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:34:57 --> Final output sent to browser
DEBUG - 2014-07-11 16:34:57 --> Total execution time: 0.2830
DEBUG - 2014-07-11 16:37:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:37:07 --> URI Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Router Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Output Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Security Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Input Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:37:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Loader Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:37:07 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:37:07 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:37:07 --> Session Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:37:07 --> Session routines successfully run
DEBUG - 2014-07-11 16:37:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:37:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:37:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:37:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Controller Class Initialized
DEBUG - 2014-07-11 16:37:07 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:37:07 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:37:07 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:37:07 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:37:07 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:37:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:37:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:37:07 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:37:07 --> Final output sent to browser
DEBUG - 2014-07-11 16:37:07 --> Total execution time: 0.2160
DEBUG - 2014-07-11 16:37:09 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:37:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:37:09 --> URI Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Router Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Output Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Security Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Input Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:37:09 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Loader Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:37:09 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:37:09 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:37:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:37:09 --> Session Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:37:09 --> Session routines successfully run
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Controller Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:37:09 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:37:09 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:37:09 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:37:09 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:37:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:37:09 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:37:09 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:37:09 --> Final output sent to browser
DEBUG - 2014-07-11 16:37:09 --> Total execution time: 0.2890
DEBUG - 2014-07-11 16:37:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:37:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:37:15 --> URI Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Router Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Output Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Security Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Input Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:37:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:15 --> Loader Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:37:16 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:37:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:37:16 --> Session Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:37:16 --> Session routines successfully run
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Controller Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:37:16 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:37:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:37:16 --> URI Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Router Class Initialized
DEBUG - 2014-07-11 16:37:16 --> No URI present. Default controller set.
DEBUG - 2014-07-11 16:37:16 --> Output Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Security Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Input Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:37:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Language Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Loader Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:37:16 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:37:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:37:16 --> Session Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:37:16 --> Session routines successfully run
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Controller Class Initialized
DEBUG - 2014-07-11 16:37:16 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:37:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:37:16 --> Model Class Initialized
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:37:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:37:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:37:16 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:37:16 --> Final output sent to browser
DEBUG - 2014-07-11 16:37:16 --> Total execution time: 0.2010
DEBUG - 2014-07-11 16:38:13 --> Config Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:38:13 --> URI Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Router Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Output Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Security Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Input Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:38:13 --> Language Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Language Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Config Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Loader Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:38:13 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:38:13 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:38:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:38:13 --> Session Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:38:13 --> Session routines successfully run
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Controller Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:38:13 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:38:13 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:38:13 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:38:13 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:38:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:38:13 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:38:13 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:38:13 --> Final output sent to browser
DEBUG - 2014-07-11 16:38:13 --> Total execution time: 0.2830
DEBUG - 2014-07-11 16:38:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:38:15 --> URI Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Router Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Output Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Security Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Input Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:38:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Loader Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:38:15 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:38:15 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:38:15 --> Session Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:38:15 --> Session routines successfully run
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Controller Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Setting MX_Controller Initialized
DEBUG - 2014-07-11 16:38:15 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:38:15 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:38:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:38:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:38:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:38:15 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:38:15 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:38:15 --> Final output sent to browser
DEBUG - 2014-07-11 16:38:15 --> Total execution time: 0.3130
DEBUG - 2014-07-11 16:39:36 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:36 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:36 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:36 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:36 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:36 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:36 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:39:36 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:36 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:39:36 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:39:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:39:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:39:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:39:36 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:39:36 --> Final output sent to browser
DEBUG - 2014-07-11 16:39:36 --> Total execution time: 0.3620
DEBUG - 2014-07-11 16:39:40 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:40 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:40 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:40 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:40 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:40 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:40 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:39:40 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:40 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:39:40 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:39:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:39:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:39:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:39:40 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:39:40 --> Final output sent to browser
DEBUG - 2014-07-11 16:39:40 --> Total execution time: 0.2860
DEBUG - 2014-07-11 16:39:43 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:43 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:43 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:43 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:43 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:43 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:43 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:43 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:44 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:44 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:44 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:44 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:44 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:44 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:45 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:39:45 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:45 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:39:45 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:39:45 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:39:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:39:45 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:39:45 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:39:45 --> Final output sent to browser
DEBUG - 2014-07-11 16:39:45 --> Total execution time: 0.4380
DEBUG - 2014-07-11 16:39:47 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:47 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:47 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:47 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:47 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:47 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:47 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:47 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:47 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:47 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:47 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:47 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:39:47 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:47 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:39:47 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:39:47 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:39:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:39:47 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:39:47 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:39:47 --> Final output sent to browser
DEBUG - 2014-07-11 16:39:47 --> Total execution time: 0.2160
DEBUG - 2014-07-11 16:39:49 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:49 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:49 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:49 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:49 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:49 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:49 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:39:49 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:49 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:39:49 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:39:49 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:39:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:39:49 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:39:49 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:39:49 --> Final output sent to browser
DEBUG - 2014-07-11 16:39:49 --> Total execution time: 0.2980
DEBUG - 2014-07-11 16:39:57 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:57 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:57 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:57 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:57 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:57 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:57 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:39:57 --> URI Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Router Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Output Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Security Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Input Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:39:57 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Language Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Config Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Loader Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:39:57 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:39:57 --> Session Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:39:57 --> Session routines successfully run
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Controller Class Initialized
DEBUG - 2014-07-11 16:39:57 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:39:58 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:39:58 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:39:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:39:58 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:58 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:39:58 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:39:58 --> Model Class Initialized
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:39:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:39:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:39:58 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:39:58 --> Final output sent to browser
DEBUG - 2014-07-11 16:39:58 --> Total execution time: 0.2820
DEBUG - 2014-07-11 16:40:06 --> Config Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:40:06 --> URI Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Router Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Output Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Security Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Input Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:40:06 --> Language Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Language Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Config Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Loader Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:40:06 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:40:06 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:40:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:40:06 --> Session Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:40:06 --> Session routines successfully run
DEBUG - 2014-07-11 16:40:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:40:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:40:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:40:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Controller Class Initialized
DEBUG - 2014-07-11 16:40:06 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:40:06 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:40:06 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:40:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:40:06 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:40:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:40:06 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:40:06 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:40:06 --> Final output sent to browser
DEBUG - 2014-07-11 16:40:06 --> Total execution time: 0.2150
DEBUG - 2014-07-11 16:40:34 --> Config Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:40:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:40:34 --> URI Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Router Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Output Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Security Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Input Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:40:34 --> Language Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Language Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Config Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Loader Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:40:34 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:40:34 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:40:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:40:34 --> Session Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:40:34 --> Session routines successfully run
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Controller Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:40:34 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:40:34 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:40:34 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:40:34 --> Model Class Initialized
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:40:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:40:34 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:40:34 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:40:34 --> Final output sent to browser
DEBUG - 2014-07-11 16:40:34 --> Total execution time: 0.3190
DEBUG - 2014-07-11 16:41:28 --> Config Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:41:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:41:28 --> URI Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Router Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Output Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Security Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Input Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:41:28 --> Language Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Language Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Config Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Loader Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:41:28 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:41:28 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:41:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:41:28 --> Session Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:41:28 --> Session routines successfully run
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Controller Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:41:28 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:41:28 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:41:28 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:41:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:41:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:41:28 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:41:28 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:41:28 --> Final output sent to browser
DEBUG - 2014-07-11 16:41:28 --> Total execution time: 0.3450
DEBUG - 2014-07-11 16:42:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:42:15 --> URI Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Router Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Output Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Security Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Input Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:42:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Loader Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:42:15 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:42:15 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:42:15 --> Session Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:42:15 --> Session routines successfully run
DEBUG - 2014-07-11 16:42:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:42:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:42:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:42:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Controller Class Initialized
DEBUG - 2014-07-11 16:42:15 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:42:15 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:42:15 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:42:15 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:42:15 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:42:15 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:42:15 --> Final output sent to browser
DEBUG - 2014-07-11 16:42:15 --> Total execution time: 0.2320
DEBUG - 2014-07-11 16:42:17 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:42:17 --> URI Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Router Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Output Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Security Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Input Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:42:17 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Loader Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:42:17 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:42:17 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:42:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:42:17 --> Session Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:42:17 --> Session routines successfully run
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Controller Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:42:17 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:42:17 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:42:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:42:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:42:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:42:17 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:42:17 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:42:17 --> Final output sent to browser
DEBUG - 2014-07-11 16:42:17 --> Total execution time: 0.2850
DEBUG - 2014-07-11 16:42:36 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:42:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:42:36 --> URI Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Router Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Output Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Security Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Input Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:42:36 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Loader Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:42:36 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:42:36 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:42:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:42:36 --> Session Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:42:36 --> Session routines successfully run
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Controller Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:42:36 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:42:36 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:42:36 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:42:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:42:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:42:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:42:36 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:42:36 --> Final output sent to browser
DEBUG - 2014-07-11 16:42:36 --> Total execution time: 0.3010
DEBUG - 2014-07-11 16:42:42 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:42:42 --> URI Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Router Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Output Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Security Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Input Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:42:42 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Loader Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:42:42 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:42:42 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:42:42 --> Session Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:42:42 --> Session routines successfully run
DEBUG - 2014-07-11 16:42:42 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:42:42 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:42:42 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:42:42 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Controller Class Initialized
DEBUG - 2014-07-11 16:42:42 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:42:42 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:42:42 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:42:42 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:42:42 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:42:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:42:42 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:42:42 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:42:42 --> Final output sent to browser
DEBUG - 2014-07-11 16:42:42 --> Total execution time: 0.2120
DEBUG - 2014-07-11 16:42:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:42:44 --> URI Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Router Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Output Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Security Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Input Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:42:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Loader Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:42:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:42:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:42:44 --> Session Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:42:44 --> Session routines successfully run
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:42:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:42:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:42:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:42:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:42:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:42:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:42:44 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:42:44 --> Final output sent to browser
DEBUG - 2014-07-11 16:42:44 --> Total execution time: 0.3040
DEBUG - 2014-07-11 16:43:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:43:39 --> URI Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Router Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Output Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Security Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Input Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:43:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Loader Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:43:39 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:43:39 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:43:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:43:39 --> Session Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:43:39 --> Session routines successfully run
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Controller Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:43:39 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:43:39 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:43:39 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:43:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:43:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:43:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:43:39 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:43:39 --> Final output sent to browser
DEBUG - 2014-07-11 16:43:39 --> Total execution time: 0.2840
DEBUG - 2014-07-11 16:43:43 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:43:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:43:43 --> URI Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Router Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Output Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Security Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Input Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:43:43 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Loader Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:43:43 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:43:43 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:43:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:43:43 --> Session Class Initialized
DEBUG - 2014-07-11 16:43:43 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:43:43 --> Session routines successfully run
DEBUG - 2014-07-11 16:43:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:43:43 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:43:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:43:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:43:44 --> URI Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Router Class Initialized
DEBUG - 2014-07-11 16:43:44 --> No URI present. Default controller set.
DEBUG - 2014-07-11 16:43:44 --> Output Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Security Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Input Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:43:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Loader Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:43:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:43:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:43:44 --> Session Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:43:44 --> Session routines successfully run
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:43:44 --> Site MX_Controller Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:43:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:43:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:43:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:43:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:43:44 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:43:44 --> Final output sent to browser
DEBUG - 2014-07-11 16:43:44 --> Total execution time: 0.2100
DEBUG - 2014-07-11 16:43:59 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:43:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:43:59 --> URI Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Router Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Output Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Security Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Input Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:43:59 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Language Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Config Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Loader Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:43:59 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:43:59 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:43:59 --> Session Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:43:59 --> Session routines successfully run
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Controller Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Setting MX_Controller Initialized
DEBUG - 2014-07-11 16:43:59 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:43:59 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:43:59 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:43:59 --> Model Class Initialized
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:43:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:43:59 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:43:59 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:43:59 --> Final output sent to browser
DEBUG - 2014-07-11 16:43:59 --> Total execution time: 0.2690
DEBUG - 2014-07-11 16:44:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:32 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:32 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:32 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:32 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:32 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:44:32 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:32 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:44:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:44:32 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:44:33 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:44:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:44:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:44:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:44:33 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:44:33 --> Final output sent to browser
DEBUG - 2014-07-11 16:44:33 --> Total execution time: 0.3400
DEBUG - 2014-07-11 16:44:35 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:35 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:35 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:35 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:35 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:35 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:35 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:35 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:44:36 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:36 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:44:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:44:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:44:36 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:44:36 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:44:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:44:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:44:36 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:44:36 --> Final output sent to browser
DEBUG - 2014-07-11 16:44:36 --> Total execution time: 0.2630
DEBUG - 2014-07-11 16:44:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:39 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:39 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:39 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:39 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:39 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:44:39 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:39 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:39 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:40 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:40 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:40 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:40 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:40 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:40 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:40 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:40 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:40 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:40 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Permission MX_Controller Initialized
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:40 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:44:40 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:44:40 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:44:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:44:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:44:40 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:44:40 --> Final output sent to browser
DEBUG - 2014-07-11 16:44:40 --> Total execution time: 0.3460
DEBUG - 2014-07-11 16:44:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:44 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:44 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:44 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:44 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:44:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:44:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:44:44 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:44:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:44:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:44:44 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:44:44 --> Final output sent to browser
DEBUG - 2014-07-11 16:44:44 --> Total execution time: 0.2180
DEBUG - 2014-07-11 16:44:48 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:44:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:44:48 --> URI Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Router Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Output Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Security Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Input Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:44:48 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Language Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Config Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Loader Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:44:48 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:44:48 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:44:48 --> Session Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:44:48 --> Session routines successfully run
DEBUG - 2014-07-11 16:44:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:44:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:44:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:44:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Model Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Controller Class Initialized
DEBUG - 2014-07-11 16:44:48 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:44:48 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:44:48 --> Form Validation Class Initialized
ERROR - 2014-07-11 16:44:48 --> 404 Page Not Found --> site/not_found
DEBUG - 2014-07-11 16:45:33 --> Config Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:45:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:45:33 --> URI Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Router Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Output Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Security Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Input Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:45:33 --> Language Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Language Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Config Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Loader Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:45:33 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:45:33 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:45:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:45:33 --> Session Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:45:33 --> Session routines successfully run
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Controller Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:45:33 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:45:33 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:45:33 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:45:33 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:45:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:45:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:45:33 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:45:33 --> Final output sent to browser
DEBUG - 2014-07-11 16:45:33 --> Total execution time: 0.2920
DEBUG - 2014-07-11 16:45:50 --> Config Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:45:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:45:50 --> URI Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Router Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Output Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Security Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Input Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:45:50 --> Language Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Language Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Config Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Loader Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:45:50 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:45:50 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:45:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:45:50 --> Session Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:45:50 --> Session routines successfully run
DEBUG - 2014-07-11 16:45:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:45:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:45:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:45:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Controller Class Initialized
DEBUG - 2014-07-11 16:45:50 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:45:50 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:45:50 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:45:50 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:45:50 --> Model Class Initialized
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:45:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:45:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:45:50 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:45:50 --> Final output sent to browser
DEBUG - 2014-07-11 16:45:50 --> Total execution time: 0.2300
DEBUG - 2014-07-11 16:47:03 --> Config Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:47:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:47:03 --> URI Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Router Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Output Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Security Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Input Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:47:03 --> Language Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Language Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Config Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Loader Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:47:03 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:47:03 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:47:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:47:03 --> Session Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:47:03 --> Session routines successfully run
DEBUG - 2014-07-11 16:47:03 --> Model Class Initialized
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:47:03 --> Model Class Initialized
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:47:03 --> Model Class Initialized
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:47:03 --> Model Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Model Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Controller Class Initialized
DEBUG - 2014-07-11 16:47:03 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:47:03 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:47:03 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:47:03 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:47:03 --> Model Class Initialized
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:47:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:47:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:47:03 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:47:03 --> Final output sent to browser
DEBUG - 2014-07-11 16:47:03 --> Total execution time: 0.2190
DEBUG - 2014-07-11 16:48:24 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:48:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:48:24 --> URI Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Router Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Output Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Security Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Input Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:48:24 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Loader Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:48:24 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:48:24 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:48:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:48:24 --> Session Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:48:24 --> Session routines successfully run
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Controller Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:48:24 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:48:24 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:48:24 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:48:24 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:48:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:48:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:48:24 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:48:24 --> Final output sent to browser
DEBUG - 2014-07-11 16:48:24 --> Total execution time: 0.2850
DEBUG - 2014-07-11 16:48:26 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:48:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:48:26 --> URI Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Router Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Output Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Security Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Input Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:48:26 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Loader Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:48:26 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:48:26 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:48:26 --> Session Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:48:26 --> Session routines successfully run
DEBUG - 2014-07-11 16:48:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:48:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:48:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:48:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Controller Class Initialized
DEBUG - 2014-07-11 16:48:26 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:48:26 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:48:26 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:48:26 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:48:26 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:48:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:48:27 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:48:27 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:48:27 --> Final output sent to browser
DEBUG - 2014-07-11 16:48:27 --> Total execution time: 0.2150
DEBUG - 2014-07-11 16:48:28 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:48:28 --> URI Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Router Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Output Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Security Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Input Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:48:28 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Loader Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:48:28 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:48:28 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:48:28 --> Session Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:48:28 --> Session routines successfully run
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Controller Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:48:28 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:48:28 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:48:28 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:48:28 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:48:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:48:28 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:48:28 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:48:28 --> Final output sent to browser
DEBUG - 2014-07-11 16:48:28 --> Total execution time: 0.2910
DEBUG - 2014-07-11 16:48:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:48:30 --> URI Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Router Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Output Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Security Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Input Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:48:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Loader Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:48:30 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:48:30 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:48:30 --> Session Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:48:30 --> Session routines successfully run
DEBUG - 2014-07-11 16:48:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:48:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:48:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:48:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Controller Class Initialized
DEBUG - 2014-07-11 16:48:30 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:48:30 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:48:30 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:48:30 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:48:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:48:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:48:30 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:48:30 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:48:30 --> Final output sent to browser
DEBUG - 2014-07-11 16:48:30 --> Total execution time: 0.2340
DEBUG - 2014-07-11 16:49:14 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:49:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:49:14 --> URI Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Router Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Output Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Security Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Input Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:49:14 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Loader Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:49:14 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:49:14 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:49:14 --> Session Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:49:14 --> Session routines successfully run
DEBUG - 2014-07-11 16:49:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:49:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:49:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:49:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Controller Class Initialized
DEBUG - 2014-07-11 16:49:14 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:49:14 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:49:14 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:49:14 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:49:14 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:49:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:49:14 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:49:14 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:49:14 --> Final output sent to browser
DEBUG - 2014-07-11 16:49:14 --> Total execution time: 0.2140
DEBUG - 2014-07-11 16:49:16 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:16 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:49:16 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:49:16 --> URI Class Initialized
DEBUG - 2014-07-11 16:49:16 --> Router Class Initialized
DEBUG - 2014-07-11 16:49:16 --> Output Class Initialized
DEBUG - 2014-07-11 16:49:16 --> Security Class Initialized
DEBUG - 2014-07-11 16:49:16 --> Input Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:49:17 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Loader Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:49:17 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:49:17 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:49:17 --> Session Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:49:17 --> Session routines successfully run
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Controller Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:49:17 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:49:17 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:49:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:49:17 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:49:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:49:17 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:49:17 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:49:17 --> Final output sent to browser
DEBUG - 2014-07-11 16:49:17 --> Total execution time: 0.3130
DEBUG - 2014-07-11 16:49:20 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:49:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:49:20 --> URI Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Router Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Output Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Security Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Input Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:49:20 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Loader Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:49:20 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:49:20 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:49:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:49:20 --> Session Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:49:20 --> Session routines successfully run
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Controller Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:49:20 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:49:20 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:49:20 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:49:20 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:49:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:49:20 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:49:20 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:49:20 --> Final output sent to browser
DEBUG - 2014-07-11 16:49:20 --> Total execution time: 0.2640
DEBUG - 2014-07-11 16:49:29 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:49:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:49:29 --> URI Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Router Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Output Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Security Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Input Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:49:29 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Loader Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:49:29 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:49:29 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:49:29 --> Session Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:49:29 --> Session routines successfully run
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Controller Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:49:29 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:49:29 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:49:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:49:29 --> URI Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Router Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Output Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Security Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Input Class Initialized
DEBUG - 2014-07-11 16:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:49:29 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Loader Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:49:30 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:49:30 --> Session Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:49:30 --> Session routines successfully run
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Controller Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:49:30 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:49:30 --> URI Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Router Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Output Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Security Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Input Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:49:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Language Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Config Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Loader Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:49:30 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:49:30 --> Session Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:49:30 --> Session routines successfully run
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Controller Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Order MX_Controller Initialized
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:49:30 --> Form Validation Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:49:30 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:49:30 --> Model Class Initialized
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:49:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:49:30 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:49:30 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:49:30 --> Final output sent to browser
DEBUG - 2014-07-11 16:49:30 --> Total execution time: 0.3280
DEBUG - 2014-07-11 16:51:35 --> Config Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Hooks Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Utf8 Class Initialized
DEBUG - 2014-07-11 16:51:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 16:51:35 --> URI Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Router Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Output Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Security Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Input Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 16:51:35 --> Language Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Language Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Config Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Loader Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Helper loaded: url_helper
DEBUG - 2014-07-11 16:51:35 --> Helper loaded: common_helper
DEBUG - 2014-07-11 16:51:35 --> Database Driver Class Initialized
ERROR - 2014-07-11 16:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 16:51:35 --> Session Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Helper loaded: string_helper
DEBUG - 2014-07-11 16:51:35 --> Session routines successfully run
DEBUG - 2014-07-11 16:51:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 16:51:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 16:51:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 16:51:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Controller Class Initialized
DEBUG - 2014-07-11 16:51:35 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 16:51:35 --> Helper loaded: form_helper
DEBUG - 2014-07-11 16:51:35 --> Form Validation Class Initialized
ERROR - 2014-07-11 16:51:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 126
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 16:51:35 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 16:51:35 --> Model Class Initialized
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 16:51:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 16:51:35 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 16:51:35 --> Helper loaded: text_helper
DEBUG - 2014-07-11 16:51:35 --> Final output sent to browser
DEBUG - 2014-07-11 16:51:35 --> Total execution time: 0.2250
DEBUG - 2014-07-11 17:04:06 --> Config Class Initialized
DEBUG - 2014-07-11 17:04:06 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:04:06 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:04:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:04:07 --> URI Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Router Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Output Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Security Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Input Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:04:07 --> Language Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Language Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Config Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Loader Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:04:07 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:04:07 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:04:07 --> Session Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:04:07 --> Session routines successfully run
DEBUG - 2014-07-11 17:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Controller Class Initialized
DEBUG - 2014-07-11 17:04:07 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:04:07 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:04:07 --> Form Validation Class Initialized
ERROR - 2014-07-11 17:04:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 126
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:04:07 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:04:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:04:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:04:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:04:07 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:04:07 --> Final output sent to browser
DEBUG - 2014-07-11 17:04:07 --> Total execution time: 0.2440
DEBUG - 2014-07-11 17:06:15 --> Config Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:06:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:06:15 --> URI Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Router Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Output Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Security Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Input Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:06:15 --> Language Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Language Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Config Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Loader Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:06:15 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:06:15 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:06:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:06:15 --> Session Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:06:15 --> Session routines successfully run
DEBUG - 2014-07-11 17:06:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:06:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:06:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:06:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Controller Class Initialized
DEBUG - 2014-07-11 17:06:15 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:06:15 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:06:15 --> Form Validation Class Initialized
ERROR - 2014-07-11 17:06:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 126
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:06:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:06:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:06:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:06:15 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:06:15 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:06:15 --> Final output sent to browser
DEBUG - 2014-07-11 17:06:15 --> Total execution time: 0.2220
DEBUG - 2014-07-11 17:07:22 --> Config Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:07:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:07:22 --> URI Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Router Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Output Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Security Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Input Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:07:22 --> Language Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Language Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Config Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Loader Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:07:22 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:07:22 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:07:22 --> Session Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:07:22 --> Session routines successfully run
DEBUG - 2014-07-11 17:07:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:07:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:07:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:07:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Controller Class Initialized
DEBUG - 2014-07-11 17:07:22 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:07:22 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:07:22 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:07:22 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:07:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:07:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:07:22 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:07:22 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:07:22 --> Final output sent to browser
DEBUG - 2014-07-11 17:07:22 --> Total execution time: 0.2180
DEBUG - 2014-07-11 17:07:24 --> Config Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:07:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:07:24 --> URI Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Router Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Output Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Security Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Input Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:07:24 --> Language Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Language Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Config Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Loader Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:07:24 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:07:24 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:07:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:07:24 --> Session Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:07:24 --> Session routines successfully run
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Controller Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:07:24 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:07:24 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:07:24 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:07:24 --> Model Class Initialized
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:07:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:07:25 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:07:25 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:07:25 --> Final output sent to browser
DEBUG - 2014-07-11 17:07:25 --> Total execution time: 0.2870
DEBUG - 2014-07-11 17:08:14 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:08:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:08:14 --> URI Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Router Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Output Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Security Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Input Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:08:14 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Loader Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:08:14 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:08:14 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:08:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:08:14 --> Session Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:08:14 --> Session routines successfully run
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Controller Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:08:14 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:08:14 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:08:14 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:08:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:08:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:08:14 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:08:14 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:08:14 --> Final output sent to browser
DEBUG - 2014-07-11 17:08:14 --> Total execution time: 0.3020
DEBUG - 2014-07-11 17:08:16 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:08:16 --> URI Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Router Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Output Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Security Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Input Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:08:16 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Loader Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:08:16 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:08:16 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:08:16 --> Session Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:08:16 --> Session routines successfully run
DEBUG - 2014-07-11 17:08:16 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:08:16 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:08:16 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:08:16 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Controller Class Initialized
DEBUG - 2014-07-11 17:08:16 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:08:16 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:08:16 --> Form Validation Class Initialized
ERROR - 2014-07-11 17:08:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 126
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:08:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:08:16 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:08:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:08:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:08:16 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:08:16 --> Final output sent to browser
DEBUG - 2014-07-11 17:08:16 --> Total execution time: 0.2300
DEBUG - 2014-07-11 17:08:21 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:08:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:08:21 --> URI Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Router Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Output Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Security Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Input Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:08:21 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Loader Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:08:21 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:08:21 --> Session Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:08:21 --> Session routines successfully run
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Controller Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:08:21 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:08:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:08:21 --> URI Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Router Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Output Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Security Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Input Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:08:21 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Loader Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:08:21 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:08:21 --> Session Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:08:21 --> Session routines successfully run
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Controller Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:08:21 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:08:21 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:08:21 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:08:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:08:22 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:08:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:08:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:08:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:08:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:08:22 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:08:22 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:08:22 --> Final output sent to browser
DEBUG - 2014-07-11 17:08:22 --> Total execution time: 0.3430
DEBUG - 2014-07-11 17:08:25 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:08:25 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:08:25 --> URI Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Router Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Output Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Security Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Input Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:08:25 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Language Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Config Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Loader Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:08:25 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:08:25 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:08:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:08:25 --> Session Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:08:25 --> Session routines successfully run
DEBUG - 2014-07-11 17:08:25 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:08:25 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:08:25 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:08:25 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Controller Class Initialized
DEBUG - 2014-07-11 17:08:25 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:08:25 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:08:25 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:08:25 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:08:25 --> Model Class Initialized
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:08:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:08:25 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:08:25 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:08:25 --> Final output sent to browser
DEBUG - 2014-07-11 17:08:25 --> Total execution time: 0.2480
DEBUG - 2014-07-11 17:09:15 --> Config Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:09:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:09:15 --> URI Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Router Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Output Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Security Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Input Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:09:15 --> Language Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Language Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Config Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Loader Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:09:15 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:09:15 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:09:15 --> Session Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:09:15 --> Session routines successfully run
DEBUG - 2014-07-11 17:09:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:09:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:09:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:09:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Controller Class Initialized
DEBUG - 2014-07-11 17:09:15 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:09:15 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:09:15 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-11 17:09:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-11 17:09:15 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-11 17:09:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-11 17:09:15 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:09:15 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:09:15 --> Final output sent to browser
DEBUG - 2014-07-11 17:09:15 --> Total execution time: 0.2340
DEBUG - 2014-07-11 17:09:53 --> Config Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:09:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:09:53 --> URI Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Router Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Output Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Security Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Input Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:09:53 --> Language Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Language Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Config Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Loader Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:09:53 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:09:53 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:09:53 --> Session Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:09:53 --> Session routines successfully run
DEBUG - 2014-07-11 17:09:53 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:09:53 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:09:53 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:09:53 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Model Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Controller Class Initialized
DEBUG - 2014-07-11 17:09:53 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:09:53 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:09:53 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:09:53 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:09:53 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-07-11 17:09:53 --> Helper loaded: text_helper
DEBUG - 2014-07-11 17:09:53 --> Final output sent to browser
DEBUG - 2014-07-11 17:09:53 --> Total execution time: 0.1690
DEBUG - 2014-07-11 17:10:23 --> Config Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:10:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:10:23 --> URI Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Router Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Output Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Security Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Input Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:10:23 --> Language Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Language Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Config Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Loader Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:10:23 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:10:23 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:10:23 --> Session Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:10:23 --> Session routines successfully run
DEBUG - 2014-07-11 17:10:23 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:10:23 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:10:23 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:10:23 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Controller Class Initialized
DEBUG - 2014-07-11 17:10:23 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:10:23 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:10:23 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:10:23 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:10:23 --> Final output sent to browser
DEBUG - 2014-07-11 17:10:23 --> Total execution time: 0.1690
DEBUG - 2014-07-11 17:10:36 --> Config Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:10:36 --> URI Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Router Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Output Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Security Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Input Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:10:36 --> Language Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Language Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Config Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Loader Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:10:36 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:10:36 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:10:36 --> Session Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:10:36 --> Session routines successfully run
DEBUG - 2014-07-11 17:10:36 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:10:36 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:10:36 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:10:36 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Model Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Controller Class Initialized
DEBUG - 2014-07-11 17:10:36 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:10:36 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:10:36 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:10:36 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:10:36 --> Final output sent to browser
DEBUG - 2014-07-11 17:10:36 --> Total execution time: 0.1670
DEBUG - 2014-07-11 17:11:48 --> Config Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:11:48 --> URI Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Router Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Output Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Security Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Input Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:11:48 --> Language Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Language Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Config Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Loader Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:11:48 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:11:48 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:11:48 --> Session Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:11:48 --> Session routines successfully run
DEBUG - 2014-07-11 17:11:48 --> Model Class Initialized
DEBUG - 2014-07-11 17:11:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:11:48 --> Model Class Initialized
DEBUG - 2014-07-11 17:11:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:11:48 --> Model Class Initialized
DEBUG - 2014-07-11 17:11:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:11:48 --> Model Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Model Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Controller Class Initialized
DEBUG - 2014-07-11 17:11:48 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:11:48 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:11:48 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:11:48 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:11:48 --> Final output sent to browser
DEBUG - 2014-07-11 17:11:48 --> Total execution time: 0.1700
DEBUG - 2014-07-11 17:22:12 --> Config Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:22:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:22:12 --> URI Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Router Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Output Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Security Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Input Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:22:12 --> Language Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Language Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Config Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Loader Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:22:12 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:22:12 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:22:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:22:12 --> Session Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:22:12 --> Session routines successfully run
DEBUG - 2014-07-11 17:22:12 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:22:12 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:22:12 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:22:12 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Controller Class Initialized
DEBUG - 2014-07-11 17:22:12 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:22:12 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:22:12 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:22:12 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:22:12 --> Final output sent to browser
DEBUG - 2014-07-11 17:22:12 --> Total execution time: 0.1850
DEBUG - 2014-07-11 17:22:46 --> Config Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:22:46 --> URI Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Router Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Output Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Security Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Input Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:22:46 --> Language Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Language Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Config Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Loader Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:22:46 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:22:46 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:22:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:22:46 --> Session Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:22:46 --> Session routines successfully run
DEBUG - 2014-07-11 17:22:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:22:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:22:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:22:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Controller Class Initialized
DEBUG - 2014-07-11 17:22:46 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:22:46 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:22:46 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:22:46 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:22:46 --> Final output sent to browser
DEBUG - 2014-07-11 17:22:46 --> Total execution time: 0.1640
DEBUG - 2014-07-11 17:24:06 --> Config Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:24:06 --> URI Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Router Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Output Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Security Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Input Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:24:06 --> Language Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Language Class Initialized
DEBUG - 2014-07-11 17:24:06 --> Config Class Initialized
DEBUG - 2014-07-11 17:24:07 --> Loader Class Initialized
DEBUG - 2014-07-11 17:24:07 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:24:07 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:24:07 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:24:07 --> Session Class Initialized
DEBUG - 2014-07-11 17:24:07 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:24:07 --> Session routines successfully run
DEBUG - 2014-07-11 17:24:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:24:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:24:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:24:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:24:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:24:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:24:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:24:07 --> Model Class Initialized
DEBUG - 2014-07-11 17:24:07 --> Controller Class Initialized
DEBUG - 2014-07-11 17:24:07 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:24:07 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:24:07 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:24:07 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:24:07 --> Final output sent to browser
DEBUG - 2014-07-11 17:24:07 --> Total execution time: 0.1840
DEBUG - 2014-07-11 17:25:28 --> Config Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:25:28 --> URI Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Router Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Output Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Security Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Input Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:25:28 --> Language Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Language Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Config Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Loader Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:25:28 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:25:28 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:25:28 --> Session Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:25:28 --> Session routines successfully run
DEBUG - 2014-07-11 17:25:28 --> Model Class Initialized
DEBUG - 2014-07-11 17:25:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:25:28 --> Model Class Initialized
DEBUG - 2014-07-11 17:25:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:25:28 --> Model Class Initialized
DEBUG - 2014-07-11 17:25:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:25:28 --> Model Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Model Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Controller Class Initialized
DEBUG - 2014-07-11 17:25:28 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:25:28 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:25:28 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:25:28 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:25:28 --> Final output sent to browser
DEBUG - 2014-07-11 17:25:28 --> Total execution time: 0.1690
DEBUG - 2014-07-11 17:26:10 --> Config Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:26:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:26:10 --> URI Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Router Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Output Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Security Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Input Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:26:10 --> Language Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Language Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Config Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Loader Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:26:10 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:26:10 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:26:10 --> Session Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:26:10 --> Session routines successfully run
DEBUG - 2014-07-11 17:26:10 --> Model Class Initialized
DEBUG - 2014-07-11 17:26:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:26:10 --> Model Class Initialized
DEBUG - 2014-07-11 17:26:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:26:10 --> Model Class Initialized
DEBUG - 2014-07-11 17:26:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:26:10 --> Model Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Model Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Controller Class Initialized
DEBUG - 2014-07-11 17:26:10 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:26:10 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:26:10 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:26:10 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:26:10 --> Final output sent to browser
DEBUG - 2014-07-11 17:26:10 --> Total execution time: 0.1670
DEBUG - 2014-07-11 17:27:00 --> Config Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:27:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:27:00 --> URI Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Router Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Output Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Security Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Input Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:27:00 --> Language Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Language Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Config Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Loader Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:27:00 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:27:00 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:27:00 --> Session Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:27:00 --> Session routines successfully run
DEBUG - 2014-07-11 17:27:00 --> Model Class Initialized
DEBUG - 2014-07-11 17:27:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:27:00 --> Model Class Initialized
DEBUG - 2014-07-11 17:27:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:27:00 --> Model Class Initialized
DEBUG - 2014-07-11 17:27:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:27:00 --> Model Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Model Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Controller Class Initialized
DEBUG - 2014-07-11 17:27:00 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:27:00 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:27:00 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:27:00 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:27:00 --> Final output sent to browser
DEBUG - 2014-07-11 17:27:00 --> Total execution time: 0.1650
DEBUG - 2014-07-11 17:28:45 --> Config Class Initialized
DEBUG - 2014-07-11 17:28:45 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:28:45 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:28:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:28:45 --> URI Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Router Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Output Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Security Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Input Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:28:46 --> Language Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Language Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Config Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Loader Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:28:46 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:28:46 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:28:46 --> Session Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:28:46 --> Session routines successfully run
DEBUG - 2014-07-11 17:28:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:28:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:28:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:28:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:28:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:28:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:28:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Model Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Controller Class Initialized
DEBUG - 2014-07-11 17:28:46 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:28:46 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:28:46 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:28:46 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:28:46 --> Final output sent to browser
DEBUG - 2014-07-11 17:28:46 --> Total execution time: 0.1690
DEBUG - 2014-07-11 17:29:55 --> Config Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:29:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:29:55 --> URI Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Router Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Output Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Security Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Input Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:29:55 --> Language Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Language Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Config Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Loader Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:29:55 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:29:55 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:29:55 --> Session Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:29:55 --> Session routines successfully run
DEBUG - 2014-07-11 17:29:55 --> Model Class Initialized
DEBUG - 2014-07-11 17:29:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:29:55 --> Model Class Initialized
DEBUG - 2014-07-11 17:29:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:29:55 --> Model Class Initialized
DEBUG - 2014-07-11 17:29:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:29:55 --> Model Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Model Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Controller Class Initialized
DEBUG - 2014-07-11 17:29:55 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:29:55 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:29:55 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:29:55 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:29:55 --> Final output sent to browser
DEBUG - 2014-07-11 17:29:55 --> Total execution time: 0.1650
DEBUG - 2014-07-11 17:31:56 --> Config Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:31:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:31:56 --> URI Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Router Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Output Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Security Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Input Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:31:56 --> Language Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Language Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Config Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Loader Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:31:56 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:31:56 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:31:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:31:56 --> Session Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:31:56 --> Session routines successfully run
DEBUG - 2014-07-11 17:31:56 --> Model Class Initialized
DEBUG - 2014-07-11 17:31:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:31:56 --> Model Class Initialized
DEBUG - 2014-07-11 17:31:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:31:56 --> Model Class Initialized
DEBUG - 2014-07-11 17:31:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:31:56 --> Model Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Model Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Controller Class Initialized
DEBUG - 2014-07-11 17:31:56 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:31:56 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:31:56 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:31:56 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:31:56 --> Final output sent to browser
DEBUG - 2014-07-11 17:31:56 --> Total execution time: 0.1680
DEBUG - 2014-07-11 17:32:39 --> Config Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:32:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:32:39 --> URI Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Router Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Output Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Security Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Input Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:32:39 --> Language Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Language Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Config Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Loader Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:32:39 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:32:39 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:32:39 --> Session Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:32:39 --> Session routines successfully run
DEBUG - 2014-07-11 17:32:39 --> Model Class Initialized
DEBUG - 2014-07-11 17:32:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:32:39 --> Model Class Initialized
DEBUG - 2014-07-11 17:32:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:32:39 --> Model Class Initialized
DEBUG - 2014-07-11 17:32:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:32:39 --> Model Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Model Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Controller Class Initialized
DEBUG - 2014-07-11 17:32:39 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:32:39 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:32:39 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:32:39 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:32:39 --> Final output sent to browser
DEBUG - 2014-07-11 17:32:39 --> Total execution time: 0.1690
DEBUG - 2014-07-11 17:33:13 --> Config Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:33:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:33:13 --> URI Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Router Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Output Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Security Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Input Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:33:13 --> Language Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Language Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Config Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Loader Class Initialized
DEBUG - 2014-07-11 17:33:13 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:33:13 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:33:13 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:33:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:33:14 --> Session Class Initialized
DEBUG - 2014-07-11 17:33:14 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:33:14 --> Session routines successfully run
DEBUG - 2014-07-11 17:33:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:33:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:33:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:33:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:14 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:14 --> Controller Class Initialized
DEBUG - 2014-07-11 17:33:14 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:33:14 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:33:14 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:33:14 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:33:14 --> Final output sent to browser
DEBUG - 2014-07-11 17:33:14 --> Total execution time: 0.1680
DEBUG - 2014-07-11 17:33:44 --> Config Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:33:44 --> URI Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Router Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Output Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Security Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Input Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:33:44 --> Language Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Language Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Config Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Loader Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:33:44 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:33:44 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:33:44 --> Session Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:33:44 --> Session routines successfully run
DEBUG - 2014-07-11 17:33:44 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:33:44 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:33:44 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:33:44 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Model Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Controller Class Initialized
DEBUG - 2014-07-11 17:33:44 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:33:44 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:33:44 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:33:44 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:33:44 --> Final output sent to browser
DEBUG - 2014-07-11 17:33:44 --> Total execution time: 0.1640
DEBUG - 2014-07-11 17:34:34 --> Config Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:34:34 --> URI Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Router Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Output Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Security Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Input Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:34:34 --> Language Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Language Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Config Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Loader Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:34:34 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:34:34 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:34:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:34:34 --> Session Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:34:34 --> Session routines successfully run
DEBUG - 2014-07-11 17:34:34 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:34:34 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:34:34 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:34:34 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Controller Class Initialized
DEBUG - 2014-07-11 17:34:34 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:34:34 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:34:34 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:34:34 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:34:34 --> Final output sent to browser
DEBUG - 2014-07-11 17:34:34 --> Total execution time: 0.1650
DEBUG - 2014-07-11 17:34:47 --> Config Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:34:47 --> URI Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Router Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Output Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Security Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Input Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:34:47 --> Language Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Language Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Config Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Loader Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:34:47 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:34:47 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:34:47 --> Session Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:34:47 --> Session routines successfully run
DEBUG - 2014-07-11 17:34:47 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:34:47 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:34:47 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:34:47 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Model Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Controller Class Initialized
DEBUG - 2014-07-11 17:34:47 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:34:47 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:34:47 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:34:47 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:34:47 --> Final output sent to browser
DEBUG - 2014-07-11 17:34:47 --> Total execution time: 0.1690
DEBUG - 2014-07-11 17:42:33 --> Config Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:42:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:42:33 --> URI Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Router Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Output Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Security Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Input Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:42:33 --> Language Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Language Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Config Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Loader Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:42:33 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:42:33 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:42:33 --> Session Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:42:33 --> Session routines successfully run
DEBUG - 2014-07-11 17:42:33 --> Model Class Initialized
DEBUG - 2014-07-11 17:42:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:42:33 --> Model Class Initialized
DEBUG - 2014-07-11 17:42:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:42:33 --> Model Class Initialized
DEBUG - 2014-07-11 17:42:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:42:33 --> Model Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Model Class Initialized
DEBUG - 2014-07-11 17:42:33 --> Controller Class Initialized
DEBUG - 2014-07-11 17:42:34 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:42:34 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:42:34 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:42:34 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:42:34 --> Final output sent to browser
DEBUG - 2014-07-11 17:42:34 --> Total execution time: 0.1790
DEBUG - 2014-07-11 17:55:09 --> Config Class Initialized
DEBUG - 2014-07-11 17:55:09 --> Hooks Class Initialized
DEBUG - 2014-07-11 17:55:09 --> Utf8 Class Initialized
DEBUG - 2014-07-11 17:55:09 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 17:55:09 --> URI Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Router Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Output Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Security Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Input Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 17:55:10 --> Language Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Language Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Config Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Loader Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Helper loaded: url_helper
DEBUG - 2014-07-11 17:55:10 --> Helper loaded: common_helper
DEBUG - 2014-07-11 17:55:10 --> Database Driver Class Initialized
ERROR - 2014-07-11 17:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 17:55:10 --> Session Class Initialized
DEBUG - 2014-07-11 17:55:10 --> Helper loaded: string_helper
DEBUG - 2014-07-11 17:55:11 --> Session routines successfully run
DEBUG - 2014-07-11 17:55:11 --> Model Class Initialized
DEBUG - 2014-07-11 17:55:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 17:55:11 --> Model Class Initialized
DEBUG - 2014-07-11 17:55:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 17:55:11 --> Model Class Initialized
DEBUG - 2014-07-11 17:55:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 17:55:11 --> Model Class Initialized
DEBUG - 2014-07-11 17:55:11 --> Model Class Initialized
DEBUG - 2014-07-11 17:55:11 --> Controller Class Initialized
DEBUG - 2014-07-11 17:55:11 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 17:55:11 --> Helper loaded: form_helper
DEBUG - 2014-07-11 17:55:11 --> Form Validation Class Initialized
DEBUG - 2014-07-11 17:55:12 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 17:55:12 --> Final output sent to browser
DEBUG - 2014-07-11 17:55:12 --> Total execution time: 2.7922
DEBUG - 2014-07-11 18:23:59 --> Config Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Hooks Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Utf8 Class Initialized
DEBUG - 2014-07-11 18:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 18:23:59 --> URI Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Router Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Output Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Security Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Input Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 18:23:59 --> Language Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Language Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Config Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Loader Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Helper loaded: url_helper
DEBUG - 2014-07-11 18:23:59 --> Helper loaded: common_helper
DEBUG - 2014-07-11 18:23:59 --> Database Driver Class Initialized
ERROR - 2014-07-11 18:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 18:23:59 --> Session Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Helper loaded: string_helper
DEBUG - 2014-07-11 18:23:59 --> Session routines successfully run
DEBUG - 2014-07-11 18:23:59 --> Model Class Initialized
DEBUG - 2014-07-11 18:23:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 18:23:59 --> Model Class Initialized
DEBUG - 2014-07-11 18:23:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 18:23:59 --> Model Class Initialized
DEBUG - 2014-07-11 18:23:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 18:23:59 --> Model Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Model Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Controller Class Initialized
DEBUG - 2014-07-11 18:23:59 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 18:23:59 --> Helper loaded: form_helper
DEBUG - 2014-07-11 18:23:59 --> Form Validation Class Initialized
DEBUG - 2014-07-11 18:23:59 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 18:23:59 --> Final output sent to browser
DEBUG - 2014-07-11 18:23:59 --> Total execution time: 0.3460
DEBUG - 2014-07-11 18:30:24 --> Config Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Hooks Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Utf8 Class Initialized
DEBUG - 2014-07-11 18:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 18:30:24 --> URI Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Router Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Output Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Security Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Input Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 18:30:24 --> Language Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Language Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Config Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Loader Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Helper loaded: url_helper
DEBUG - 2014-07-11 18:30:24 --> Helper loaded: common_helper
DEBUG - 2014-07-11 18:30:24 --> Database Driver Class Initialized
ERROR - 2014-07-11 18:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 18:30:24 --> Session Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Helper loaded: string_helper
DEBUG - 2014-07-11 18:30:24 --> Session routines successfully run
DEBUG - 2014-07-11 18:30:24 --> Model Class Initialized
DEBUG - 2014-07-11 18:30:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 18:30:24 --> Model Class Initialized
DEBUG - 2014-07-11 18:30:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 18:30:24 --> Model Class Initialized
DEBUG - 2014-07-11 18:30:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 18:30:24 --> Model Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Model Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Controller Class Initialized
DEBUG - 2014-07-11 18:30:24 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 18:30:24 --> Helper loaded: form_helper
DEBUG - 2014-07-11 18:30:24 --> Form Validation Class Initialized
DEBUG - 2014-07-11 18:30:24 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 18:30:24 --> Final output sent to browser
DEBUG - 2014-07-11 18:30:24 --> Total execution time: 0.1810
DEBUG - 2014-07-11 18:31:36 --> Config Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Hooks Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Utf8 Class Initialized
DEBUG - 2014-07-11 18:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 18:31:36 --> URI Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Router Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Output Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Security Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Input Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 18:31:36 --> Language Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Language Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Config Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Loader Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Helper loaded: url_helper
DEBUG - 2014-07-11 18:31:36 --> Helper loaded: common_helper
DEBUG - 2014-07-11 18:31:36 --> Database Driver Class Initialized
ERROR - 2014-07-11 18:31:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 18:31:36 --> Session Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Helper loaded: string_helper
DEBUG - 2014-07-11 18:31:36 --> Session routines successfully run
DEBUG - 2014-07-11 18:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 18:31:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 18:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 18:31:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 18:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 18:31:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 18:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Model Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Controller Class Initialized
DEBUG - 2014-07-11 18:31:36 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 18:31:36 --> Helper loaded: form_helper
DEBUG - 2014-07-11 18:31:36 --> Form Validation Class Initialized
DEBUG - 2014-07-11 18:31:36 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 18:31:36 --> Final output sent to browser
DEBUG - 2014-07-11 18:31:36 --> Total execution time: 0.1670
DEBUG - 2014-07-11 18:32:46 --> Config Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Hooks Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Utf8 Class Initialized
DEBUG - 2014-07-11 18:32:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 18:32:46 --> URI Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Router Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Output Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Security Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Input Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 18:32:46 --> Language Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Language Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Config Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Loader Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Helper loaded: url_helper
DEBUG - 2014-07-11 18:32:46 --> Helper loaded: common_helper
DEBUG - 2014-07-11 18:32:46 --> Database Driver Class Initialized
ERROR - 2014-07-11 18:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 18:32:46 --> Session Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Helper loaded: string_helper
DEBUG - 2014-07-11 18:32:46 --> Session routines successfully run
DEBUG - 2014-07-11 18:32:46 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 18:32:46 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 18:32:46 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 18:32:46 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Controller Class Initialized
DEBUG - 2014-07-11 18:32:46 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 18:32:46 --> Helper loaded: form_helper
DEBUG - 2014-07-11 18:32:46 --> Form Validation Class Initialized
DEBUG - 2014-07-11 18:32:46 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 18:32:46 --> Final output sent to browser
DEBUG - 2014-07-11 18:32:46 --> Total execution time: 0.1680
DEBUG - 2014-07-11 18:32:49 --> Config Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Hooks Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Utf8 Class Initialized
DEBUG - 2014-07-11 18:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-11 18:32:49 --> URI Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Router Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Output Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Security Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Input Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-11 18:32:49 --> Language Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Language Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Config Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Loader Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Helper loaded: url_helper
DEBUG - 2014-07-11 18:32:49 --> Helper loaded: common_helper
DEBUG - 2014-07-11 18:32:49 --> Database Driver Class Initialized
ERROR - 2014-07-11 18:32:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-11 18:32:49 --> Session Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Helper loaded: string_helper
DEBUG - 2014-07-11 18:32:49 --> Session routines successfully run
DEBUG - 2014-07-11 18:32:49 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-11 18:32:49 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-11 18:32:49 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-11 18:32:49 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Model Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Controller Class Initialized
DEBUG - 2014-07-11 18:32:49 --> Payment MX_Controller Initialized
DEBUG - 2014-07-11 18:32:49 --> Helper loaded: form_helper
DEBUG - 2014-07-11 18:32:49 --> Form Validation Class Initialized
DEBUG - 2014-07-11 18:32:49 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-11 18:32:49 --> Final output sent to browser
DEBUG - 2014-07-11 18:32:49 --> Total execution time: 0.1670
