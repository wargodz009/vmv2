<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-12 21:05:03 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Hooks Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Hooks Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Utf8 Class Initialized
DEBUG - 2014-07-12 21:05:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 21:05:03 --> Utf8 Class Initialized
DEBUG - 2014-07-12 21:05:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 21:05:03 --> URI Class Initialized
DEBUG - 2014-07-12 21:05:03 --> URI Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Router Class Initialized
DEBUG - 2014-07-12 21:05:03 --> No URI present. Default controller set.
DEBUG - 2014-07-12 21:05:03 --> Router Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Output Class Initialized
DEBUG - 2014-07-12 21:05:03 --> No URI present. Default controller set.
DEBUG - 2014-07-12 21:05:03 --> Output Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Security Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Security Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Input Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 21:05:03 --> Input Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 21:05:03 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Loader Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Loader Class Initialized
DEBUG - 2014-07-12 21:05:03 --> Helper loaded: url_helper
DEBUG - 2014-07-12 21:05:03 --> Helper loaded: common_helper
DEBUG - 2014-07-12 21:05:03 --> Helper loaded: url_helper
DEBUG - 2014-07-12 21:05:03 --> Helper loaded: common_helper
DEBUG - 2014-07-12 21:05:04 --> Database Driver Class Initialized
ERROR - 2014-07-12 21:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-12 21:05:04 --> Database Driver Class Initialized
ERROR - 2014-07-12 21:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-12 21:05:04 --> Session Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Session Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Helper loaded: string_helper
DEBUG - 2014-07-12 21:05:04 --> A session cookie was not found.
DEBUG - 2014-07-12 21:05:04 --> Session routines successfully run
DEBUG - 2014-07-12 21:05:04 --> Helper loaded: string_helper
DEBUG - 2014-07-12 21:05:04 --> A session cookie was not found.
DEBUG - 2014-07-12 21:05:04 --> Session routines successfully run
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Controller Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Controller Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Site MX_Controller Initialized
DEBUG - 2014-07-12 21:05:04 --> Site MX_Controller Initialized
DEBUG - 2014-07-12 21:05:04 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Hooks Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Utf8 Class Initialized
DEBUG - 2014-07-12 21:05:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 21:05:04 --> URI Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Router Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Output Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Security Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Input Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 21:05:04 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Loader Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Helper loaded: url_helper
DEBUG - 2014-07-12 21:05:04 --> Helper loaded: common_helper
DEBUG - 2014-07-12 21:05:04 --> Database Driver Class Initialized
ERROR - 2014-07-12 21:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-12 21:05:04 --> Session Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Helper loaded: string_helper
DEBUG - 2014-07-12 21:05:04 --> Session routines successfully run
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Controller Class Initialized
DEBUG - 2014-07-12 21:05:04 --> Site MX_Controller Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-12 21:05:04 --> Menu MX_Controller Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-12 21:05:04 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-12 21:05:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-12 21:05:04 --> Final output sent to browser
DEBUG - 2014-07-12 21:05:04 --> Total execution time: 0.1670
DEBUG - 2014-07-12 21:05:26 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Hooks Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Utf8 Class Initialized
DEBUG - 2014-07-12 21:05:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 21:05:26 --> URI Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Router Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Output Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Security Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Input Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 21:05:26 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Loader Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Helper loaded: url_helper
DEBUG - 2014-07-12 21:05:26 --> Helper loaded: common_helper
DEBUG - 2014-07-12 21:05:26 --> Database Driver Class Initialized
ERROR - 2014-07-12 21:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-12 21:05:26 --> Session Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Helper loaded: string_helper
DEBUG - 2014-07-12 21:05:26 --> Session routines successfully run
DEBUG - 2014-07-12 21:05:26 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-12 21:05:26 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-12 21:05:26 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-12 21:05:26 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Controller Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Site MX_Controller Initialized
DEBUG - 2014-07-12 21:05:26 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Hooks Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Utf8 Class Initialized
DEBUG - 2014-07-12 21:05:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 21:05:26 --> URI Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Router Class Initialized
DEBUG - 2014-07-12 21:05:26 --> No URI present. Default controller set.
DEBUG - 2014-07-12 21:05:26 --> Output Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Security Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Input Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 21:05:26 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:26 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:27 --> Loader Class Initialized
DEBUG - 2014-07-12 21:05:27 --> Helper loaded: url_helper
DEBUG - 2014-07-12 21:05:27 --> Helper loaded: common_helper
DEBUG - 2014-07-12 21:05:27 --> Database Driver Class Initialized
ERROR - 2014-07-12 21:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-12 21:05:27 --> Session Class Initialized
DEBUG - 2014-07-12 21:05:27 --> Helper loaded: string_helper
DEBUG - 2014-07-12 21:05:27 --> Session routines successfully run
DEBUG - 2014-07-12 21:05:27 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-12 21:05:27 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-12 21:05:27 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-12 21:05:27 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:27 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:27 --> Controller Class Initialized
DEBUG - 2014-07-12 21:05:27 --> Site MX_Controller Initialized
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-12 21:05:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-12 21:05:27 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-12 21:05:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-12 21:05:27 --> Final output sent to browser
DEBUG - 2014-07-12 21:05:27 --> Total execution time: 0.3020
DEBUG - 2014-07-12 21:05:53 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Hooks Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Utf8 Class Initialized
DEBUG - 2014-07-12 21:05:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-12 21:05:53 --> URI Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Router Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Output Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Security Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Input Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-12 21:05:53 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Language Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Config Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Loader Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Helper loaded: url_helper
DEBUG - 2014-07-12 21:05:53 --> Helper loaded: common_helper
DEBUG - 2014-07-12 21:05:53 --> Database Driver Class Initialized
ERROR - 2014-07-12 21:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-12 21:05:53 --> Session Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Helper loaded: string_helper
DEBUG - 2014-07-12 21:05:53 --> Session routines successfully run
DEBUG - 2014-07-12 21:05:53 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-12 21:05:53 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-12 21:05:53 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-12 21:05:53 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Controller Class Initialized
DEBUG - 2014-07-12 21:05:53 --> Order MX_Controller Initialized
DEBUG - 2014-07-12 21:05:53 --> Helper loaded: form_helper
DEBUG - 2014-07-12 21:05:53 --> Form Validation Class Initialized
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-12 21:05:53 --> Menu MX_Controller Initialized
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-12 21:05:53 --> Model Class Initialized
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-12 21:05:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-12 21:05:53 --> Final output sent to browser
DEBUG - 2014-07-12 21:05:53 --> Total execution time: 0.2870
