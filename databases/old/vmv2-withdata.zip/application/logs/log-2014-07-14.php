<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-14 00:01:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:01:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:01:04 --> URI Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Router Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Output Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Security Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Input Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:01:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Loader Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:01:04 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:01:04 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:01:04 --> Session Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:01:04 --> Session routines successfully run
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Controller Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:01:04 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:01:04 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:01:05 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:01:05 --> Final output sent to browser
DEBUG - 2014-07-14 00:01:05 --> Total execution time: 0.2400
DEBUG - 2014-07-14 00:01:05 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:01:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:01:05 --> URI Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Router Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Output Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Security Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Input Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:01:05 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Loader Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:01:05 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:01:05 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:01:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:01:05 --> Session Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:01:05 --> Session routines successfully run
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Controller Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:01:05 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:01:05 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:01:06 --> URI Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Router Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Output Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Security Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Input Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:01:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Loader Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:01:06 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:01:06 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:01:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:01:06 --> Session Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:01:06 --> Session routines successfully run
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:01:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:01:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:01:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:01:21 --> URI Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Router Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Output Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Security Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Input Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:01:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Loader Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:01:21 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:01:21 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:01:21 --> Session Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:01:21 --> Session routines successfully run
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Controller Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:01:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:01:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:01:21 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:01:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:01:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:01:21 --> Final output sent to browser
DEBUG - 2014-07-14 00:01:21 --> Total execution time: 0.2090
DEBUG - 2014-07-14 00:01:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:01:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:01:24 --> URI Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Router Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Output Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Security Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Input Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:01:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Loader Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:01:24 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:01:24 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:01:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:01:24 --> Session Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:01:24 --> Session routines successfully run
DEBUG - 2014-07-14 00:01:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:01:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:01:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:01:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Controller Class Initialized
DEBUG - 2014-07-14 00:01:24 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:01:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:01:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:01:24 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:01:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:01:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:01:24 --> Final output sent to browser
DEBUG - 2014-07-14 00:01:24 --> Total execution time: 0.1640
DEBUG - 2014-07-14 00:01:41 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:01:41 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:01:41 --> URI Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Router Class Initialized
DEBUG - 2014-07-14 00:01:41 --> No URI present. Default controller set.
DEBUG - 2014-07-14 00:01:41 --> Output Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Security Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Input Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:01:41 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Language Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Config Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Loader Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:01:41 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:01:41 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:01:41 --> Session Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:01:41 --> Session routines successfully run
DEBUG - 2014-07-14 00:01:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:01:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:01:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:01:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Controller Class Initialized
DEBUG - 2014-07-14 00:01:41 --> Site MX_Controller Initialized
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:01:41 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:01:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:01:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:01:41 --> Final output sent to browser
DEBUG - 2014-07-14 00:01:41 --> Total execution time: 0.2360
DEBUG - 2014-07-14 00:02:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:02:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:02:32 --> URI Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Router Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Output Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Security Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Input Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:02:32 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Loader Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:02:32 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:02:32 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:02:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:02:32 --> Session Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:02:32 --> Session routines successfully run
DEBUG - 2014-07-14 00:02:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:02:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:02:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:02:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Controller Class Initialized
DEBUG - 2014-07-14 00:02:32 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:02:32 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:02:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:02:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:02:39 --> URI Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:02:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:02:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:02:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:02:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:02:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:02:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:02:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:02:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:02:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:02:39 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:02:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:02:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:02:39 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:02:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:02:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:02:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:02:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:02:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:02:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:02:40 --> Final output sent to browser
DEBUG - 2014-07-14 00:02:40 --> Total execution time: 0.3680
DEBUG - 2014-07-14 00:02:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:02:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:02:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:02:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:02:53 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:02:53 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:02:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:02:53 --> Session Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:02:53 --> Session routines successfully run
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:02:53 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:02:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:02:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:02:53 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:02:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:02:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:02:53 --> Final output sent to browser
DEBUG - 2014-07-14 00:02:53 --> Total execution time: 0.2210
DEBUG - 2014-07-14 00:02:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:02:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:02:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:02:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:02:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Security Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Input Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:02:55 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Loader Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:02:55 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:02:55 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:02:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:02:55 --> Session Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:02:55 --> Session routines successfully run
DEBUG - 2014-07-14 00:02:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:02:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:02:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:02:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Controller Class Initialized
DEBUG - 2014-07-14 00:02:55 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:02:55 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:02:55 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:02:55 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:02:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:02:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:02:55 --> Final output sent to browser
DEBUG - 2014-07-14 00:02:55 --> Total execution time: 0.2150
DEBUG - 2014-07-14 00:02:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:02:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:02:56 --> URI Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Router Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Output Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Security Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Input Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:02:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Loader Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:02:56 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:02:56 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:02:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:02:56 --> Session Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:02:56 --> Session routines successfully run
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Controller Class Initialized
DEBUG - 2014-07-14 00:02:56 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:02:56 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:02:56 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:02:56 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:02:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:02:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:02:56 --> Final output sent to browser
DEBUG - 2014-07-14 00:02:56 --> Total execution time: 0.2730
DEBUG - 2014-07-14 00:02:57 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:02:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:02:57 --> URI Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Router Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Output Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Security Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Input Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:02:57 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Language Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Config Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Loader Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:02:57 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:02:57 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:02:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:02:57 --> Session Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:02:57 --> Session routines successfully run
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Controller Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:02:57 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:02:57 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:02:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:02:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:02:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:02:58 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:02:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:02:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:02:58 --> Final output sent to browser
DEBUG - 2014-07-14 00:02:58 --> Total execution time: 0.2980
DEBUG - 2014-07-14 00:03:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:00 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:00 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:00 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:00 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:00 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:00 --> Inventory MX_Controller Initialized
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:00 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:00 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:00 --> Total execution time: 0.1670
DEBUG - 2014-07-14 00:03:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:01 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:01 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:01 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:01 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:01 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:01 --> Employee MX_Controller Initialized
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:01 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:01 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:01 --> Total execution time: 0.1690
DEBUG - 2014-07-14 00:03:02 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:02 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:02 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:02 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:02 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:02 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:02 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:02 --> Client MX_Controller Initialized
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:02 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:02 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:02 --> Total execution time: 0.1700
DEBUG - 2014-07-14 00:03:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:04 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:04 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:04 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:04 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:04 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:04 --> User MX_Controller Initialized
DEBUG - 2014-07-14 00:03:04 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:03:04 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:04 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:04 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:04 --> Total execution time: 0.3250
DEBUG - 2014-07-14 00:03:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:06 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:06 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:06 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:06 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:06 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:06 --> Report MX_Controller Initialized
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:06 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:06 --> Total execution time: 0.1880
DEBUG - 2014-07-14 00:03:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:07 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:07 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:07 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:07 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:07 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:03:07 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:03:07 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:07 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:07 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:07 --> Total execution time: 0.2970
DEBUG - 2014-07-14 00:03:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:15 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:15 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:15 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:15 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:15 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:15 --> Inventory MX_Controller Initialized
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:15 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:15 --> Total execution time: 0.1920
DEBUG - 2014-07-14 00:03:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:03:17 --> URI Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Router Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Output Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Security Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Input Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:03:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Loader Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:03:17 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:03:17 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:03:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:03:17 --> Session Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:03:17 --> Session routines successfully run
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Controller Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:03:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:03:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:03:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:03:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:03:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:03:17 --> Final output sent to browser
DEBUG - 2014-07-14 00:03:17 --> Total execution time: 0.3060
DEBUG - 2014-07-14 00:10:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:08 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:08 --> No URI present. Default controller set.
DEBUG - 2014-07-14 00:10:08 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:08 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:08 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:08 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:08 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:08 --> Site MX_Controller Initialized
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:08 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:08 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:08 --> Total execution time: 0.2230
DEBUG - 2014-07-14 00:10:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:10 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:10 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:10 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:10 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:10 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:10 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:10:10 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:10 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:10 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:10 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:10 --> Total execution time: 0.2540
DEBUG - 2014-07-14 00:10:12 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:12 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:12 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:12 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:12 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:12 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:12 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:10:12 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:12 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:12 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:12 --> Total execution time: 0.3370
DEBUG - 2014-07-14 00:10:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:17 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:17 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:17 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:17 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:17 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:17 --> Inventory MX_Controller Initialized
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:17 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:17 --> Total execution time: 0.2130
DEBUG - 2014-07-14 00:10:19 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:19 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:19 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:19 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:19 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:19 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:19 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:10:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:19 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:19 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:19 --> Total execution time: 0.3090
DEBUG - 2014-07-14 00:10:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:20 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:20 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:20 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:20 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:20 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:20 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:20 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:20 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:10:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:21 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:21 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:21 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:21 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:21 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:10:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:21 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:21 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:21 --> Total execution time: 0.3060
DEBUG - 2014-07-14 00:10:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:22 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:22 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:23 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:23 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:23 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:23 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:10:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:23 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:23 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:23 --> Total execution time: 0.2840
DEBUG - 2014-07-14 00:10:38 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:38 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:38 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:38 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:38 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:38 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:38 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:10:38 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:38 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:10:38 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:38 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:38 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:10:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:39 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:10:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:39 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:39 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:39 --> Total execution time: 0.3550
DEBUG - 2014-07-14 00:10:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:42 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:10:42 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:10:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:10:43 --> URI Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Router Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Output Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Security Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Input Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:10:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Loader Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:10:43 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:10:43 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:10:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:10:43 --> Session Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:10:43 --> Session routines successfully run
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Controller Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:10:43 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:10:43 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:10:43 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:10:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:10:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:10:43 --> Final output sent to browser
DEBUG - 2014-07-14 00:10:43 --> Total execution time: 0.3240
DEBUG - 2014-07-14 00:11:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:00 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:00 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:00 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:00 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:00 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:11:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:00 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:00 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:00 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:00 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:11:00 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:00 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:11:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:01 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:01 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:01 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:01 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:01 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:11:01 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:01 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:11:01 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:11:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:11:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:11:01 --> Final output sent to browser
DEBUG - 2014-07-14 00:11:01 --> Total execution time: 0.3730
DEBUG - 2014-07-14 00:11:03 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:03 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:03 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:03 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:03 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:03 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:03 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Supplier MX_Controller Initialized
DEBUG - 2014-07-14 00:11:03 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:03 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:11:03 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:11:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:11:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:11:03 --> Final output sent to browser
DEBUG - 2014-07-14 00:11:03 --> Total execution time: 0.2940
DEBUG - 2014-07-14 00:11:05 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:05 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:05 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:05 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:05 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:05 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:05 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:06 --> Supplier MX_Controller Initialized
DEBUG - 2014-07-14 00:11:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:11:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:11:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:11:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:11:06 --> Final output sent to browser
DEBUG - 2014-07-14 00:11:06 --> Total execution time: 0.3270
DEBUG - 2014-07-14 00:11:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:11 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:11 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:11 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:11 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:11 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Supplier MX_Controller Initialized
DEBUG - 2014-07-14 00:11:11 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:11:12 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:12 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:12 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:12 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:12 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:12 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:12 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Supplier MX_Controller Initialized
DEBUG - 2014-07-14 00:11:12 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:11:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:13 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:13 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:13 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:13 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:13 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Supplier MX_Controller Initialized
DEBUG - 2014-07-14 00:11:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:11:13 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:11:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:11:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:11:13 --> Final output sent to browser
DEBUG - 2014-07-14 00:11:13 --> Total execution time: 0.4500
DEBUG - 2014-07-14 00:11:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:14 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:14 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:14 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:14 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:14 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:14 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:11:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:11:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:11:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:11:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:11:15 --> Final output sent to browser
DEBUG - 2014-07-14 00:11:15 --> Total execution time: 0.3590
DEBUG - 2014-07-14 00:11:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:15 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:15 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:15 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:15 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:15 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:16 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:16 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:16 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:16 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:16 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:16 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:16 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:16 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:16 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:16 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:16 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:11:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:11:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:11:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:11:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:11:16 --> Final output sent to browser
DEBUG - 2014-07-14 00:11:16 --> Total execution time: 0.3090
DEBUG - 2014-07-14 00:11:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:56 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:56 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:56 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:56 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:56 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:11:56 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:56 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:11:57 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:11:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:11:57 --> URI Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Router Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Output Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Security Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Input Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:11:57 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Language Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Config Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Loader Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:11:57 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:11:57 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:11:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:11:57 --> Session Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:11:57 --> Session routines successfully run
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Controller Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:11:57 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:11:57 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:11:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:11:57 --> DB Transaction Failure
ERROR - 2014-07-14 00:11:57 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:11:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:12:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:12:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:12:35 --> URI Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Router Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Output Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Security Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Input Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:12:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Loader Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:12:35 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:12:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:12:35 --> Session Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:12:35 --> Session routines successfully run
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Controller Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:12:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:12:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:12:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:12:35 --> URI Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Router Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Output Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Security Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Input Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:12:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Loader Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:12:35 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:12:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:12:35 --> Session Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:12:35 --> Session routines successfully run
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Controller Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:12:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:12:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:12:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:12:35 --> DB Transaction Failure
ERROR - 2014-07-14 00:12:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:12:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:13:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:13:30 --> URI Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Router Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Output Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Security Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Input Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:13:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Loader Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:13:30 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:13:30 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:13:30 --> Session Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:13:30 --> Session routines successfully run
DEBUG - 2014-07-14 00:13:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:13:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:13:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:13:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Controller Class Initialized
DEBUG - 2014-07-14 00:13:30 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:13:31 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:13:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:13:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:13:31 --> URI Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Router Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Output Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Security Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Input Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:13:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Loader Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:13:31 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:13:31 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:13:31 --> Session Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:13:31 --> Session routines successfully run
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Controller Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:13:31 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:13:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:13:31 --> DB Transaction Failure
ERROR - 2014-07-14 00:13:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:13:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:13:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:13:34 --> URI Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Router Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Output Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Security Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Input Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:13:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Loader Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:13:34 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:13:34 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:13:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:13:34 --> Session Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:13:34 --> Session routines successfully run
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Controller Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:13:34 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:13:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:13:34 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:13:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:13:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:13:34 --> Final output sent to browser
DEBUG - 2014-07-14 00:13:34 --> Total execution time: 0.3560
DEBUG - 2014-07-14 00:13:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:13:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:13:35 --> URI Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Router Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Output Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Security Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Input Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:13:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Loader Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:13:35 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:13:35 --> Session Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:13:35 --> Session routines successfully run
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Controller Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:13:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:13:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:13:35 --> URI Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Router Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Output Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Security Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Input Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:13:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Loader Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:13:35 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:13:35 --> Session Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:13:35 --> Session routines successfully run
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Controller Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:13:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:13:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:13:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:13:37 --> URI Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Router Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Output Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Security Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Input Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:13:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Loader Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:13:37 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:13:37 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:13:37 --> Session Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:13:37 --> Session routines successfully run
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Controller Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:13:37 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:13:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:13:37 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:13:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:13:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:13:37 --> Final output sent to browser
DEBUG - 2014-07-14 00:13:37 --> Total execution time: 0.2880
DEBUG - 2014-07-14 00:14:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:14:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:14:06 --> URI Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Router Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Output Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Security Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Input Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:14:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Loader Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:14:06 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:14:06 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:14:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:14:06 --> Session Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:14:06 --> Session routines successfully run
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:14:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:14:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:14:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:14:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:14:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:14:07 --> URI Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Router Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Output Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Security Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Input Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:14:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Loader Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:14:07 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:14:07 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:14:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:14:07 --> Session Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:14:07 --> Session routines successfully run
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Controller Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:14:07 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:14:07 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:14:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:14:07 --> DB Transaction Failure
ERROR - 2014-07-14 00:14:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:14:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:15:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:15:43 --> URI Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Router Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Output Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Security Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Input Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:15:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Loader Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:15:43 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:15:43 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:15:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:15:43 --> Session Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:15:43 --> Session routines successfully run
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Controller Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:15:43 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:15:43 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:15:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:15:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:15:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:15:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:15:44 --> Final output sent to browser
DEBUG - 2014-07-14 00:15:44 --> Total execution time: 0.2960
DEBUG - 2014-07-14 00:16:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:16:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:16:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:16:07 --> URI Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Router Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Output Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Security Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Input Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:16:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Loader Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:16:08 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:16:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:16:08 --> Session Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:16:08 --> Session routines successfully run
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Controller Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:16:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:16:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:16:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:16:08 --> URI Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Router Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Output Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Security Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Input Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:16:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Loader Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:16:08 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:16:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:16:08 --> Session Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:16:08 --> Session routines successfully run
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Controller Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:16:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:16:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:16:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:16:08 --> DB Transaction Failure
ERROR - 2014-07-14 00:16:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:16:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:17:16 --> Config Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:17:16 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:17:16 --> URI Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Router Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Output Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Security Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Input Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:17:16 --> Language Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Language Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Config Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Loader Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:17:16 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:17:16 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:17:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:17:16 --> Session Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:17:16 --> Session routines successfully run
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Controller Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:17:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:17:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:17:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:17:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:17:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:17:16 --> Final output sent to browser
DEBUG - 2014-07-14 00:17:16 --> Total execution time: 0.2940
DEBUG - 2014-07-14 00:17:36 --> Config Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:17:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:17:36 --> URI Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Router Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Output Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Security Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Input Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:17:36 --> Language Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Language Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Config Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Loader Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:17:36 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:17:36 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:17:36 --> Session Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:17:36 --> Session routines successfully run
DEBUG - 2014-07-14 00:17:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:17:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:17:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:17:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Controller Class Initialized
DEBUG - 2014-07-14 00:17:36 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:17:37 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:17:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:17:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:17:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:17:37 --> URI Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Router Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Output Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Security Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Input Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:17:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Loader Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:17:37 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:17:37 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:17:37 --> Session Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:17:37 --> Session routines successfully run
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Controller Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:17:37 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:17:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:17:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:17:37 --> DB Transaction Failure
ERROR - 2014-07-14 00:17:37 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:17:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:19:47 --> Config Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:19:47 --> URI Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Router Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Output Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Security Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Input Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:19:47 --> Language Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Language Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Config Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Loader Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:19:47 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:19:47 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:19:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:19:47 --> Session Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:19:47 --> Session routines successfully run
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Controller Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:19:47 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:19:47 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:19:47 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:19:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:19:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:19:47 --> Final output sent to browser
DEBUG - 2014-07-14 00:19:47 --> Total execution time: 0.3090
DEBUG - 2014-07-14 00:20:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:26 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:26 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:26 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:26 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:20:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:26 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:26 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:26 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:26 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:20:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:27 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:27 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:27 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:27 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:27 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:20:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:20:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:20:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:20:27 --> Final output sent to browser
DEBUG - 2014-07-14 00:20:27 --> Total execution time: 0.3750
DEBUG - 2014-07-14 00:20:28 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:28 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:28 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:28 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:28 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:28 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:28 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:29 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:29 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:29 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:29 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:29 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:29 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:29 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:29 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:49 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:49 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:49 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:49 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:49 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:49 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:50 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:50 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:50 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:50 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:50 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:50 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:50 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:50 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:50 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:50 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:50 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:20:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:20:51 --> URI Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Router Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Output Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Security Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Input Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:20:51 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Language Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Config Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Loader Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:20:51 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:20:51 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:20:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:20:51 --> Session Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:20:51 --> Session routines successfully run
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Controller Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:20:51 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:20:51 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:20:52 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:20:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:20:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:20:52 --> Final output sent to browser
DEBUG - 2014-07-14 00:20:52 --> Total execution time: 0.2840
DEBUG - 2014-07-14 00:21:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:21:26 --> URI Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Router Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Output Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Security Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Input Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:21:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Loader Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:21:26 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:21:26 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:21:26 --> Session Class Initialized
DEBUG - 2014-07-14 00:21:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:21:26 --> Session routines successfully run
DEBUG - 2014-07-14 00:21:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Controller Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:21:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:21:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:21:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:21:27 --> URI Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Router Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Output Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Security Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Input Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:21:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Loader Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:21:27 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:21:27 --> Session Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:21:27 --> Session routines successfully run
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Controller Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:21:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:21:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:21:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:21:27 --> URI Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Router Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Output Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Security Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Input Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:21:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Loader Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:21:27 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:21:27 --> Session Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:21:27 --> Session routines successfully run
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Controller Class Initialized
DEBUG - 2014-07-14 00:21:27 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:21:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:21:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:21:28 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:21:28 --> Final output sent to browser
DEBUG - 2014-07-14 00:21:28 --> Total execution time: 0.3690
DEBUG - 2014-07-14 00:21:28 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:21:28 --> URI Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Router Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Output Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Security Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Input Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:21:28 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Loader Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:21:28 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:21:28 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:21:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:21:28 --> Session Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:21:28 --> Session routines successfully run
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Controller Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:21:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:21:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:21:29 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:21:29 --> URI Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Router Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Output Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Security Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Input Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:21:29 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Language Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Config Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Loader Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:21:29 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:21:29 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:21:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:21:29 --> Session Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:21:29 --> Session routines successfully run
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Controller Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:21:29 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:21:29 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:21:29 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:22:13 --> URI Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Router Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Output Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Security Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Input Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:22:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Loader Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:22:13 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:22:13 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:22:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:22:13 --> Session Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:22:13 --> Session routines successfully run
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Controller Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:22:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:22:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:22:14 --> URI Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Router Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Output Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Security Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Input Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:22:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Loader Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:22:14 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:22:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:22:14 --> Session Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:22:14 --> Session routines successfully run
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Controller Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:22:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:22:14 --> URI Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Router Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Output Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Security Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Input Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:22:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Loader Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:22:14 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:22:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:22:14 --> Session Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:22:14 --> Session routines successfully run
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Controller Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:22:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:22:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:22:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:22:46 --> URI Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Router Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Output Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Security Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Input Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:22:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Loader Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:22:46 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:22:46 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:22:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:22:46 --> Session Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:22:46 --> Session routines successfully run
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Controller Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:22:46 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:22:46 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:22:46 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:22:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:22:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:22:46 --> Final output sent to browser
DEBUG - 2014-07-14 00:22:46 --> Total execution time: 0.2940
DEBUG - 2014-07-14 00:23:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:23:34 --> URI Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Router Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Output Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Security Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Input Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:23:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Loader Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:23:34 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:23:34 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:23:34 --> Session Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:23:34 --> Session routines successfully run
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Controller Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:23:34 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:23:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:23:34 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:23:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:23:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:23:34 --> Final output sent to browser
DEBUG - 2014-07-14 00:23:34 --> Total execution time: 0.2910
DEBUG - 2014-07-14 00:23:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:23:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:23:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:23:53 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:23:53 --> Session Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:23:53 --> Session routines successfully run
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:23:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:23:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:23:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:23:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:23:53 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:23:53 --> Session Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:23:53 --> Session routines successfully run
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:23:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:23:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:23:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:23:53 --> DB Transaction Failure
ERROR - 2014-07-14 00:23:53 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:23:53 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:25:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:25:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:25:14 --> URI Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Router Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Output Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Security Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Input Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:25:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Loader Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:25:14 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:25:14 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:25:14 --> Session Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:25:14 --> Session routines successfully run
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Controller Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:25:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:25:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:25:14 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:25:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:25:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:25:14 --> Final output sent to browser
DEBUG - 2014-07-14 00:25:14 --> Total execution time: 0.2900
DEBUG - 2014-07-14 00:25:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:25:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:25:33 --> URI Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Router Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Output Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Security Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Input Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:25:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Loader Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:25:33 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:25:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:25:33 --> Session Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:25:33 --> Session routines successfully run
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Controller Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:25:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:25:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:25:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:25:33 --> URI Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Router Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Output Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Security Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Input Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:25:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Loader Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:25:33 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:25:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:25:33 --> Session Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:25:33 --> Session routines successfully run
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Controller Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:25:33 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:25:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:25:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:25:33 --> DB Transaction Failure
ERROR - 2014-07-14 00:25:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:25:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:25:50 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:25:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:25:50 --> URI Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Router Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Output Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Security Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Input Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:25:50 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Language Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Config Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Loader Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:25:50 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:25:50 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:25:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:25:50 --> Session Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:25:50 --> Session routines successfully run
DEBUG - 2014-07-14 00:25:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:25:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:25:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:25:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Controller Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:25:50 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:25:50 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:25:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:25:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:25:51 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:25:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:25:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:25:51 --> Final output sent to browser
DEBUG - 2014-07-14 00:25:51 --> Total execution time: 0.2860
DEBUG - 2014-07-14 00:26:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:26:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:26:37 --> URI Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Router Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Output Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Security Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Input Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:26:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Loader Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:26:37 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:26:37 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:26:37 --> Session Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:26:37 --> Session routines successfully run
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Controller Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:26:37 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:26:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:26:38 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:26:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:26:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:26:38 --> Final output sent to browser
DEBUG - 2014-07-14 00:26:38 --> Total execution time: 0.2930
DEBUG - 2014-07-14 00:27:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:27:10 --> URI Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Router Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Output Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Security Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Input Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:27:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Loader Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:27:10 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:27:10 --> Session Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:27:10 --> Session routines successfully run
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Controller Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:27:10 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:27:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:27:10 --> URI Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Router Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Output Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Security Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Input Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:27:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Loader Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:27:10 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:27:10 --> Session Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:27:10 --> Session routines successfully run
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Controller Class Initialized
DEBUG - 2014-07-14 00:27:10 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:27:11 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:27:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:27:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:27:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:27:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:27:11 --> DB Transaction Failure
ERROR - 2014-07-14 00:27:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`batch`, CONSTRAINT `FK__user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`))
DEBUG - 2014-07-14 00:27:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-07-14 00:27:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:27:30 --> URI Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Router Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Output Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Security Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Input Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:27:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Loader Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:27:30 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:27:30 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:27:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:27:30 --> Session Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:27:30 --> Session routines successfully run
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Controller Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:27:30 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:27:30 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:27:30 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:27:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:27:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:27:30 --> Final output sent to browser
DEBUG - 2014-07-14 00:27:30 --> Total execution time: 0.2860
DEBUG - 2014-07-14 00:28:12 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:12 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:12 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:12 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:12 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:12 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:12 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:12 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:12 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:12 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:28:12 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:28:12 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:28:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:28:12 --> Final output sent to browser
DEBUG - 2014-07-14 00:28:12 --> Total execution time: 0.2920
DEBUG - 2014-07-14 00:28:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:34 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:34 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:34 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:34 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:28:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:34 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:34 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:34 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:34 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:34 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:34 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:34 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:34 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:28:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:35 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:35 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:35 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:35 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:35 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:35 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:35 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:35 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:28:35 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:28:35 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:28:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:28:35 --> Final output sent to browser
DEBUG - 2014-07-14 00:28:35 --> Total execution time: 0.4040
DEBUG - 2014-07-14 00:28:36 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:36 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:36 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:36 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:36 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:36 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:36 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:36 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:36 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:36 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:36 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:36 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:36 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:36 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:36 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:44 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:44 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:44 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:44 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:44 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:44 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:44 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:28:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:28:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:28:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:28:44 --> Final output sent to browser
DEBUG - 2014-07-14 00:28:44 --> Total execution time: 0.3040
DEBUG - 2014-07-14 00:28:52 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:52 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:52 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:52 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:52 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:52 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:52 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:52 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:52 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:52 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:28:53 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:28:53 --> Final output sent to browser
DEBUG - 2014-07-14 00:28:53 --> Total execution time: 0.3190
DEBUG - 2014-07-14 00:28:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:53 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:53 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:53 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:53 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:28:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:28:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:28:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:28:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:28:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:28:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:28:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:28:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:28:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:28:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:54 --> Controller Class Initialized
DEBUG - 2014-07-14 00:28:54 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:28:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:28:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:28:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:28:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:06 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:06 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:06 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:06 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:06 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:29:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:06 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:06 --> Total execution time: 0.3060
DEBUG - 2014-07-14 00:29:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:31 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:31 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:31 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:31 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:29:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:31 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:31 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:31 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:31 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:29:31 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-07-14 00:29:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:32 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:32 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:32 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:32 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:32 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:32 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:29:32 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:32 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:32 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:32 --> Total execution time: 0.4140
DEBUG - 2014-07-14 00:29:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:33 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:33 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:33 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:33 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:33 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:33 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:33 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:33 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:29:33 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:45 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:45 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:45 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:45 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:45 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:45 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:29:45 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:45 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:45 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:45 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:45 --> Total execution time: 0.2690
DEBUG - 2014-07-14 00:29:47 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:47 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:47 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:47 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:47 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:47 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:47 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:29:47 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:47 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:47 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:47 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:47 --> Total execution time: 0.3510
DEBUG - 2014-07-14 00:29:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:49 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:49 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:49 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:49 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:29:49 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:49 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:49 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:49 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:49 --> Total execution time: 0.2990
DEBUG - 2014-07-14 00:29:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:56 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:56 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:56 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:56 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:56 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:56 --> Client MX_Controller Initialized
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:56 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:56 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:56 --> Total execution time: 0.2320
DEBUG - 2014-07-14 00:29:58 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:29:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:29:58 --> URI Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Router Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Output Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Security Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Input Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:29:58 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Language Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Config Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Loader Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:29:58 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:29:58 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:29:58 --> Session Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:29:58 --> Session routines successfully run
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Controller Class Initialized
DEBUG - 2014-07-14 00:29:58 --> User MX_Controller Initialized
DEBUG - 2014-07-14 00:29:58 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:29:58 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:29:58 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:29:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:29:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:29:58 --> Final output sent to browser
DEBUG - 2014-07-14 00:29:58 --> Total execution time: 0.3370
DEBUG - 2014-07-14 00:30:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:00 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:01 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:01 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:01 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:01 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:01 --> Employee MX_Controller Initialized
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:01 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:01 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:01 --> Total execution time: 0.2190
DEBUG - 2014-07-14 00:30:02 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:02 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:02 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:02 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:02 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:02 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:02 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:02 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:02 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:03 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:03 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:03 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:03 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:03 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:03 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:03 --> Total execution time: 0.3210
DEBUG - 2014-07-14 00:30:05 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:05 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:05 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:05 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:05 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:05 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:05 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:05 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:05 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:05 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:05 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:06 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:06 --> Total execution time: 0.2850
DEBUG - 2014-07-14 00:30:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:13 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:13 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:13 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:13 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:13 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:14 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:14 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:14 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:14 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:14 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:14 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:14 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:14 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:15 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:15 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:15 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:15 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:15 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:15 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:15 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:15 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:15 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:15 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:15 --> Total execution time: 0.3520
DEBUG - 2014-07-14 00:30:18 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:18 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:18 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:18 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:18 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:18 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:18 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:18 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:18 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:18 --> Total execution time: 0.2830
DEBUG - 2014-07-14 00:30:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:23 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:23 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:23 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:23 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:23 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:23 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:23 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:23 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:23 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:24 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:24 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:24 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:24 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:24 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:24 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:24 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:24 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:24 --> Total execution time: 0.4010
DEBUG - 2014-07-14 00:30:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:27 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:27 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:27 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:27 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:27 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:27 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:27 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:27 --> Total execution time: 0.2870
DEBUG - 2014-07-14 00:30:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:32 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:32 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:32 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:32 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:32 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:32 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:32 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:32 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:32 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:33 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:33 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:33 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:33 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:33 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:33 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:33 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:33 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Msr_client MX_Controller Initialized
DEBUG - 2014-07-14 00:30:33 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:33 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:33 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:33 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:33 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:33 --> Total execution time: 0.3830
DEBUG - 2014-07-14 00:30:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:37 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:37 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:37 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:37 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:37 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:37 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:30:37 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:37 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:37 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:37 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:37 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:37 --> Total execution time: 0.2590
DEBUG - 2014-07-14 00:30:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:39 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:30:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:39 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:39 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:39 --> Total execution time: 0.3610
DEBUG - 2014-07-14 00:30:52 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:30:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:30:52 --> URI Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Router Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Output Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Security Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Input Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:30:52 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Language Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Config Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Loader Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:30:52 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:30:52 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:30:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:30:52 --> Session Class Initialized
DEBUG - 2014-07-14 00:30:52 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:30:52 --> Session routines successfully run
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:30:53 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:30:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:30:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:30:53 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:30:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:30:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:30:53 --> Final output sent to browser
DEBUG - 2014-07-14 00:30:53 --> Total execution time: 0.2830
DEBUG - 2014-07-14 00:31:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:31:07 --> URI Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Router Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Output Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Security Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Input Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:31:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Loader Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:31:07 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:31:07 --> Session Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:31:07 --> Session routines successfully run
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Controller Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:31:07 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:31:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:31:07 --> URI Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Router Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Output Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Security Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Input Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:31:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Loader Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:31:07 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:31:07 --> Session Class Initialized
DEBUG - 2014-07-14 00:31:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:31:07 --> Session routines successfully run
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Controller Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:31:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:31:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:31:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:31:08 --> URI Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Router Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Output Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Security Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Input Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:31:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Loader Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:31:08 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:31:08 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:31:08 --> Session Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:31:08 --> Session routines successfully run
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Controller Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:31:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:31:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:31:08 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:31:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:31:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:31:08 --> Final output sent to browser
DEBUG - 2014-07-14 00:31:08 --> Total execution time: 0.4100
DEBUG - 2014-07-14 00:31:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:10 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:31:10 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:31:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:31:10 --> URI Class Initialized
DEBUG - 2014-07-14 00:31:10 --> Router Class Initialized
DEBUG - 2014-07-14 00:31:10 --> Output Class Initialized
DEBUG - 2014-07-14 00:31:10 --> Security Class Initialized
DEBUG - 2014-07-14 00:31:10 --> Input Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:31:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Loader Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:31:11 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:31:11 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:31:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:31:11 --> Session Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:31:11 --> Session routines successfully run
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Controller Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:31:11 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:31:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:31:11 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:31:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:31:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:31:11 --> Final output sent to browser
DEBUG - 2014-07-14 00:31:11 --> Total execution time: 0.3630
DEBUG - 2014-07-14 00:31:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:31:13 --> URI Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Router Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Output Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Security Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Input Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:31:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Loader Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:31:13 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:31:13 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:31:13 --> Session Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:31:13 --> Session routines successfully run
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Controller Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:31:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:31:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:31:13 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:31:14 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:31:14 --> Model Class Initialized
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:31:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:31:14 --> Final output sent to browser
DEBUG - 2014-07-14 00:31:14 --> Total execution time: 0.3100
DEBUG - 2014-07-14 00:32:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:08 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:08 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:08 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:08 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:08 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:08 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:08 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:08 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:08 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:08 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:08 --> Total execution time: 0.3050
DEBUG - 2014-07-14 00:32:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:22 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:22 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:22 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:22 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:22 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:23 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:23 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:23 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:23 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:23 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:24 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:24 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:24 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:24 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:24 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:24 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:24 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:24 --> Total execution time: 0.3970
DEBUG - 2014-07-14 00:32:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:26 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:26 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:26 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:26 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:26 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:26 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:26 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:26 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:27 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:27 --> Total execution time: 0.3180
DEBUG - 2014-07-14 00:32:38 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:38 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:38 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:38 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:38 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:38 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:38 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:38 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:38 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:38 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:38 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:39 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:39 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:40 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:40 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:40 --> Total execution time: 0.4550
DEBUG - 2014-07-14 00:32:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:42 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:42 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:42 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:42 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:42 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:42 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:42 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:42 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:42 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:42 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:42 --> Total execution time: 0.2930
DEBUG - 2014-07-14 00:32:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:53 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:53 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:53 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:53 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:55 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:55 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:55 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:32:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:55 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:55 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:55 --> Total execution time: 0.4370
DEBUG - 2014-07-14 00:32:57 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:57 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:57 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:57 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:57 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:57 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:57 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:57 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:57 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:32:57 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:57 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:57 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:57 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:57 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:57 --> Total execution time: 0.2620
DEBUG - 2014-07-14 00:32:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:32:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:32:59 --> URI Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Router Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Output Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Security Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Input Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:32:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Loader Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:32:59 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:32:59 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:32:59 --> Session Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:32:59 --> Session routines successfully run
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Controller Class Initialized
DEBUG - 2014-07-14 00:32:59 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:32:59 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:32:59 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:32:59 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:32:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:32:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:32:59 --> Final output sent to browser
DEBUG - 2014-07-14 00:32:59 --> Total execution time: 0.2630
DEBUG - 2014-07-14 00:33:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:01 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:01 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:01 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:01 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:01 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:01 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:33:01 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:01 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:01 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:01 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:01 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:01 --> Total execution time: 0.3540
DEBUG - 2014-07-14 00:33:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:10 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:10 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:10 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:10 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:10 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:33:10 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:10 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:33:10 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:10 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:10 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:11 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:11 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:11 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:11 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:33:11 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:11 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:11 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:11 --> Total execution time: 0.4500
DEBUG - 2014-07-14 00:33:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:17 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:17 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:17 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:17 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:17 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:17 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:17 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:17 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:33:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:17 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:17 --> Total execution time: 0.3680
DEBUG - 2014-07-14 00:33:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:20 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:20 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:20 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:20 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:20 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:20 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:20 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:20 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:20 --> Total execution time: 0.2460
DEBUG - 2014-07-14 00:33:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:21 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:21 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:21 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:21 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:21 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:22 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:22 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:22 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:22 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:22 --> Total execution time: 0.3460
DEBUG - 2014-07-14 00:33:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:23 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:23 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:23 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:23 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:23 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:23 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:23 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:23 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:23 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:23 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:23 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:23 --> Total execution time: 0.2740
DEBUG - 2014-07-14 00:33:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:44 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:44 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:44 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:44 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:44 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:44 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:44 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:44 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:44 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:44 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:44 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:45 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:45 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:45 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:45 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:45 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:45 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:45 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:33:45 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:33:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:33:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:33:45 --> Final output sent to browser
DEBUG - 2014-07-14 00:33:45 --> Total execution time: 0.4240
DEBUG - 2014-07-14 00:33:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:33:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:33:59 --> URI Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Router Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Output Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Security Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Input Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:33:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Loader Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:33:59 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:33:59 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:33:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:33:59 --> Session Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:33:59 --> Session routines successfully run
DEBUG - 2014-07-14 00:33:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:33:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:33:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:33:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Controller Class Initialized
DEBUG - 2014-07-14 00:33:59 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:33:59 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:33:59 --> Form Validation Class Initialized
ERROR - 2014-07-14 00:33:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
ERROR - 2014-07-14 00:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
ERROR - 2014-07-14 00:34:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:34:00 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:34:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:34:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:34:00 --> Final output sent to browser
DEBUG - 2014-07-14 00:34:00 --> Total execution time: 0.3040
DEBUG - 2014-07-14 00:34:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:34:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:34:11 --> URI Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Router Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Output Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Security Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Input Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:34:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Loader Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:34:11 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:34:11 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:34:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:34:11 --> Session Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:34:11 --> Session routines successfully run
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Controller Class Initialized
DEBUG - 2014-07-14 00:34:11 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:34:11 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:34:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:34:11 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:34:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:11 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-14 00:34:11 --> Final output sent to browser
DEBUG - 2014-07-14 00:34:11 --> Total execution time: 0.3210
DEBUG - 2014-07-14 00:34:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:34:27 --> URI Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Router Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Output Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Security Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Input Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:34:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Loader Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:34:27 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:34:27 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:34:27 --> Session Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:34:27 --> Session routines successfully run
DEBUG - 2014-07-14 00:34:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:34:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:34:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:34:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Controller Class Initialized
DEBUG - 2014-07-14 00:34:27 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:34:27 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:34:27 --> Form Validation Class Initialized
ERROR - 2014-07-14 00:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
ERROR - 2014-07-14 00:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
ERROR - 2014-07-14 00:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:34:27 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:34:27 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:34:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:34:27 --> Final output sent to browser
DEBUG - 2014-07-14 00:34:27 --> Total execution time: 0.2630
DEBUG - 2014-07-14 00:34:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:34:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:34:42 --> URI Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Router Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Output Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Security Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Input Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:34:42 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Loader Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:34:42 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:34:42 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:34:42 --> Session Class Initialized
DEBUG - 2014-07-14 00:34:42 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:34:42 --> Session routines successfully run
DEBUG - 2014-07-14 00:34:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:34:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:34:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Controller Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:34:43 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:34:43 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:34:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:34:43 --> URI Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Router Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Output Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Security Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Input Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:34:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Loader Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:34:43 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:34:43 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:34:43 --> Session Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:34:43 --> Session routines successfully run
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Controller Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:34:43 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:34:43 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:34:43 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:34:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:34:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:34:43 --> Final output sent to browser
DEBUG - 2014-07-14 00:34:43 --> Total execution time: 0.3370
DEBUG - 2014-07-14 00:34:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:34:46 --> URI Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Router Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Output Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Security Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Input Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:34:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Loader Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:34:46 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:34:46 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:34:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:34:46 --> Session Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:34:46 --> Session routines successfully run
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Controller Class Initialized
DEBUG - 2014-07-14 00:34:46 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:34:46 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:34:46 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:34:46 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:34:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:46 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-14 00:34:46 --> Final output sent to browser
DEBUG - 2014-07-14 00:34:46 --> Total execution time: 0.2890
DEBUG - 2014-07-14 00:34:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:34:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:34:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:34:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Loader Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:34:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:34:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:34:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:34:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:34:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Controller Class Initialized
DEBUG - 2014-07-14 00:34:54 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:34:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:34:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:34:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:34:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:34:54 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-07-14 00:34:54 --> Final output sent to browser
DEBUG - 2014-07-14 00:34:54 --> Total execution time: 0.2940
DEBUG - 2014-07-14 00:36:40 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:40 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:40 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:40 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:40 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:40 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:40 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:40 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:36:41 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:36:41 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:36:41 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:36:41 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:36:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:36:41 --> Final output sent to browser
DEBUG - 2014-07-14 00:36:41 --> Total execution time: 0.2670
DEBUG - 2014-07-14 00:36:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:43 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:43 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:43 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:43 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:43 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:43 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:36:43 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:36:43 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:36:43 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:36:43 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:36:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:36:43 --> Final output sent to browser
DEBUG - 2014-07-14 00:36:43 --> Total execution time: 0.3210
DEBUG - 2014-07-14 00:36:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:45 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:45 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:45 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:45 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:45 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:45 --> Inventory MX_Controller Initialized
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:36:45 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:36:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:36:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:36:45 --> Final output sent to browser
DEBUG - 2014-07-14 00:36:45 --> Total execution time: 0.2250
DEBUG - 2014-07-14 00:36:47 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:47 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:47 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:47 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:47 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:47 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:47 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:47 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:36:47 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:36:47 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:36:47 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:36:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:36:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:36:47 --> Final output sent to browser
DEBUG - 2014-07-14 00:36:47 --> Total execution time: 0.3420
DEBUG - 2014-07-14 00:36:48 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:48 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:48 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:48 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:48 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:48 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:48 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:48 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:36:48 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:36:48 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:36:48 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:36:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:36:48 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:36:49 --> Final output sent to browser
DEBUG - 2014-07-14 00:36:49 --> Total execution time: 0.3720
DEBUG - 2014-07-14 00:36:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:49 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:49 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:49 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:49 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:36:49 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:36:49 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:36:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Output Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Security Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Input Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:36:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Loader Class Initialized
DEBUG - 2014-07-14 00:36:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:36:49 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:36:49 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:36:50 --> Session Class Initialized
DEBUG - 2014-07-14 00:36:50 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:36:50 --> Session routines successfully run
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:50 --> Controller Class Initialized
DEBUG - 2014-07-14 00:36:50 --> Batch MX_Controller Initialized
DEBUG - 2014-07-14 00:36:50 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:36:50 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:36:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:36:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:15 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:15 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:15 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:15 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:16 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:16 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:16 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:16 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:16 --> Item MX_Controller Initialized
DEBUG - 2014-07-14 00:37:16 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:16 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:16 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:16 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:16 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:16 --> Total execution time: 0.3320
DEBUG - 2014-07-14 00:37:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:17 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:17 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:17 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:17 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:17 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:17 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:17 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:17 --> Total execution time: 0.2590
DEBUG - 2014-07-14 00:37:19 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:19 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:19 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:19 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:19 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:19 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:19 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:19 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:19 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:19 --> Total execution time: 0.3730
DEBUG - 2014-07-14 00:37:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:21 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:21 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:21 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:21 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:21 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:21 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:21 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:21 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:21 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:21 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:21 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:21 --> Total execution time: 0.4950
DEBUG - 2014-07-14 00:37:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:22 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:22 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:22 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:22 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:22 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:22 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:22 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:22 --> Total execution time: 0.3560
DEBUG - 2014-07-14 00:37:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:30 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:30 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:30 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:30 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:30 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:30 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:30 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:30 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:30 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:30 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:30 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:31 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:31 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:31 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:31 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:31 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:31 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:31 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:31 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:31 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:31 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:31 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:31 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:31 --> Total execution time: 0.3990
DEBUG - 2014-07-14 00:37:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:39 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:39 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:39 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:39 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:39 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:39 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:39 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:39 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:39 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:39 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:40 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:40 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:40 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:40 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:40 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:40 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:40 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:40 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:40 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:40 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:40 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:40 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:40 --> Total execution time: 0.3370
DEBUG - 2014-07-14 00:37:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:45 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:45 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:45 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:45 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:45 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:45 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:45 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:45 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:45 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:45 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:45 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:45 --> Total execution time: 0.2980
DEBUG - 2014-07-14 00:37:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:53 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:53 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:53 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:53 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:53 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:53 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:53 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:53 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:54 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:55 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:55 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:55 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:55 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:55 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:55 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:55 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:55 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:55 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:55 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:55 --> Total execution time: 0.4660
DEBUG - 2014-07-14 00:37:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:59 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:59 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:59 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:59 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:59 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:37:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:37:59 --> URI Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Router Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Output Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Security Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Input Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:37:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Language Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Config Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Loader Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:37:59 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:37:59 --> Session Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:37:59 --> Session routines successfully run
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Controller Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:37:59 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:37:59 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:37:59 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:37:59 --> Model Class Initialized
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:37:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:37:59 --> Final output sent to browser
DEBUG - 2014-07-14 00:37:59 --> Total execution time: 0.3730
DEBUG - 2014-07-14 00:38:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:38:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:38:06 --> URI Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Router Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Output Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Security Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Input Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:38:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Loader Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:38:06 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:38:06 --> Session Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:38:06 --> Session routines successfully run
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:38:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:38:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:38:06 --> URI Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Router Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Output Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Security Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Input Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:38:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Loader Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:38:06 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:38:06 --> Session Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:38:06 --> Session routines successfully run
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Controller Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:38:06 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:38:06 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:38:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:38:06 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:38:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:38:06 --> Final output sent to browser
DEBUG - 2014-07-14 00:38:06 --> Total execution time: 0.3430
DEBUG - 2014-07-14 00:38:19 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:38:19 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:38:19 --> URI Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Router Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Output Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Security Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Input Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:38:19 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Loader Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:38:19 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:38:19 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:38:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:38:19 --> Session Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:38:19 --> Session routines successfully run
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Controller Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:38:19 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:38:19 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:38:19 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:19 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:38:20 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:38:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:38:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:38:20 --> Final output sent to browser
DEBUG - 2014-07-14 00:38:20 --> Total execution time: 0.3430
DEBUG - 2014-07-14 00:38:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:38:22 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:38:22 --> URI Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Router Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Output Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Security Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Input Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:38:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Language Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Config Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Loader Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:38:22 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:38:22 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:38:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:38:22 --> Session Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:38:22 --> Session routines successfully run
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Controller Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:38:22 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:38:22 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:38:22 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:38:22 --> Model Class Initialized
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:38:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:38:22 --> Final output sent to browser
DEBUG - 2014-07-14 00:38:22 --> Total execution time: 0.3580
DEBUG - 2014-07-14 00:39:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:04 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:04 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:04 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:04 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:04 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:39:04 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:04 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:04 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:04 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:04 --> Total execution time: 0.3690
DEBUG - 2014-07-14 00:39:18 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:18 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:18 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:18 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:18 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:18 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:18 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:18 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:18 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:39:18 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:18 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/order/views/order_return_form.php
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:18 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:18 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:18 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:18 --> Total execution time: 0.2690
DEBUG - 2014-07-14 00:39:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:27 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:27 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:27 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:27 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:28 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:28 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:28 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:39:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:28 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:28 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:28 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:28 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:28 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:28 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:28 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:39:28 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:28 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:28 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:28 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:29 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:29 --> Total execution time: 0.3720
DEBUG - 2014-07-14 00:39:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:46 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:46 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:46 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:46 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:46 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:46 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:39:47 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:47 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:39:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:39:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:39:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:47 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:47 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:47 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:47 --> Total execution time: 0.3820
DEBUG - 2014-07-14 00:39:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:50 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:50 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:50 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:50 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:50 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:50 --> Payment MX_Controller Initialized
DEBUG - 2014-07-14 00:39:50 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:50 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:50 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:50 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:50 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:50 --> Total execution time: 0.2400
DEBUG - 2014-07-14 00:39:51 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:51 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:51 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:51 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:51 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:51 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:51 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:51 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:51 --> Employee MX_Controller Initialized
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:51 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:51 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:51 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:51 --> Total execution time: 0.2470
DEBUG - 2014-07-14 00:39:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:54 --> District MX_Controller Initialized
DEBUG - 2014-07-14 00:39:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:54 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:54 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:54 --> Total execution time: 0.2960
DEBUG - 2014-07-14 00:39:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:56 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:56 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:56 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:56 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:56 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:56 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:56 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:56 --> District MX_Controller Initialized
DEBUG - 2014-07-14 00:39:56 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:39:56 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/district/views/list_user_per_district.php
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:56 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:56 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:56 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:56 --> Total execution time: 0.2770
DEBUG - 2014-07-14 00:39:58 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:39:58 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:39:58 --> URI Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Router Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Output Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Security Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Input Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:39:58 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Language Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Config Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Loader Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:39:58 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:39:58 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:39:58 --> Session Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:39:58 --> Session routines successfully run
DEBUG - 2014-07-14 00:39:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:39:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:39:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:39:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Controller Class Initialized
DEBUG - 2014-07-14 00:39:58 --> Client MX_Controller Initialized
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:39:58 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:39:58 --> Model Class Initialized
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:39:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:39:58 --> Final output sent to browser
DEBUG - 2014-07-14 00:39:58 --> Total execution time: 0.2330
DEBUG - 2014-07-14 00:40:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:00 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:00 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:00 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:00 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:00 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:00 --> User MX_Controller Initialized
DEBUG - 2014-07-14 00:40:00 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:00 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:00 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:00 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:00 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:00 --> Total execution time: 0.3350
DEBUG - 2014-07-14 00:40:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:04 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:04 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:04 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:04 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:04 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:04 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:04 --> Report MX_Controller Initialized
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:04 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:04 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:04 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:04 --> Total execution time: 0.2220
DEBUG - 2014-07-14 00:40:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:07 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:07 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:07 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:07 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:07 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:40:07 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:07 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:07 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:07 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:07 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:07 --> Total execution time: 0.3130
DEBUG - 2014-07-14 00:40:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:11 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:11 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:11 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:11 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:11 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:11 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Role MX_Controller Initialized
DEBUG - 2014-07-14 00:40:11 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:11 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:11 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:11 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:11 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:11 --> Total execution time: 0.2940
DEBUG - 2014-07-14 00:40:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:13 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:13 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:13 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:13 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:13 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:13 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Permission MX_Controller Initialized
DEBUG - 2014-07-14 00:40:13 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:13 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:13 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:13 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:13 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:13 --> Total execution time: 0.3350
DEBUG - 2014-07-14 00:40:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:17 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:17 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:17 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:17 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:17 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:17 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:40:17 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:17 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:17 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:17 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:17 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:17 --> Total execution time: 0.3050
DEBUG - 2014-07-14 00:40:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:20 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:20 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:20 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:20 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:20 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:20 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:20 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:40:20 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:20 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:20 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:20 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:20 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:20 --> Total execution time: 0.2440
DEBUG - 2014-07-14 00:40:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:24 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:24 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:24 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:24 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:24 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Setting MX_Controller Initialized
DEBUG - 2014-07-14 00:40:24 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:24 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:24 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:24 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:24 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:24 --> Total execution time: 0.3020
DEBUG - 2014-07-14 00:40:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:42 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:42 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:42 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:42 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:42 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:42 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:42 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Permission MX_Controller Initialized
DEBUG - 2014-07-14 00:40:42 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:42 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:42 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:42 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:42 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:42 --> Total execution time: 0.3400
DEBUG - 2014-07-14 00:40:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:44 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:44 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:44 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:44 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:44 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:44 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Role MX_Controller Initialized
DEBUG - 2014-07-14 00:40:44 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:44 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:44 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:44 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:44 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:44 --> Total execution time: 0.3070
DEBUG - 2014-07-14 00:40:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:46 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:46 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:46 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:46 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:46 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:46 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:46 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:40:46 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:46 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:46 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:46 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:46 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:46 --> Total execution time: 0.2570
DEBUG - 2014-07-14 00:40:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:49 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:49 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:49 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:49 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:49 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:49 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:40:49 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:49 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:49 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:49 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:49 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:49 --> Total execution time: 0.3470
DEBUG - 2014-07-14 00:40:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Hooks Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Utf8 Class Initialized
DEBUG - 2014-07-14 00:40:54 --> UTF-8 Support Enabled
DEBUG - 2014-07-14 00:40:54 --> URI Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Router Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Output Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Security Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Input Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-14 00:40:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Language Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Config Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Loader Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Helper loaded: url_helper
DEBUG - 2014-07-14 00:40:54 --> Helper loaded: common_helper
DEBUG - 2014-07-14 00:40:54 --> Database Driver Class Initialized
ERROR - 2014-07-14 00:40:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-14 00:40:54 --> Session Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Helper loaded: string_helper
DEBUG - 2014-07-14 00:40:54 --> Session routines successfully run
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Controller Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Order MX_Controller Initialized
DEBUG - 2014-07-14 00:40:54 --> Helper loaded: form_helper
DEBUG - 2014-07-14 00:40:54 --> Form Validation Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-14 00:40:54 --> Menu MX_Controller Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-14 00:40:54 --> Model Class Initialized
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-14 00:40:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-14 00:40:54 --> Final output sent to browser
DEBUG - 2014-07-14 00:40:54 --> Total execution time: 0.3420
