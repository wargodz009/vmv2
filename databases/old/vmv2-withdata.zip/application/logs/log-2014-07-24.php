<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-24 07:58:52 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:58:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:58:52 --> URI Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:58:52 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:58:52 --> URI Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Router Class Initialized
DEBUG - 2014-07-24 07:58:52 --> Router Class Initialized
DEBUG - 2014-07-24 07:58:52 --> No URI present. Default controller set.
DEBUG - 2014-07-24 07:58:52 --> No URI present. Default controller set.
DEBUG - 2014-07-24 07:58:53 --> Output Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Output Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Security Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Security Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Input Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Input Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:58:53 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Loader Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Loader Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:58:53 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:58:53 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:58:53 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:58:53 --> Database Driver Class Initialized
DEBUG - 2014-07-24 07:58:53 --> Database Driver Class Initialized
ERROR - 2014-07-24 07:58:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-07-24 07:58:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-24 07:58:54 --> Session Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Session Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:58:54 --> A session cookie was not found.
DEBUG - 2014-07-24 07:58:54 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:58:54 --> A session cookie was not found.
DEBUG - 2014-07-24 07:58:54 --> Session routines successfully run
DEBUG - 2014-07-24 07:58:54 --> Session routines successfully run
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:58:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Controller Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Controller Class Initialized
DEBUG - 2014-07-24 07:58:54 --> Site MX_Controller Initialized
DEBUG - 2014-07-24 07:58:54 --> Site MX_Controller Initialized
DEBUG - 2014-07-24 07:58:55 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:58:55 --> URI Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Router Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Output Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Security Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Input Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:58:55 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Loader Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:58:55 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:58:55 --> Database Driver Class Initialized
ERROR - 2014-07-24 07:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-24 07:58:55 --> Session Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:58:55 --> Session routines successfully run
DEBUG - 2014-07-24 07:58:55 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:58:55 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:58:55 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:58:55 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Controller Class Initialized
DEBUG - 2014-07-24 07:58:55 --> Site MX_Controller Initialized
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-24 07:58:55 --> Menu MX_Controller Initialized
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-24 07:58:55 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-24 07:58:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-24 07:58:55 --> Final output sent to browser
DEBUG - 2014-07-24 07:58:55 --> Total execution time: 0.2290
DEBUG - 2014-07-24 07:58:59 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:58:59 --> URI Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Router Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Output Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Security Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Input Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:58:59 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Language Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Config Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Loader Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:58:59 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:58:59 --> Database Driver Class Initialized
ERROR - 2014-07-24 07:58:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-24 07:58:59 --> Session Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:58:59 --> Session routines successfully run
DEBUG - 2014-07-24 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Model Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Controller Class Initialized
DEBUG - 2014-07-24 07:58:59 --> Site MX_Controller Initialized
DEBUG - 2014-07-24 07:59:00 --> Config Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:59:00 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:59:00 --> URI Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Router Class Initialized
DEBUG - 2014-07-24 07:59:00 --> No URI present. Default controller set.
DEBUG - 2014-07-24 07:59:00 --> Output Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Security Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Input Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:59:00 --> Language Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Language Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Config Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Loader Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:59:00 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:59:00 --> Database Driver Class Initialized
ERROR - 2014-07-24 07:59:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-24 07:59:00 --> Session Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:59:00 --> Session routines successfully run
DEBUG - 2014-07-24 07:59:00 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:59:00 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:59:00 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:59:00 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Controller Class Initialized
DEBUG - 2014-07-24 07:59:00 --> Site MX_Controller Initialized
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-24 07:59:00 --> Menu MX_Controller Initialized
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-24 07:59:00 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-24 07:59:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-24 07:59:00 --> Final output sent to browser
DEBUG - 2014-07-24 07:59:00 --> Total execution time: 0.3820
DEBUG - 2014-07-24 07:59:06 --> Config Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:59:06 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:59:06 --> URI Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Router Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Output Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Security Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Input Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:59:06 --> Language Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Language Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Config Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Loader Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:59:06 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:59:06 --> Database Driver Class Initialized
ERROR - 2014-07-24 07:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-24 07:59:06 --> Session Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:59:06 --> Session routines successfully run
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Controller Class Initialized
DEBUG - 2014-07-24 07:59:06 --> Order MX_Controller Initialized
DEBUG - 2014-07-24 07:59:06 --> Helper loaded: form_helper
DEBUG - 2014-07-24 07:59:06 --> Form Validation Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-24 07:59:06 --> Menu MX_Controller Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-24 07:59:06 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-24 07:59:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-24 07:59:06 --> Final output sent to browser
DEBUG - 2014-07-24 07:59:06 --> Total execution time: 0.4010
DEBUG - 2014-07-24 07:59:08 --> Config Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Hooks Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Utf8 Class Initialized
DEBUG - 2014-07-24 07:59:08 --> UTF-8 Support Enabled
DEBUG - 2014-07-24 07:59:08 --> URI Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Router Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Output Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Security Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Input Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-24 07:59:08 --> Language Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Language Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Config Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Loader Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Helper loaded: url_helper
DEBUG - 2014-07-24 07:59:08 --> Helper loaded: common_helper
DEBUG - 2014-07-24 07:59:08 --> Database Driver Class Initialized
ERROR - 2014-07-24 07:59:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-24 07:59:08 --> Session Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Helper loaded: string_helper
DEBUG - 2014-07-24 07:59:08 --> Session routines successfully run
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Controller Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Order MX_Controller Initialized
DEBUG - 2014-07-24 07:59:08 --> Helper loaded: form_helper
DEBUG - 2014-07-24 07:59:08 --> Form Validation Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-24 07:59:08 --> Menu MX_Controller Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-24 07:59:08 --> Model Class Initialized
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-24 07:59:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-24 07:59:08 --> Final output sent to browser
DEBUG - 2014-07-24 07:59:08 --> Total execution time: 0.5980
