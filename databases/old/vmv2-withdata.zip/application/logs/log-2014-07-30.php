<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-07-30 06:28:50 --> Config Class Initialized
DEBUG - 2014-07-30 06:28:50 --> Hooks Class Initialized
DEBUG - 2014-07-30 06:28:50 --> Utf8 Class Initialized
DEBUG - 2014-07-30 06:28:50 --> UTF-8 Support Enabled
DEBUG - 2014-07-30 06:28:50 --> URI Class Initialized
DEBUG - 2014-07-30 06:28:50 --> Router Class Initialized
DEBUG - 2014-07-30 06:28:50 --> No URI present. Default controller set.
DEBUG - 2014-07-30 06:28:50 --> Output Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Security Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Input Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-30 06:28:51 --> Language Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Language Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Config Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Loader Class Initialized
DEBUG - 2014-07-30 06:28:51 --> Helper loaded: url_helper
DEBUG - 2014-07-30 06:28:51 --> Helper loaded: common_helper
DEBUG - 2014-07-30 06:28:51 --> Database Driver Class Initialized
ERROR - 2014-07-30 06:28:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-30 06:28:52 --> Session Class Initialized
DEBUG - 2014-07-30 06:28:52 --> Helper loaded: string_helper
DEBUG - 2014-07-30 06:28:52 --> A session cookie was not found.
DEBUG - 2014-07-30 06:28:53 --> Session routines successfully run
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Controller Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Site MX_Controller Initialized
DEBUG - 2014-07-30 06:28:53 --> Config Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Hooks Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Utf8 Class Initialized
DEBUG - 2014-07-30 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2014-07-30 06:28:53 --> URI Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Router Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Output Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Security Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Input Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-07-30 06:28:53 --> Language Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Language Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Config Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Loader Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Helper loaded: url_helper
DEBUG - 2014-07-30 06:28:53 --> Helper loaded: common_helper
DEBUG - 2014-07-30 06:28:53 --> Database Driver Class Initialized
ERROR - 2014-07-30 06:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-07-30 06:28:53 --> Session Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Helper loaded: string_helper
DEBUG - 2014-07-30 06:28:53 --> Session routines successfully run
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Controller Class Initialized
DEBUG - 2014-07-30 06:28:53 --> Site MX_Controller Initialized
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-07-30 06:28:54 --> Menu MX_Controller Initialized
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-07-30 06:28:54 --> Model Class Initialized
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-07-30 06:28:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-07-30 06:28:54 --> Final output sent to browser
DEBUG - 2014-07-30 06:28:54 --> Total execution time: 0.2780
