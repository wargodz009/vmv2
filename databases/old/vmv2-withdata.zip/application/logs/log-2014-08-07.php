<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-07 00:30:11 --> Config Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Hooks Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Utf8 Class Initialized
DEBUG - 2014-08-07 00:30:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 00:30:11 --> URI Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Router Class Initialized
DEBUG - 2014-08-07 00:30:11 --> No URI present. Default controller set.
DEBUG - 2014-08-07 00:30:11 --> Output Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Security Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Input Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 00:30:11 --> Language Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Language Class Initialized
DEBUG - 2014-08-07 00:30:11 --> Config Class Initialized
DEBUG - 2014-08-07 00:30:12 --> Loader Class Initialized
DEBUG - 2014-08-07 00:30:12 --> Helper loaded: url_helper
DEBUG - 2014-08-07 00:30:12 --> Helper loaded: common_helper
DEBUG - 2014-08-07 00:30:12 --> Database Driver Class Initialized
ERROR - 2014-08-07 00:30:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 00:30:13 --> Session Class Initialized
DEBUG - 2014-08-07 00:30:13 --> Helper loaded: string_helper
DEBUG - 2014-08-07 00:30:13 --> A session cookie was not found.
DEBUG - 2014-08-07 00:30:14 --> Session routines successfully run
DEBUG - 2014-08-07 00:30:14 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 00:30:14 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 00:30:14 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 00:30:14 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:14 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:14 --> Controller Class Initialized
DEBUG - 2014-08-07 00:30:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 00:30:15 --> Config Class Initialized
DEBUG - 2014-08-07 00:30:15 --> Hooks Class Initialized
DEBUG - 2014-08-07 00:30:15 --> Utf8 Class Initialized
DEBUG - 2014-08-07 00:30:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 00:30:15 --> URI Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Router Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Output Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Security Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Input Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 00:30:16 --> Language Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Language Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Config Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Loader Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Helper loaded: url_helper
DEBUG - 2014-08-07 00:30:16 --> Helper loaded: common_helper
DEBUG - 2014-08-07 00:30:16 --> Database Driver Class Initialized
ERROR - 2014-08-07 00:30:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 00:30:16 --> Session Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Helper loaded: string_helper
DEBUG - 2014-08-07 00:30:16 --> Session routines successfully run
DEBUG - 2014-08-07 00:30:16 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 00:30:16 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 00:30:16 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 00:30:16 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Controller Class Initialized
DEBUG - 2014-08-07 00:30:16 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 00:30:16 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-07 00:30:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-07 00:30:17 --> Model Class Initialized
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-07 00:30:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-07 00:30:17 --> Final output sent to browser
DEBUG - 2014-08-07 00:30:17 --> Total execution time: 1.2371
DEBUG - 2014-08-07 00:32:52 --> Config Class Initialized
DEBUG - 2014-08-07 00:32:52 --> Hooks Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Utf8 Class Initialized
DEBUG - 2014-08-07 00:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 00:32:53 --> URI Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Router Class Initialized
DEBUG - 2014-08-07 00:32:53 --> No URI present. Default controller set.
DEBUG - 2014-08-07 00:32:53 --> Output Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Security Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Input Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 00:32:53 --> Language Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Language Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Config Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Loader Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Helper loaded: url_helper
DEBUG - 2014-08-07 00:32:53 --> Helper loaded: common_helper
DEBUG - 2014-08-07 00:32:53 --> Database Driver Class Initialized
ERROR - 2014-08-07 00:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 00:32:53 --> Session Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Helper loaded: string_helper
ERROR - 2014-08-07 00:32:53 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
DEBUG - 2014-08-07 00:32:53 --> Session routines successfully run
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Controller Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 00:32:53 --> Config Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Hooks Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Utf8 Class Initialized
DEBUG - 2014-08-07 00:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 00:32:53 --> URI Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Router Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Output Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Security Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Input Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 00:32:53 --> Language Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Language Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Config Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Loader Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Helper loaded: url_helper
DEBUG - 2014-08-07 00:32:53 --> Helper loaded: common_helper
DEBUG - 2014-08-07 00:32:53 --> Database Driver Class Initialized
ERROR - 2014-08-07 00:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 00:32:53 --> Session Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Helper loaded: string_helper
DEBUG - 2014-08-07 00:32:53 --> Session routines successfully run
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Controller Class Initialized
DEBUG - 2014-08-07 00:32:53 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-07 00:32:53 --> Menu MX_Controller Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-07 00:32:53 --> Model Class Initialized
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-07 00:32:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-07 00:32:53 --> Final output sent to browser
DEBUG - 2014-08-07 00:32:53 --> Total execution time: 0.2890
DEBUG - 2014-08-07 22:46:31 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Hooks Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Utf8 Class Initialized
DEBUG - 2014-08-07 22:46:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 22:46:31 --> Hooks Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Utf8 Class Initialized
DEBUG - 2014-08-07 22:46:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 22:46:31 --> URI Class Initialized
DEBUG - 2014-08-07 22:46:31 --> URI Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Router Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Router Class Initialized
DEBUG - 2014-08-07 22:46:31 --> No URI present. Default controller set.
DEBUG - 2014-08-07 22:46:31 --> No URI present. Default controller set.
DEBUG - 2014-08-07 22:46:31 --> Output Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Output Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Security Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Security Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Input Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Input Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 22:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 22:46:31 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Loader Class Initialized
DEBUG - 2014-08-07 22:46:31 --> Loader Class Initialized
DEBUG - 2014-08-07 22:46:32 --> Helper loaded: url_helper
DEBUG - 2014-08-07 22:46:32 --> Helper loaded: url_helper
DEBUG - 2014-08-07 22:46:32 --> Helper loaded: common_helper
DEBUG - 2014-08-07 22:46:32 --> Helper loaded: common_helper
DEBUG - 2014-08-07 22:46:32 --> Database Driver Class Initialized
DEBUG - 2014-08-07 22:46:32 --> Database Driver Class Initialized
ERROR - 2014-08-07 22:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-07 22:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 22:46:33 --> Session Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Session Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Helper loaded: string_helper
DEBUG - 2014-08-07 22:46:33 --> A session cookie was not found.
DEBUG - 2014-08-07 22:46:33 --> Helper loaded: string_helper
DEBUG - 2014-08-07 22:46:33 --> A session cookie was not found.
DEBUG - 2014-08-07 22:46:33 --> Session routines successfully run
DEBUG - 2014-08-07 22:46:33 --> Session routines successfully run
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Controller Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Controller Class Initialized
DEBUG - 2014-08-07 22:46:33 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 22:46:33 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 22:46:34 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Hooks Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Utf8 Class Initialized
DEBUG - 2014-08-07 22:46:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 22:46:34 --> URI Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Router Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Output Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Security Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Input Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 22:46:34 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Loader Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Helper loaded: url_helper
DEBUG - 2014-08-07 22:46:34 --> Helper loaded: common_helper
DEBUG - 2014-08-07 22:46:34 --> Database Driver Class Initialized
ERROR - 2014-08-07 22:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 22:46:34 --> Session Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Helper loaded: string_helper
DEBUG - 2014-08-07 22:46:34 --> Session routines successfully run
DEBUG - 2014-08-07 22:46:34 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 22:46:34 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 22:46:34 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 22:46:34 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Controller Class Initialized
DEBUG - 2014-08-07 22:46:34 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-07 22:46:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-07 22:46:34 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-07 22:46:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-07 22:46:34 --> Final output sent to browser
DEBUG - 2014-08-07 22:46:34 --> Total execution time: 0.2210
DEBUG - 2014-08-07 22:46:40 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Hooks Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Utf8 Class Initialized
DEBUG - 2014-08-07 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 22:46:40 --> URI Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Router Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Output Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Security Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Input Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 22:46:40 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Loader Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Helper loaded: url_helper
DEBUG - 2014-08-07 22:46:40 --> Helper loaded: common_helper
DEBUG - 2014-08-07 22:46:40 --> Database Driver Class Initialized
ERROR - 2014-08-07 22:46:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 22:46:40 --> Session Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Helper loaded: string_helper
DEBUG - 2014-08-07 22:46:40 --> Session routines successfully run
DEBUG - 2014-08-07 22:46:40 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 22:46:40 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 22:46:40 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 22:46:40 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Controller Class Initialized
DEBUG - 2014-08-07 22:46:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 22:46:41 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Hooks Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Utf8 Class Initialized
DEBUG - 2014-08-07 22:46:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-07 22:46:41 --> URI Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Router Class Initialized
DEBUG - 2014-08-07 22:46:41 --> No URI present. Default controller set.
DEBUG - 2014-08-07 22:46:41 --> Output Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Security Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Input Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-07 22:46:41 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Language Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Config Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Loader Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Helper loaded: url_helper
DEBUG - 2014-08-07 22:46:41 --> Helper loaded: common_helper
DEBUG - 2014-08-07 22:46:41 --> Database Driver Class Initialized
ERROR - 2014-08-07 22:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-07 22:46:41 --> Session Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Helper loaded: string_helper
DEBUG - 2014-08-07 22:46:41 --> Session routines successfully run
DEBUG - 2014-08-07 22:46:41 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-07 22:46:41 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-07 22:46:41 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-07 22:46:41 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Controller Class Initialized
DEBUG - 2014-08-07 22:46:41 --> Site MX_Controller Initialized
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-07 22:46:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-07 22:46:41 --> Model Class Initialized
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-07 22:46:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-07 22:46:41 --> Final output sent to browser
DEBUG - 2014-08-07 22:46:41 --> Total execution time: 0.3770
