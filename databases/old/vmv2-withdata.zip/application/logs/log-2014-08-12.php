<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-12 01:57:09 --> Config Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Hooks Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Utf8 Class Initialized
DEBUG - 2014-08-12 01:57:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 01:57:09 --> URI Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Router Class Initialized
DEBUG - 2014-08-12 01:57:09 --> No URI present. Default controller set.
DEBUG - 2014-08-12 01:57:09 --> Output Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Security Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Input Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 01:57:09 --> Language Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Language Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Config Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Loader Class Initialized
DEBUG - 2014-08-12 01:57:09 --> Helper loaded: url_helper
DEBUG - 2014-08-12 01:57:09 --> Helper loaded: common_helper
DEBUG - 2014-08-12 01:57:09 --> Database Driver Class Initialized
ERROR - 2014-08-12 01:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 01:57:11 --> Session Class Initialized
DEBUG - 2014-08-12 01:57:11 --> Helper loaded: string_helper
DEBUG - 2014-08-12 01:57:11 --> A session cookie was not found.
DEBUG - 2014-08-12 01:57:11 --> Session routines successfully run
DEBUG - 2014-08-12 01:57:11 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-12 01:57:11 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-12 01:57:11 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-12 01:57:11 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:11 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:11 --> Controller Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-12 01:57:12 --> Config Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Hooks Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Utf8 Class Initialized
DEBUG - 2014-08-12 01:57:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 01:57:12 --> URI Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Router Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Output Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Security Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Input Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 01:57:12 --> Language Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Language Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Config Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Loader Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Helper loaded: url_helper
DEBUG - 2014-08-12 01:57:12 --> Helper loaded: common_helper
DEBUG - 2014-08-12 01:57:12 --> Database Driver Class Initialized
ERROR - 2014-08-12 01:57:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 01:57:12 --> Session Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Helper loaded: string_helper
DEBUG - 2014-08-12 01:57:12 --> Session routines successfully run
DEBUG - 2014-08-12 01:57:12 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-12 01:57:12 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-12 01:57:12 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-12 01:57:12 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Controller Class Initialized
DEBUG - 2014-08-12 01:57:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-12 01:57:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-12 01:57:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-12 01:57:12 --> Model Class Initialized
DEBUG - 2014-08-12 01:57:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-12 01:57:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-12 01:57:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-12 01:57:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-12 01:57:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-12 01:57:13 --> Final output sent to browser
DEBUG - 2014-08-12 01:57:13 --> Total execution time: 0.3070
