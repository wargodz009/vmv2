<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-17 02:04:40 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:40 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:40 --> No URI present. Default controller set.
DEBUG - 2014-08-17 02:04:40 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:40 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:40 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:40 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:40 --> A session cookie was not found.
DEBUG - 2014-08-17 02:04:40 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 02:04:40 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:40 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:40 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:40 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:40 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:40 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:40 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:40 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:41 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:41 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:41 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:41 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 02:04:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 02:04:41 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 02:04:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 02:04:41 --> Final output sent to browser
DEBUG - 2014-08-17 02:04:41 --> Total execution time: 0.2941
DEBUG - 2014-08-17 02:04:45 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:45 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:45 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:45 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:45 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:45 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:45 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 02:04:45 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:45 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:45 --> No URI present. Default controller set.
DEBUG - 2014-08-17 02:04:45 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:45 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:45 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:45 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:45 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:45 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 02:04:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 02:04:45 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 02:04:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 02:04:45 --> Final output sent to browser
DEBUG - 2014-08-17 02:04:45 --> Total execution time: 0.3385
DEBUG - 2014-08-17 02:04:47 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:47 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:47 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:48 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:48 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:48 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:48 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:48 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 02:04:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 02:04:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 02:04:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 02:04:48 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 02:04:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 02:04:48 --> Final output sent to browser
DEBUG - 2014-08-17 02:04:48 --> Total execution time: 0.4083
DEBUG - 2014-08-17 02:04:49 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:49 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:49 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:49 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:49 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:49 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:49 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:49 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:49 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:49 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:49 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:49 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 02:04:49 --> Helper loaded: form_helper
DEBUG - 2014-08-17 02:04:49 --> Form Validation Class Initialized
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 02:04:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 02:04:49 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 02:04:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 02:04:49 --> Final output sent to browser
DEBUG - 2014-08-17 02:04:49 --> Total execution time: 0.3707
DEBUG - 2014-08-17 02:04:51 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:51 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:51 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:51 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:51 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:51 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:51 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Setting MX_Controller Initialized
DEBUG - 2014-08-17 02:04:51 --> Helper loaded: form_helper
DEBUG - 2014-08-17 02:04:51 --> Form Validation Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 02:04:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 02:04:51 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 02:04:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 02:04:51 --> Final output sent to browser
DEBUG - 2014-08-17 02:04:51 --> Total execution time: 0.7543
DEBUG - 2014-08-17 02:04:54 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Hooks Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Utf8 Class Initialized
DEBUG - 2014-08-17 02:04:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 02:04:54 --> URI Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Router Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Output Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Security Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Input Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 02:04:54 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Language Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Config Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Loader Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Helper loaded: url_helper
DEBUG - 2014-08-17 02:04:54 --> Helper loaded: common_helper
DEBUG - 2014-08-17 02:04:54 --> Database Driver Class Initialized
ERROR - 2014-08-17 02:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 02:04:54 --> Session Class Initialized
DEBUG - 2014-08-17 02:04:54 --> Helper loaded: string_helper
DEBUG - 2014-08-17 02:04:54 --> Session routines successfully run
DEBUG - 2014-08-17 02:04:54 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 02:04:54 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 02:04:55 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 02:04:55 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:55 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:55 --> Controller Class Initialized
DEBUG - 2014-08-17 02:04:55 --> Permission MX_Controller Initialized
DEBUG - 2014-08-17 02:04:55 --> Helper loaded: form_helper
DEBUG - 2014-08-17 02:04:55 --> Form Validation Class Initialized
DEBUG - 2014-08-17 02:04:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 02:04:55 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:55 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 02:04:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 02:04:55 --> Model Class Initialized
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 02:04:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 02:04:55 --> Final output sent to browser
DEBUG - 2014-08-17 02:04:55 --> Total execution time: 0.4916
DEBUG - 2014-08-17 20:54:13 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:13 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:13 --> No URI present. Default controller set.
DEBUG - 2014-08-17 20:54:13 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:13 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:13 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:14 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:14 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:14 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:14 --> A session cookie was not found.
DEBUG - 2014-08-17 20:54:14 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 20:54:14 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:14 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:14 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:14 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:14 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:14 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:14 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:54:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:54:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:54:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:54:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:54:15 --> Final output sent to browser
DEBUG - 2014-08-17 20:54:15 --> Total execution time: 0.3654
DEBUG - 2014-08-17 20:54:23 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:23 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:23 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:23 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:23 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:23 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:23 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:23 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:23 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:23 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:23 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:23 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 20:54:24 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:24 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:24 --> No URI present. Default controller set.
DEBUG - 2014-08-17 20:54:24 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:24 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:24 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:24 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:24 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:24 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:24 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:54:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:54:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:54:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:54:24 --> Final output sent to browser
DEBUG - 2014-08-17 20:54:24 --> Total execution time: 0.5069
DEBUG - 2014-08-17 20:54:51 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:51 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:51 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:51 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:51 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:51 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:51 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:51 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 20:54:51 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:54:51 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:54:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:54:51 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:54:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:54:51 --> Final output sent to browser
DEBUG - 2014-08-17 20:54:51 --> Total execution time: 0.5872
DEBUG - 2014-08-17 20:54:54 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:54 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:54 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:54 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:54 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:54 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:54 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:54 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:54 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:54 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:54 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:55 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 20:54:55 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:54:55 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:54:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:54:55 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:54:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:54:55 --> Final output sent to browser
DEBUG - 2014-08-17 20:54:55 --> Total execution time: 0.6747
DEBUG - 2014-08-17 20:54:57 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:54:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:54:57 --> URI Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Router Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Output Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Security Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Input Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:54:57 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Language Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Config Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Loader Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:54:57 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:54:57 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:54:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:54:57 --> Session Class Initialized
DEBUG - 2014-08-17 20:54:57 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:54:57 --> Session routines successfully run
DEBUG - 2014-08-17 20:54:57 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> Controller Class Initialized
DEBUG - 2014-08-17 20:54:58 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 20:54:58 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:54:58 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:54:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:54:58 --> Model Class Initialized
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:54:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:54:58 --> Final output sent to browser
DEBUG - 2014-08-17 20:54:58 --> Total execution time: 0.6334
DEBUG - 2014-08-17 20:55:01 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:01 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:01 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:01 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:01 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:01 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:01 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:01 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:01 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:01 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:01 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:01 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 20:55:01 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:01 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:01 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:01 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:01 --> Total execution time: 0.4126
DEBUG - 2014-08-17 20:55:03 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:03 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:03 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:03 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:03 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:04 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:04 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:04 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:04 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:04 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 20:55:04 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:04 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:04 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:04 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:04 --> Total execution time: 0.5892
DEBUG - 2014-08-17 20:55:06 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:06 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:06 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:06 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:06 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:06 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:06 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:06 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:06 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:06 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:06 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:06 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:06 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:06 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:06 --> Total execution time: 0.3917
DEBUG - 2014-08-17 20:55:08 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:08 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:09 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:09 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:09 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:09 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:09 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:09 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:09 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:09 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:09 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:09 --> Employee MX_Controller Initialized
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:09 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:09 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:09 --> Total execution time: 0.3892
DEBUG - 2014-08-17 20:55:11 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:11 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:11 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:11 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:11 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:11 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:11 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:11 --> User MX_Controller Initialized
DEBUG - 2014-08-17 20:55:11 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:11 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:11 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:11 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:11 --> Total execution time: 0.7435
DEBUG - 2014-08-17 20:55:13 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:13 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:13 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:13 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:14 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:14 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:14 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:14 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:14 --> District MX_Controller Initialized
DEBUG - 2014-08-17 20:55:14 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:14 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:14 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:14 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:14 --> Total execution time: 0.5427
DEBUG - 2014-08-17 20:55:16 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:16 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:16 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:16 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:16 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:16 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:16 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 20:55:16 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:16 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:17 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:17 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:17 --> Total execution time: 0.6781
DEBUG - 2014-08-17 20:55:21 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:21 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:21 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:21 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:21 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:21 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:21 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:21 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:21 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:21 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:21 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:21 --> Client MX_Controller Initialized
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:21 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:21 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:21 --> Total execution time: 0.4310
DEBUG - 2014-08-17 20:55:24 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:24 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:24 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:24 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:24 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:24 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:24 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:24 --> User MX_Controller Initialized
DEBUG - 2014-08-17 20:55:24 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:24 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:24 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:24 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:24 --> Total execution time: 0.5564
DEBUG - 2014-08-17 20:55:27 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:27 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:27 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:27 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:27 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:27 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:27 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:27 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:27 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:27 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:27 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:27 --> Report MX_Controller Initialized
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:27 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:27 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:27 --> Total execution time: 0.4083
DEBUG - 2014-08-17 20:55:29 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:29 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:29 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:29 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:29 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:29 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:30 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:30 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:30 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:30 --> Setting MX_Controller Initialized
DEBUG - 2014-08-17 20:55:30 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:30 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:30 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:30 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:30 --> Total execution time: 0.5753
DEBUG - 2014-08-17 20:55:33 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:33 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:33 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:33 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:33 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:33 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:33 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Setting MX_Controller Initialized
DEBUG - 2014-08-17 20:55:33 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:33 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:33 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:33 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:33 --> Total execution time: 0.5580
DEBUG - 2014-08-17 20:55:35 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:35 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:35 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:35 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:35 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:35 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:35 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:35 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:35 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:35 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:35 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:35 --> Setting MX_Controller Initialized
DEBUG - 2014-08-17 20:55:35 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:35 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:35 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:35 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:35 --> Total execution time: 0.4546
DEBUG - 2014-08-17 20:55:49 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:49 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:49 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:49 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:49 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:49 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:49 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Role MX_Controller Initialized
DEBUG - 2014-08-17 20:55:49 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:49 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:49 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:49 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:49 --> Total execution time: 0.5722
DEBUG - 2014-08-17 20:55:52 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Hooks Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Utf8 Class Initialized
DEBUG - 2014-08-17 20:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 20:55:52 --> URI Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Router Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Output Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Security Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Input Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 20:55:52 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Language Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Config Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Loader Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Helper loaded: url_helper
DEBUG - 2014-08-17 20:55:52 --> Helper loaded: common_helper
DEBUG - 2014-08-17 20:55:52 --> Database Driver Class Initialized
ERROR - 2014-08-17 20:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 20:55:52 --> Session Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Helper loaded: string_helper
DEBUG - 2014-08-17 20:55:52 --> Session routines successfully run
DEBUG - 2014-08-17 20:55:52 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 20:55:52 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 20:55:52 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 20:55:52 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Controller Class Initialized
DEBUG - 2014-08-17 20:55:52 --> Setting MX_Controller Initialized
DEBUG - 2014-08-17 20:55:52 --> Helper loaded: form_helper
DEBUG - 2014-08-17 20:55:52 --> Form Validation Class Initialized
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 20:55:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 20:55:52 --> Model Class Initialized
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 20:55:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 20:55:52 --> Final output sent to browser
DEBUG - 2014-08-17 20:55:52 --> Total execution time: 0.4418
DEBUG - 2014-08-17 21:03:28 --> Config Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:03:28 --> URI Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Router Class Initialized
DEBUG - 2014-08-17 21:03:28 --> No URI present. Default controller set.
DEBUG - 2014-08-17 21:03:28 --> Output Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Security Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Input Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:03:28 --> Language Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Language Class Initialized
DEBUG - 2014-08-17 21:03:28 --> Config Class Initialized
DEBUG - 2014-08-17 21:03:29 --> Loader Class Initialized
DEBUG - 2014-08-17 21:03:29 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:03:29 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:03:29 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:03:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:03:29 --> Session Class Initialized
DEBUG - 2014-08-17 21:03:29 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:03:29 --> Session routines successfully run
DEBUG - 2014-08-17 21:03:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:03:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:03:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:03:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:03:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:03:29 --> Controller Class Initialized
DEBUG - 2014-08-17 21:03:29 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:03:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:03:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:03:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:03:29 --> Final output sent to browser
DEBUG - 2014-08-17 21:03:29 --> Total execution time: 0.8907
DEBUG - 2014-08-17 21:09:40 --> Config Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:09:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:09:40 --> URI Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Router Class Initialized
DEBUG - 2014-08-17 21:09:40 --> No URI present. Default controller set.
DEBUG - 2014-08-17 21:09:40 --> Output Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Security Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Input Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:09:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Config Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Loader Class Initialized
DEBUG - 2014-08-17 21:09:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:09:41 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:09:41 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:09:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:09:41 --> Session Class Initialized
DEBUG - 2014-08-17 21:09:41 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:09:41 --> Session routines successfully run
DEBUG - 2014-08-17 21:09:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:09:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:09:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:09:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:09:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:09:41 --> Controller Class Initialized
DEBUG - 2014-08-17 21:09:41 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:09:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:09:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:09:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:09:41 --> Final output sent to browser
DEBUG - 2014-08-17 21:09:41 --> Total execution time: 0.5667
DEBUG - 2014-08-17 21:11:56 --> Config Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:11:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:11:56 --> URI Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Router Class Initialized
DEBUG - 2014-08-17 21:11:56 --> No URI present. Default controller set.
DEBUG - 2014-08-17 21:11:56 --> Output Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Security Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Input Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:11:56 --> Language Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Language Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Config Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Loader Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:11:56 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:11:56 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:11:56 --> Session Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:11:56 --> Session routines successfully run
DEBUG - 2014-08-17 21:11:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:11:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:11:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:11:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Controller Class Initialized
DEBUG - 2014-08-17 21:11:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:11:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:11:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:11:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:11:56 --> Final output sent to browser
DEBUG - 2014-08-17 21:11:56 --> Total execution time: 0.4810
DEBUG - 2014-08-17 21:12:32 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:12:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:12:32 --> URI Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Router Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Output Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Security Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Input Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:12:32 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Loader Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:12:32 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:12:32 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:12:32 --> Session Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:12:32 --> Session routines successfully run
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Controller Class Initialized
DEBUG - 2014-08-17 21:12:32 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:12:32 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:12:32 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:12:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:12:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:12:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:12:32 --> Final output sent to browser
DEBUG - 2014-08-17 21:12:32 --> Total execution time: 0.6894
DEBUG - 2014-08-17 21:12:35 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:12:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:12:35 --> URI Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Router Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Output Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Security Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Input Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:12:35 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Loader Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:12:35 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:12:35 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:12:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:12:35 --> Session Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:12:35 --> Session routines successfully run
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Controller Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:12:35 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:12:35 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:12:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:12:35 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:12:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:12:35 --> Final output sent to browser
DEBUG - 2014-08-17 21:12:35 --> Total execution time: 0.7337
DEBUG - 2014-08-17 21:12:40 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:12:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:12:40 --> URI Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Router Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Output Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Security Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Input Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:12:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Loader Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:12:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:12:40 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:12:40 --> Session Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:12:40 --> Session routines successfully run
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Controller Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:12:40 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:12:40 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:12:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:12:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:12:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:12:40 --> Final output sent to browser
DEBUG - 2014-08-17 21:12:40 --> Total execution time: 0.6421
DEBUG - 2014-08-17 21:12:45 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:12:46 --> URI Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Router Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Output Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Security Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Input Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:12:46 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Loader Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:12:46 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:12:46 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:12:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:12:46 --> Session Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:12:46 --> Session routines successfully run
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Controller Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:12:46 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:12:46 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:12:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:12:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:12:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:12:46 --> Final output sent to browser
DEBUG - 2014-08-17 21:12:46 --> Total execution time: 0.6588
DEBUG - 2014-08-17 21:12:49 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:12:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:12:49 --> URI Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Router Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Output Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Security Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Input Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:12:49 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Loader Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:12:49 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:12:49 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:12:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:12:49 --> Session Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:12:49 --> Session routines successfully run
DEBUG - 2014-08-17 21:12:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:12:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:12:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:12:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Controller Class Initialized
DEBUG - 2014-08-17 21:12:49 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:12:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:12:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:12:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:12:49 --> Final output sent to browser
DEBUG - 2014-08-17 21:12:49 --> Total execution time: 0.4644
DEBUG - 2014-08-17 21:12:51 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:12:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:12:51 --> URI Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Router Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Output Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Security Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Input Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:12:51 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Language Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Config Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Loader Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:12:51 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:12:51 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:12:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:12:51 --> Session Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:12:51 --> Session routines successfully run
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Controller Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:12:51 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:12:51 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:12:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:12:51 --> Model Class Initialized
DEBUG - 2014-08-17 21:12:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:12:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:12:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:12:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:12:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:12:52 --> Final output sent to browser
DEBUG - 2014-08-17 21:12:52 --> Total execution time: 0.6981
DEBUG - 2014-08-17 21:13:31 --> Config Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:13:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:13:32 --> URI Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Router Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Output Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Security Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Input Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:13:32 --> Language Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Language Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Config Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Loader Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:13:32 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:13:32 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:13:32 --> Session Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:13:32 --> Session routines successfully run
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:13:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:13:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:13:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Controller Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:13:32 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:13:32 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:13:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Config Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:35:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:35:12 --> URI Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Router Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Output Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Security Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Input Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:35:12 --> Language Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Language Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Config Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Loader Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:35:12 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:35:12 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:35:12 --> Session Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:35:12 --> Session routines successfully run
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Controller Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:35:12 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:35:12 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:35:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:35:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:35:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:35:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:35:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:35:13 --> Final output sent to browser
DEBUG - 2014-08-17 21:35:13 --> Total execution time: 0.6290
DEBUG - 2014-08-17 21:42:24 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:24 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:24 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:24 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:24 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:24 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:24 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:25 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:25 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:42:25 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:25 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:25 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:25 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:25 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:25 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:25 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:26 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:42:26 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:26 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:26 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:26 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:26 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:26 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:26 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:26 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:26 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:42:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:42:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:42:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:42:27 --> Final output sent to browser
DEBUG - 2014-08-17 21:42:27 --> Total execution time: 0.7981
DEBUG - 2014-08-17 21:42:29 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:29 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:29 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:29 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:29 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:29 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:30 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:30 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:30 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:30 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:30 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:30 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:42:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:42:30 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:42:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:42:30 --> Final output sent to browser
DEBUG - 2014-08-17 21:42:30 --> Total execution time: 0.5874
DEBUG - 2014-08-17 21:42:46 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:46 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:46 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:46 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:46 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:46 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:46 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:46 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:46 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:42:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:47 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:47 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:47 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:47 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:47 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:42:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:42:48 --> URI Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Router Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Output Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Security Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Input Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:42:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Loader Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:42:48 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:42:48 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:42:48 --> Session Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:42:48 --> Session routines successfully run
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:42:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:42:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:42:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:42:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:42:48 --> Final output sent to browser
DEBUG - 2014-08-17 21:42:48 --> Total execution time: 0.7925
DEBUG - 2014-08-17 21:44:14 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:14 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:14 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:14 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:14 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:14 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:14 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Item MX_Controller Initialized
DEBUG - 2014-08-17 21:44:14 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:14 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:44:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:44:14 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:44:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:44:14 --> Final output sent to browser
DEBUG - 2014-08-17 21:44:14 --> Total execution time: 0.7005
DEBUG - 2014-08-17 21:44:25 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:25 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:25 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:25 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:25 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:25 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:25 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:25 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:26 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:26 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:44:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:44:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:44:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:44:26 --> Final output sent to browser
DEBUG - 2014-08-17 21:44:26 --> Total execution time: 0.6947
DEBUG - 2014-08-17 21:44:30 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:30 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:30 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:31 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:31 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:31 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:31 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:31 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:31 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:44:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:44:31 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:44:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:44:31 --> Final output sent to browser
DEBUG - 2014-08-17 21:44:31 --> Total execution time: 0.6072
DEBUG - 2014-08-17 21:44:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:41 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:41 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:41 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:41 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:41 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:41 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:41 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:41 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:44:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:42 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:42 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:42 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:42 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:42 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:42 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:42 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:44:46 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:46 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:46 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:46 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:47 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:47 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:47 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:44:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:47 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:47 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:48 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:44:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:48 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:48 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:48 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:48 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:48 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:48 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:49 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:49 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-17 21:44:49 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:49 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:44:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:44:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:44:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:44:49 --> Final output sent to browser
DEBUG - 2014-08-17 21:44:49 --> Total execution time: 0.7851
DEBUG - 2014-08-17 21:44:51 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:51 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:51 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:51 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:51 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:51 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:51 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:52 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:52 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:52 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:44:52 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:52 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:44:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:44:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:44:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:44:52 --> Final output sent to browser
DEBUG - 2014-08-17 21:44:52 --> Total execution time: 0.7328
DEBUG - 2014-08-17 21:44:55 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:44:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:44:55 --> URI Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Router Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Output Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Security Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Input Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:44:55 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Language Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Config Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Loader Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:44:55 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:44:55 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:44:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:44:55 --> Session Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:44:55 --> Session routines successfully run
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Controller Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:44:55 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:44:55 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:44:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:44:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:44:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:44:55 --> Final output sent to browser
DEBUG - 2014-08-17 21:44:55 --> Total execution time: 0.6686
DEBUG - 2014-08-17 21:46:14 --> Config Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:46:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:46:14 --> URI Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Router Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Output Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Security Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Input Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:46:14 --> Language Class Initialized
DEBUG - 2014-08-17 21:46:14 --> Language Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Config Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Loader Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:46:15 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:46:15 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:46:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:46:15 --> Session Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:46:15 --> Session routines successfully run
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Controller Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:46:15 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:46:15 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:46:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:46:15 --> Model Class Initialized
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:46:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:46:15 --> Final output sent to browser
DEBUG - 2014-08-17 21:46:15 --> Total execution time: 0.7955
DEBUG - 2014-08-17 21:47:03 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:03 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:03 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:03 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:03 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:03 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:04 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:04 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:04 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:04 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:04 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:47:04 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:04 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:47:05 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:05 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:05 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:05 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:05 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:05 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:05 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:47:05 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:05 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:47:40 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:40 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:41 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:41 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:41 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:41 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:47:41 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:41 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:47:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:41 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:42 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:42 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:42 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:42 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:42 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:47:42 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:42 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-17 21:47:43 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:43 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:43 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:43 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:43 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:43 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:43 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Batch MX_Controller Initialized
DEBUG - 2014-08-17 21:47:43 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:43 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:47:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:47:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:47:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:47:43 --> Final output sent to browser
DEBUG - 2014-08-17 21:47:43 --> Total execution time: 0.8713
DEBUG - 2014-08-17 21:47:46 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:46 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:47 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:47 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:47 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:47 --> Employee MX_Controller Initialized
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:47:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:47:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:47:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:47:47 --> Final output sent to browser
DEBUG - 2014-08-17 21:47:47 --> Total execution time: 0.5625
DEBUG - 2014-08-17 21:47:49 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:49 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:49 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:49 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:49 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:49 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:49 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:49 --> User MX_Controller Initialized
DEBUG - 2014-08-17 21:47:49 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:49 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:47:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:47:50 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:47:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:47:50 --> Final output sent to browser
DEBUG - 2014-08-17 21:47:50 --> Total execution time: 0.7604
DEBUG - 2014-08-17 21:47:52 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:52 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:52 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:52 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:52 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:52 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:52 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:52 --> Client MX_Controller Initialized
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:47:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:47:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:47:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:47:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:47:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:47:53 --> Final output sent to browser
DEBUG - 2014-08-17 21:47:53 --> Total execution time: 0.5869
DEBUG - 2014-08-17 21:47:54 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:54 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:54 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:54 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:55 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:55 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:55 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:55 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:55 --> User MX_Controller Initialized
DEBUG - 2014-08-17 21:47:55 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:47:55 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:47:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:47:55 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:47:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:47:55 --> Final output sent to browser
DEBUG - 2014-08-17 21:47:55 --> Total execution time: 0.7613
DEBUG - 2014-08-17 21:47:59 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:47:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:47:59 --> URI Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Router Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Output Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Security Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Input Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:47:59 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Language Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Config Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Loader Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:47:59 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:47:59 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:47:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:47:59 --> Session Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:47:59 --> Session routines successfully run
DEBUG - 2014-08-17 21:47:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:47:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:47:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:47:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Controller Class Initialized
DEBUG - 2014-08-17 21:47:59 --> Report MX_Controller Initialized
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:47:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:47:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:47:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:00 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:00 --> Total execution time: 0.5736
DEBUG - 2014-08-17 21:48:02 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:48:02 --> URI Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Router Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Output Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Security Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Input Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:48:02 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Loader Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:48:02 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:48:02 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:48:02 --> Session Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:48:02 --> Session routines successfully run
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Controller Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Report MX_Controller Initialized
DEBUG - 2014-08-17 21:48:02 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:48:02 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:48:03 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:48:03 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:03 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:03 --> Total execution time: 0.7975
DEBUG - 2014-08-17 21:48:07 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:48:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:48:07 --> URI Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Router Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Output Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Security Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Input Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:48:07 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Loader Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:48:07 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:48:07 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:48:07 --> Session Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:48:07 --> Session routines successfully run
DEBUG - 2014-08-17 21:48:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:48:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:48:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:48:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Controller Class Initialized
DEBUG - 2014-08-17 21:48:07 --> Report MX_Controller Initialized
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/report/views/generate_report_form.php
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:48:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:48:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:07 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:07 --> Total execution time: 0.5808
DEBUG - 2014-08-17 21:48:12 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:48:12 --> URI Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Router Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Output Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Security Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Input Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:48:12 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Loader Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:48:12 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:48:12 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:48:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:48:12 --> Session Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:48:12 --> Session routines successfully run
DEBUG - 2014-08-17 21:48:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:48:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:48:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:48:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Controller Class Initialized
DEBUG - 2014-08-17 21:48:12 --> Report MX_Controller Initialized
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/report/views/view_report.php
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:48:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:48:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:12 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:12 --> Total execution time: 0.5878
DEBUG - 2014-08-17 21:48:15 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:48:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:48:15 --> URI Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Router Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Output Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Security Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Input Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:48:15 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Loader Class Initialized
DEBUG - 2014-08-17 21:48:15 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:48:15 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:48:15 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:48:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:48:16 --> Session Class Initialized
DEBUG - 2014-08-17 21:48:16 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:48:16 --> Session routines successfully run
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> Controller Class Initialized
DEBUG - 2014-08-17 21:48:16 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:48:16 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:48:16 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:48:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:48:16 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:16 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:16 --> Total execution time: 0.6682
DEBUG - 2014-08-17 21:48:22 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:48:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:48:22 --> URI Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Router Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Output Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Security Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Input Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:48:22 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Loader Class Initialized
DEBUG - 2014-08-17 21:48:22 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:48:22 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:48:22 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:48:23 --> Session Class Initialized
DEBUG - 2014-08-17 21:48:23 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:48:23 --> Session routines successfully run
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> Controller Class Initialized
DEBUG - 2014-08-17 21:48:23 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:48:23 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:48:23 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:48:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:48:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:23 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:23 --> Total execution time: 0.8375
DEBUG - 2014-08-17 21:48:28 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:48:28 --> URI Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Router Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Output Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Security Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Input Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:48:28 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Language Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Config Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Loader Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:48:28 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:48:28 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:48:28 --> Session Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:48:28 --> Session routines successfully run
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Controller Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:48:28 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:48:28 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:48:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:28 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:48:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:48:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:48:29 --> Final output sent to browser
DEBUG - 2014-08-17 21:48:29 --> Total execution time: 0.7623
DEBUG - 2014-08-17 21:49:24 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:24 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:24 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:24 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:24 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:24 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:24 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:25 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:25 --> Employee MX_Controller Initialized
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:49:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:49:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:49:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:49:25 --> Final output sent to browser
DEBUG - 2014-08-17 21:49:25 --> Total execution time: 0.5964
DEBUG - 2014-08-17 21:49:26 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:26 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:26 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:26 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:26 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:27 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:27 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:27 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:27 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:27 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:27 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:27 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:49:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:49:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:49:27 --> Final output sent to browser
DEBUG - 2014-08-17 21:49:27 --> Total execution time: 0.8286
DEBUG - 2014-08-17 21:49:34 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:34 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:34 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:34 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:34 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:34 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:34 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:34 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:34 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:49:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:49:34 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:49:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:49:34 --> Final output sent to browser
DEBUG - 2014-08-17 21:49:34 --> Total execution time: 0.8361
DEBUG - 2014-08-17 21:49:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:41 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:41 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:41 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:42 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:42 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:42 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:42 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:42 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:42 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:42 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:42 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:43 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:43 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:43 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:43 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:43 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:43 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:43 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:44 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:44 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:44 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:44 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:44 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:44 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:44 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:44 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:45 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:45 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:45 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:49:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:49:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:49:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:49:45 --> Final output sent to browser
DEBUG - 2014-08-17 21:49:45 --> Total execution time: 0.9005
DEBUG - 2014-08-17 21:49:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:48 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:48 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:48 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:48 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:48 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:49:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:49:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:49:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:49:49 --> Final output sent to browser
DEBUG - 2014-08-17 21:49:49 --> Total execution time: 0.7753
DEBUG - 2014-08-17 21:49:56 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:56 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:56 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:56 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:56 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:56 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:56 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:56 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:56 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:56 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:57 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:57 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:57 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:57 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:57 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:57 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:57 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:57 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:49:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:49:58 --> URI Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Router Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Output Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Security Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Input Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:49:58 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Language Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Config Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Loader Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:49:58 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:49:58 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:49:58 --> Session Class Initialized
DEBUG - 2014-08-17 21:49:58 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:49:58 --> Session routines successfully run
DEBUG - 2014-08-17 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:49:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:49:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:59 --> Controller Class Initialized
DEBUG - 2014-08-17 21:49:59 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:49:59 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:49:59 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:49:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:49:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:49:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:49:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:49:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:49:59 --> Final output sent to browser
DEBUG - 2014-08-17 21:49:59 --> Total execution time: 1.0135
DEBUG - 2014-08-17 21:50:01 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:02 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:02 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:02 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:02 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:02 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:02 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:50:02 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:02 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:50:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:50:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:50:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:50:02 --> Final output sent to browser
DEBUG - 2014-08-17 21:50:02 --> Total execution time: 0.7962
DEBUG - 2014-08-17 21:50:10 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:10 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:10 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:10 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:10 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:11 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:11 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:11 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:50:11 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:11 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:11 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:11 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:11 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:12 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:12 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:12 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:12 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:50:12 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:12 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:12 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:12 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:12 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:13 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:13 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:13 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:13 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-17 21:50:13 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:13 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:50:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:50:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:50:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:50:13 --> Final output sent to browser
DEBUG - 2014-08-17 21:50:13 --> Total execution time: 0.9465
DEBUG - 2014-08-17 21:50:16 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:16 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:16 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:16 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:17 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:17 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:17 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:17 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:17 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:17 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:50:17 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:17 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:50:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:50:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:50:17 --> Final output sent to browser
DEBUG - 2014-08-17 21:50:17 --> Total execution time: 0.8029
DEBUG - 2014-08-17 21:50:19 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:19 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:19 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:19 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:19 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:19 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:19 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:19 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:50:19 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:20 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:50:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:50:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:50:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:50:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:50:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:50:20 --> Final output sent to browser
DEBUG - 2014-08-17 21:50:20 --> Total execution time: 0.8928
DEBUG - 2014-08-17 21:50:22 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:22 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:22 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:22 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:22 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:22 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:22 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:23 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:23 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:50:23 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:23 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:50:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:50:23 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:50:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:50:23 --> Final output sent to browser
DEBUG - 2014-08-17 21:50:23 --> Total execution time: 0.8382
DEBUG - 2014-08-17 21:50:39 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:39 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:39 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:39 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:40 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:40 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:40 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:50:40 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:40 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:41 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:41 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:41 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:41 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:41 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:41 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:50:41 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:41 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:41 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:50:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:50:42 --> URI Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Router Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Output Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Security Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Input Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:50:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Language Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Config Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Loader Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:50:42 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:50:42 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:50:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:50:42 --> Session Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:50:42 --> Session routines successfully run
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Controller Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:50:42 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:50:42 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:50:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:42 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:50:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:50:43 --> Model Class Initialized
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:50:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:50:43 --> Final output sent to browser
DEBUG - 2014-08-17 21:50:43 --> Total execution time: 1.0038
DEBUG - 2014-08-17 21:52:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:52:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:52:48 --> URI Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Router Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Output Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Security Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Input Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:52:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Loader Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:52:48 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:52:48 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:52:48 --> Session Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:52:48 --> Session routines successfully run
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:52:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:52:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:52:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:52:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:52:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:52:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:52:49 --> Final output sent to browser
DEBUG - 2014-08-17 21:52:49 --> Total execution time: 1.1078
DEBUG - 2014-08-17 21:52:57 --> Config Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:52:57 --> URI Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Router Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Output Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Security Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Input Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:52:57 --> Language Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Language Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Config Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Loader Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:52:57 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:52:57 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:52:57 --> Session Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:52:57 --> Session routines successfully run
DEBUG - 2014-08-17 21:52:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:52:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:52:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:52:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Controller Class Initialized
DEBUG - 2014-08-17 21:52:57 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:52:57 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:52:57 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:52:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:52:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:52:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:52:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:52:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:52:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:52:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:52:58 --> Final output sent to browser
DEBUG - 2014-08-17 21:52:58 --> Total execution time: 0.8513
DEBUG - 2014-08-17 21:53:24 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:24 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:24 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:24 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:24 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:24 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:24 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:24 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:24 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:53:24 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:25 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:25 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:25 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:25 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:25 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:25 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:25 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:25 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:26 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:53:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:26 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:26 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:26 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:27 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:27 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:27 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:27 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:27 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:27 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:53:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:53:27 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:53:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:53:27 --> Final output sent to browser
DEBUG - 2014-08-17 21:53:27 --> Total execution time: 1.0160
DEBUG - 2014-08-17 21:53:32 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:32 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:32 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:32 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:32 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:32 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:32 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:32 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:32 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:33 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:33 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:33 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:53:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:53:33 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:53:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:53:33 --> Final output sent to browser
DEBUG - 2014-08-17 21:53:33 --> Total execution time: 1.2556
DEBUG - 2014-08-17 21:53:38 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:38 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:38 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:38 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:39 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:39 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:39 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:39 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:39 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:39 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:39 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:39 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:39 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:39 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:40 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:40 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:40 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:53:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:53:40 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:53:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:53:40 --> Final output sent to browser
DEBUG - 2014-08-17 21:53:40 --> Total execution time: 0.9479
DEBUG - 2014-08-17 21:53:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:47 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:47 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:47 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:53:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:53:48 --> URI Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Router Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Output Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Security Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Input Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:53:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Language Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Config Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Loader Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:53:48 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:53:48 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:53:48 --> Session Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:53:48 --> Session routines successfully run
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:53:48 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:53:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:53:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:53:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:53:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:53:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:53:49 --> Model Class Initialized
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:53:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:53:49 --> Final output sent to browser
DEBUG - 2014-08-17 21:53:49 --> Total execution time: 0.9675
DEBUG - 2014-08-17 21:54:00 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:54:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:54:00 --> URI Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Router Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Output Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Security Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Input Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:54:00 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Loader Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:54:00 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:54:00 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:54:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:54:00 --> Session Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:54:00 --> Session routines successfully run
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Controller Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:54:00 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:54:00 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:54:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:54:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:54:00 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:54:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:54:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:54:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:54:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:54:01 --> Final output sent to browser
DEBUG - 2014-08-17 21:54:01 --> Total execution time: 0.9760
DEBUG - 2014-08-17 21:54:03 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:54:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:54:03 --> URI Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Router Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Output Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Security Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Input Class Initialized
DEBUG - 2014-08-17 21:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:54:03 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Loader Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:54:04 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:54:04 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:54:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:54:04 --> Session Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:54:04 --> Session routines successfully run
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Controller Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:54:04 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:54:04 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:54:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:54:04 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:54:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:54:04 --> Final output sent to browser
DEBUG - 2014-08-17 21:54:04 --> Total execution time: 0.9505
DEBUG - 2014-08-17 21:54:13 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:54:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:54:13 --> URI Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Router Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Output Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Security Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Input Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:54:13 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Loader Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:54:13 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:54:13 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:54:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:54:13 --> Session Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:54:13 --> Session routines successfully run
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Controller Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:54:13 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:54:13 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:54:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:54:13 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:54:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:54:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:54:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:54:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:54:14 --> Final output sent to browser
DEBUG - 2014-08-17 21:54:14 --> Total execution time: 0.9642
DEBUG - 2014-08-17 21:54:19 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:54:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:54:19 --> URI Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Router Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Output Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Security Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Input Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:54:19 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Language Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Config Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Loader Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:54:19 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:54:19 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:54:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:54:19 --> Session Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:54:19 --> Session routines successfully run
DEBUG - 2014-08-17 21:54:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:54:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:54:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:54:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Controller Class Initialized
DEBUG - 2014-08-17 21:54:19 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:54:20 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:54:20 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:54:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:54:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:54:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:54:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:54:20 --> Model Class Initialized
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:54:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:54:20 --> Final output sent to browser
DEBUG - 2014-08-17 21:54:20 --> Total execution time: 0.9935
DEBUG - 2014-08-17 21:56:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:56:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:56:47 --> URI Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Router Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Output Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Security Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Input Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:56:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Language Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Config Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Loader Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:56:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:56:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:56:47 --> Session Class Initialized
DEBUG - 2014-08-17 21:56:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:56:47 --> Session routines successfully run
DEBUG - 2014-08-17 21:56:47 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> Controller Class Initialized
DEBUG - 2014-08-17 21:56:48 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:56:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:56:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:56:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:56:48 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:56:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:56:48 --> Final output sent to browser
DEBUG - 2014-08-17 21:56:48 --> Total execution time: 0.9923
DEBUG - 2014-08-17 21:56:53 --> Config Class Initialized
DEBUG - 2014-08-17 21:56:53 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:56:53 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:56:54 --> URI Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Router Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Output Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Security Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Input Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:56:54 --> Language Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Language Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Config Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Loader Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:56:54 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:56:54 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:56:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:56:54 --> Session Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:56:54 --> Session routines successfully run
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Controller Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:56:54 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:56:54 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:56:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:56:54 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:56:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:56:54 --> Final output sent to browser
DEBUG - 2014-08-17 21:56:55 --> Total execution time: 1.0256
DEBUG - 2014-08-17 21:56:58 --> Config Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:56:58 --> URI Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Router Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Output Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Security Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Input Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:56:58 --> Language Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Language Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Config Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Loader Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:56:58 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:56:58 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:56:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:56:58 --> Session Class Initialized
DEBUG - 2014-08-17 21:56:58 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:56:58 --> Session routines successfully run
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> Controller Class Initialized
DEBUG - 2014-08-17 21:56:59 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:56:59 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:56:59 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:56:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:56:59 --> Model Class Initialized
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:56:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:56:59 --> Final output sent to browser
DEBUG - 2014-08-17 21:56:59 --> Total execution time: 1.0446
DEBUG - 2014-08-17 21:57:01 --> Config Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:57:01 --> URI Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Router Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Output Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Security Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Input Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:57:01 --> Language Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Language Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Config Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Loader Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:57:01 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:57:01 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:57:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:57:01 --> Session Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:57:01 --> Session routines successfully run
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Controller Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:57:01 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:57:01 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:57:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:57:01 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:57:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:57:02 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:57:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:57:02 --> Final output sent to browser
DEBUG - 2014-08-17 21:57:02 --> Total execution time: 1.0111
DEBUG - 2014-08-17 21:57:06 --> Config Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:57:06 --> URI Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Router Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Output Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Security Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Input Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:57:06 --> Language Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Language Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Config Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Loader Class Initialized
DEBUG - 2014-08-17 21:57:06 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:57:06 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:57:06 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:57:06 --> Session Class Initialized
DEBUG - 2014-08-17 21:57:07 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:57:07 --> Session routines successfully run
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> Controller Class Initialized
DEBUG - 2014-08-17 21:57:07 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:57:07 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:57:07 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:57:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:57:07 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:57:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:57:07 --> Final output sent to browser
DEBUG - 2014-08-17 21:57:07 --> Total execution time: 0.9661
DEBUG - 2014-08-17 21:57:21 --> Config Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:57:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:57:21 --> URI Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Router Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Output Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Security Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Input Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:57:21 --> Language Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Language Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Config Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Loader Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:57:21 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:57:21 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:57:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:57:21 --> Session Class Initialized
DEBUG - 2014-08-17 21:57:21 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:57:21 --> Session routines successfully run
DEBUG - 2014-08-17 21:57:21 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:57:21 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:57:21 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:57:21 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> Controller Class Initialized
DEBUG - 2014-08-17 21:57:22 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:57:22 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:57:22 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:57:22 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:57:22 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:57:22 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:57:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:57:22 --> Model Class Initialized
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:57:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:57:22 --> Final output sent to browser
DEBUG - 2014-08-17 21:57:22 --> Total execution time: 1.0850
DEBUG - 2014-08-17 21:59:17 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:59:17 --> URI Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Router Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Output Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Security Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Input Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:59:17 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Loader Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:59:17 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:59:17 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:59:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:59:17 --> Session Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:59:17 --> Session routines successfully run
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Controller Class Initialized
DEBUG - 2014-08-17 21:59:17 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:59:17 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:59:17 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:59:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:59:17 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:38 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:59:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:59:39 --> URI Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Router Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Output Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Security Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Input Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:59:39 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Loader Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:59:39 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:59:39 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:59:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:59:39 --> Session Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:59:39 --> Session routines successfully run
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Controller Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:59:39 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:59:39 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:59:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:59:39 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:59:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:59:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:59:40 --> Final output sent to browser
DEBUG - 2014-08-17 21:59:40 --> Total execution time: 1.0273
DEBUG - 2014-08-17 21:59:44 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:59:44 --> URI Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Router Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Output Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Security Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Input Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:59:44 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:44 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Loader Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:59:45 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:59:45 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:59:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:59:45 --> Session Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:59:45 --> Session routines successfully run
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Controller Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:59:45 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:59:45 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:59:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:59:45 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:59:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:59:45 --> Final output sent to browser
DEBUG - 2014-08-17 21:59:45 --> Total execution time: 1.0365
DEBUG - 2014-08-17 21:59:57 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Hooks Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Utf8 Class Initialized
DEBUG - 2014-08-17 21:59:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 21:59:57 --> URI Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Router Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Output Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Security Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Input Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 21:59:57 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Language Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Config Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Loader Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Helper loaded: url_helper
DEBUG - 2014-08-17 21:59:57 --> Helper loaded: common_helper
DEBUG - 2014-08-17 21:59:57 --> Database Driver Class Initialized
ERROR - 2014-08-17 21:59:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 21:59:57 --> Session Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Helper loaded: string_helper
DEBUG - 2014-08-17 21:59:57 --> Session routines successfully run
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Controller Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 21:59:57 --> Helper loaded: form_helper
DEBUG - 2014-08-17 21:59:57 --> Form Validation Class Initialized
DEBUG - 2014-08-17 21:59:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 21:59:57 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 21:59:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 21:59:58 --> Model Class Initialized
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 21:59:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 21:59:58 --> Final output sent to browser
DEBUG - 2014-08-17 21:59:58 --> Total execution time: 1.1328
DEBUG - 2014-08-17 22:00:14 --> Config Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:00:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:00:14 --> URI Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Router Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Output Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Security Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Input Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:00:14 --> Language Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Language Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Config Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Loader Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:00:14 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:00:14 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:00:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:00:14 --> Session Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:00:14 --> Session routines successfully run
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Controller Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:00:14 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:00:14 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:00:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:00:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:00:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:00:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:00:15 --> Final output sent to browser
DEBUG - 2014-08-17 22:00:15 --> Total execution time: 1.0674
DEBUG - 2014-08-17 22:00:18 --> Config Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:00:18 --> URI Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Router Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Output Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Security Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Input Class Initialized
DEBUG - 2014-08-17 22:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:00:19 --> Language Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Language Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Config Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Loader Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:00:19 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:00:19 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:00:19 --> Session Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:00:19 --> Session routines successfully run
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Controller Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:00:19 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:00:19 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:00:19 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:00:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:00:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:00:19 --> Final output sent to browser
DEBUG - 2014-08-17 22:00:19 --> Total execution time: 1.0280
DEBUG - 2014-08-17 22:00:23 --> Config Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:00:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:00:23 --> URI Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Router Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Output Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Security Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Input Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:00:23 --> Language Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Language Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Config Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Loader Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:00:23 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:00:23 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:00:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:00:23 --> Session Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:00:23 --> Session routines successfully run
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Controller Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:00:23 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:00:23 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:00:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:00:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:00:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:00:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:00:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:00:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:00:24 --> Final output sent to browser
DEBUG - 2014-08-17 22:00:24 --> Total execution time: 1.0606
DEBUG - 2014-08-17 22:01:11 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:01:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:01:11 --> URI Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Router Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Output Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Security Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Input Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:01:11 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Loader Class Initialized
DEBUG - 2014-08-17 22:01:11 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:01:12 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:01:12 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:01:12 --> Session Class Initialized
DEBUG - 2014-08-17 22:01:12 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:01:12 --> Session routines successfully run
DEBUG - 2014-08-17 22:01:12 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:01:12 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:01:12 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:01:12 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:12 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:12 --> Controller Class Initialized
DEBUG - 2014-08-17 22:01:12 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:01:12 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:01:12 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:01:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:01:12 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:01:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:01:12 --> Final output sent to browser
DEBUG - 2014-08-17 22:01:12 --> Total execution time: 0.8194
DEBUG - 2014-08-17 22:01:14 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:01:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:01:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:01:14 --> URI Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Router Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Output Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Security Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Input Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:01:15 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Loader Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:01:15 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:01:15 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:01:15 --> Session Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:01:15 --> Session routines successfully run
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Controller Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:01:15 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:01:15 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:01:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:01:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:01:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:01:15 --> Final output sent to browser
DEBUG - 2014-08-17 22:01:15 --> Total execution time: 0.9995
DEBUG - 2014-08-17 22:01:18 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:01:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:01:18 --> URI Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Router Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Output Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Security Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Input Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:01:18 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Loader Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:01:18 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:01:18 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:01:18 --> Session Class Initialized
DEBUG - 2014-08-17 22:01:18 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:01:18 --> Session routines successfully run
DEBUG - 2014-08-17 22:01:18 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> Controller Class Initialized
DEBUG - 2014-08-17 22:01:19 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:01:19 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:01:19 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:01:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:01:19 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:01:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:01:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:01:19 --> Final output sent to browser
DEBUG - 2014-08-17 22:01:19 --> Total execution time: 0.9181
DEBUG - 2014-08-17 22:01:40 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:01:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:01:40 --> URI Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Router Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Output Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Security Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Input Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:01:40 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Language Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Config Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Loader Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:01:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:01:40 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:01:40 --> Session Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:01:40 --> Session routines successfully run
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Controller Class Initialized
DEBUG - 2014-08-17 22:01:40 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:01:40 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:01:40 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:01:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:01:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:01:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:01:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:01:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:01:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:01:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:01:41 --> Final output sent to browser
DEBUG - 2014-08-17 22:01:41 --> Total execution time: 1.0790
DEBUG - 2014-08-17 22:02:39 --> Config Class Initialized
DEBUG - 2014-08-17 22:02:39 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:02:39 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:02:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:02:39 --> URI Class Initialized
DEBUG - 2014-08-17 22:02:39 --> Router Class Initialized
DEBUG - 2014-08-17 22:02:39 --> Output Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Security Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Input Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:02:40 --> Language Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Language Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Config Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Loader Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:02:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:02:40 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:02:40 --> Session Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:02:40 --> Session routines successfully run
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Controller Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:02:40 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:02:40 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:02:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:02:40 --> Model Class Initialized
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:02:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:02:40 --> Final output sent to browser
DEBUG - 2014-08-17 22:02:41 --> Total execution time: 1.1099
DEBUG - 2014-08-17 22:06:51 --> Config Class Initialized
DEBUG - 2014-08-17 22:06:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:06:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:06:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:06:51 --> URI Class Initialized
DEBUG - 2014-08-17 22:06:51 --> Router Class Initialized
DEBUG - 2014-08-17 22:06:51 --> Output Class Initialized
DEBUG - 2014-08-17 22:06:51 --> Security Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Input Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:06:52 --> Language Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Language Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Config Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Loader Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:06:52 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:06:52 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:06:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:06:52 --> Session Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:06:52 --> Session routines successfully run
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Controller Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:06:52 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:06:52 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:06:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:06:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:06:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:06:52 --> Final output sent to browser
DEBUG - 2014-08-17 22:06:52 --> Total execution time: 0.9990
DEBUG - 2014-08-17 22:07:26 --> Config Class Initialized
DEBUG - 2014-08-17 22:07:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:07:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:07:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:07:26 --> URI Class Initialized
DEBUG - 2014-08-17 22:07:26 --> Router Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Output Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Security Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Input Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:07:27 --> Language Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Language Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Config Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Loader Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:07:27 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:07:27 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:07:27 --> Session Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:07:27 --> Session routines successfully run
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Controller Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:07:27 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:07:27 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Config Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:07:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:07:28 --> URI Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Router Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Output Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Security Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Input Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:07:28 --> Language Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Language Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Config Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Loader Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:07:28 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:07:28 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:07:28 --> Session Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:07:28 --> Session routines successfully run
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Controller Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:07:28 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:07:28 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:28 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Config Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:07:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:07:29 --> URI Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Router Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Output Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Security Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Input Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:07:29 --> Language Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Language Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Config Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Loader Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:07:29 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:07:29 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:07:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:07:29 --> Session Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:07:29 --> Session routines successfully run
DEBUG - 2014-08-17 22:07:29 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:07:29 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:07:29 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:07:29 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Controller Class Initialized
DEBUG - 2014-08-17 22:07:29 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:07:29 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:07:29 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:07:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:07:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:07:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:07:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:07:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:07:30 --> Final output sent to browser
DEBUG - 2014-08-17 22:07:30 --> Total execution time: 1.1742
DEBUG - 2014-08-17 22:09:05 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:09:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:09:05 --> URI Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Router Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Output Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Security Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Input Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:09:05 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Loader Class Initialized
DEBUG - 2014-08-17 22:09:05 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:09:05 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:09:05 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:09:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:09:06 --> Session Class Initialized
DEBUG - 2014-08-17 22:09:06 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:09:06 --> Session routines successfully run
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> Controller Class Initialized
DEBUG - 2014-08-17 22:09:06 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:09:06 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:09:06 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:09:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:09:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:09:06 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:09:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:09:06 --> Final output sent to browser
DEBUG - 2014-08-17 22:09:06 --> Total execution time: 0.9962
DEBUG - 2014-08-17 22:09:26 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:09:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:09:26 --> URI Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Router Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Output Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Security Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Input Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:09:26 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Loader Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:09:26 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:09:26 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:09:26 --> Session Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:09:26 --> Session routines successfully run
DEBUG - 2014-08-17 22:09:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:09:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:09:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:09:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Controller Class Initialized
DEBUG - 2014-08-17 22:09:26 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:09:26 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:09:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:09:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:09:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:09:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:09:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:09:27 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:09:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:09:27 --> Final output sent to browser
DEBUG - 2014-08-17 22:09:27 --> Total execution time: 0.9087
DEBUG - 2014-08-17 22:09:30 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:09:30 --> URI Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Router Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Output Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Security Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Input Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:09:30 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Loader Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:09:30 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:09:30 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:09:30 --> Session Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:09:30 --> Session routines successfully run
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Controller Class Initialized
DEBUG - 2014-08-17 22:09:30 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:09:30 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:09:30 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:09:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:30 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:09:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:09:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:09:31 --> Final output sent to browser
DEBUG - 2014-08-17 22:09:31 --> Total execution time: 1.2603
DEBUG - 2014-08-17 22:09:34 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:09:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:09:34 --> URI Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Router Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Output Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Security Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Input Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:09:34 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Loader Class Initialized
DEBUG - 2014-08-17 22:09:34 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:09:34 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:09:34 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:09:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:09:35 --> Session Class Initialized
DEBUG - 2014-08-17 22:09:35 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:09:35 --> Session routines successfully run
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> Controller Class Initialized
DEBUG - 2014-08-17 22:09:35 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:09:35 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:09:35 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:09:35 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:09:35 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:35 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:09:35 --> Final output sent to browser
DEBUG - 2014-08-17 22:09:35 --> Total execution time: 0.8263
DEBUG - 2014-08-17 22:09:53 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:09:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:09:53 --> URI Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Router Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Output Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Security Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Input Class Initialized
DEBUG - 2014-08-17 22:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:09:53 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Language Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Config Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Loader Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:09:54 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:09:54 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:09:54 --> Session Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:09:54 --> Session routines successfully run
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Controller Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:09:54 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:09:54 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:09:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:09:54 --> Model Class Initialized
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:09:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:09:54 --> Final output sent to browser
DEBUG - 2014-08-17 22:09:54 --> Total execution time: 1.0108
DEBUG - 2014-08-17 22:10:19 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:19 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:19 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:19 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:19 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:19 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:19 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:19 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:19 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:20 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:20 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:20 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:20 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:20 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:20 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:20 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:20 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:20 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:20 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:20 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:21 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:21 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:21 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:21 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:22 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:22 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:22 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:22 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:22 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:22 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:22 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:10:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:10:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:10:23 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:10:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:10:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:10:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:10:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:10:23 --> Final output sent to browser
DEBUG - 2014-08-17 22:10:23 --> Total execution time: 1.3164
DEBUG - 2014-08-17 22:10:30 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:30 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:30 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:30 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:30 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:30 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:30 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:30 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:30 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:31 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:31 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:31 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:31 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:31 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:31 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:31 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:31 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:31 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:32 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:32 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:32 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:32 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:32 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:32 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:10:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:10:32 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:10:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:10:32 --> Final output sent to browser
DEBUG - 2014-08-17 22:10:32 --> Total execution time: 1.0980
DEBUG - 2014-08-17 22:10:37 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:37 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:37 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:37 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:38 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:38 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:38 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:38 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:38 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:38 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:38 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:38 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:38 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:38 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:38 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:39 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:39 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:39 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:10:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:10:39 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:10:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:10:39 --> Final output sent to browser
DEBUG - 2014-08-17 22:10:39 --> Total execution time: 1.1283
DEBUG - 2014-08-17 22:10:45 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:45 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:45 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:45 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:45 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:45 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:45 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:45 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:10:45 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:45 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:45 --> Model Class Initialized
ERROR - 2014-08-17 22:10:45 --> Severity: Notice  --> Undefined variable: full_amount C:\xampp\htdocs\vmv2\application\modules\payment\views\print_paid_items.php 182
ERROR - 2014-08-17 22:10:45 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\vmv2\application\modules\payment\views\print_paid_items.php 185
ERROR - 2014-08-17 22:10:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\payment\views\print_paid_items.php 185
ERROR - 2014-08-17 22:10:46 --> Severity: Notice  --> Undefined variable: less C:\xampp\htdocs\vmv2\application\modules\payment\views\print_paid_items.php 200
ERROR - 2014-08-17 22:10:46 --> Severity: Notice  --> Undefined variable: full_amount C:\xampp\htdocs\vmv2\application\modules\payment\views\print_paid_items.php 200
DEBUG - 2014-08-17 22:10:46 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:10:46 --> Final output sent to browser
DEBUG - 2014-08-17 22:10:46 --> Total execution time: 0.8708
DEBUG - 2014-08-17 22:10:51 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:52 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:52 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:52 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:52 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:52 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:52 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:52 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:52 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:10:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:10:52 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:10:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:10:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:10:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:10:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:10:53 --> Final output sent to browser
DEBUG - 2014-08-17 22:10:53 --> Total execution time: 1.1343
DEBUG - 2014-08-17 22:10:55 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:10:55 --> URI Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Router Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Output Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Security Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Input Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:10:55 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Language Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Config Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Loader Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:10:55 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:10:55 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:10:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:10:55 --> Session Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:10:55 --> Session routines successfully run
DEBUG - 2014-08-17 22:10:55 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:10:55 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:10:55 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:10:55 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Controller Class Initialized
DEBUG - 2014-08-17 22:10:55 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:10:56 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:10:56 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:10:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:10:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:56 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:10:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:10:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:10:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:10:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:10:56 --> Final output sent to browser
DEBUG - 2014-08-17 22:10:56 --> Total execution time: 1.0806
DEBUG - 2014-08-17 22:11:14 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:11:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:11:14 --> URI Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Router Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Output Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Security Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Input Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:11:14 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Loader Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:11:14 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:11:14 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:11:14 --> Session Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:11:14 --> Session routines successfully run
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Controller Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:11:14 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:11:14 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:11:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:14 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:11:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:11:15 --> URI Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Router Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Output Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Security Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Input Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:11:15 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Loader Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:11:15 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:11:15 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:11:15 --> Session Class Initialized
DEBUG - 2014-08-17 22:11:15 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:11:15 --> Session routines successfully run
DEBUG - 2014-08-17 22:11:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:11:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:11:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:11:16 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Controller Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:11:16 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:11:16 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:11:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:11:16 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:11:16 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:11:16 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:11:16 --> URI Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Router Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Output Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Security Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Input Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:11:16 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:16 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Loader Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:11:17 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:11:17 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:11:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:11:17 --> Session Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:11:17 --> Session routines successfully run
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Controller Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:11:17 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:11:17 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:11:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:11:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:11:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:11:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:11:18 --> Final output sent to browser
DEBUG - 2014-08-17 22:11:18 --> Total execution time: 1.3299
DEBUG - 2014-08-17 22:11:20 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:11:20 --> URI Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Router Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Output Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Security Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Input Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:11:20 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Loader Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:11:20 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:11:20 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:11:20 --> Session Class Initialized
DEBUG - 2014-08-17 22:11:20 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:11:20 --> Session routines successfully run
DEBUG - 2014-08-17 22:11:20 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:11:20 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> Controller Class Initialized
DEBUG - 2014-08-17 22:11:21 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:11:21 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:11:21 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:11:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:11:21 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:11:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:11:21 --> Final output sent to browser
DEBUG - 2014-08-17 22:11:21 --> Total execution time: 1.1699
DEBUG - 2014-08-17 22:11:26 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:11:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:11:26 --> URI Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Router Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Output Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Security Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Input Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:11:26 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Loader Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:11:26 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:11:26 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:11:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:11:26 --> Session Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:11:26 --> Session routines successfully run
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Controller Class Initialized
DEBUG - 2014-08-17 22:11:26 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:11:26 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:11:26 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:11:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:11:26 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:26 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:11:26 --> Final output sent to browser
DEBUG - 2014-08-17 22:11:26 --> Total execution time: 0.8057
DEBUG - 2014-08-17 22:11:47 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:11:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:11:47 --> URI Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Router Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Output Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Security Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Input Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:11:47 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Language Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Config Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Loader Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:11:47 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:11:47 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:11:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:11:47 --> Session Class Initialized
DEBUG - 2014-08-17 22:11:47 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:11:47 --> Session routines successfully run
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> Controller Class Initialized
DEBUG - 2014-08-17 22:11:48 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:11:48 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:11:48 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:11:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:11:48 --> Model Class Initialized
DEBUG - 2014-08-17 22:11:48 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:11:48 --> Final output sent to browser
DEBUG - 2014-08-17 22:11:48 --> Total execution time: 0.8624
DEBUG - 2014-08-17 22:14:16 --> Config Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:14:16 --> URI Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Router Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Output Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Security Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Input Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:14:16 --> Language Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Language Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Config Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Loader Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:14:16 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:14:16 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:14:16 --> Session Class Initialized
DEBUG - 2014-08-17 22:14:16 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:14:17 --> Session routines successfully run
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> Controller Class Initialized
DEBUG - 2014-08-17 22:14:17 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:14:17 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:14:17 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:14:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:14:17 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:17 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:14:17 --> Final output sent to browser
DEBUG - 2014-08-17 22:14:17 --> Total execution time: 0.9167
DEBUG - 2014-08-17 22:14:55 --> Config Class Initialized
DEBUG - 2014-08-17 22:14:55 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:14:55 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:14:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:14:56 --> URI Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Router Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Output Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Security Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Input Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:14:56 --> Language Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Language Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Config Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Loader Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:14:56 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:14:56 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:14:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:14:56 --> Session Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:14:56 --> Session routines successfully run
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Controller Class Initialized
DEBUG - 2014-08-17 22:14:56 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:14:56 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:14:56 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:14:56 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:14:56 --> Model Class Initialized
DEBUG - 2014-08-17 22:14:56 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:14:56 --> Final output sent to browser
DEBUG - 2014-08-17 22:14:56 --> Total execution time: 0.9466
DEBUG - 2014-08-17 22:15:09 --> Config Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:15:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:15:09 --> URI Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Router Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Output Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Security Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Input Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:15:09 --> Language Class Initialized
DEBUG - 2014-08-17 22:15:09 --> Language Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Config Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Loader Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:15:10 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:15:10 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:15:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:15:10 --> Session Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:15:10 --> Session routines successfully run
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Controller Class Initialized
DEBUG - 2014-08-17 22:15:10 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:15:10 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:15:10 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:15:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:15:10 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:10 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:15:10 --> Final output sent to browser
DEBUG - 2014-08-17 22:15:10 --> Total execution time: 0.8166
DEBUG - 2014-08-17 22:15:22 --> Config Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:15:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:15:22 --> URI Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Router Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Output Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Security Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Input Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:15:22 --> Language Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Language Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Config Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Loader Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:15:22 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:15:22 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:15:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:15:22 --> Session Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:15:22 --> Session routines successfully run
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Controller Class Initialized
DEBUG - 2014-08-17 22:15:22 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:15:22 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:15:22 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:15:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:15:22 --> Model Class Initialized
DEBUG - 2014-08-17 22:15:22 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:15:22 --> Final output sent to browser
DEBUG - 2014-08-17 22:15:22 --> Total execution time: 0.9693
DEBUG - 2014-08-17 22:59:06 --> Config Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:59:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:59:06 --> URI Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Router Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Output Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Security Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Input Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:59:06 --> Language Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Language Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Config Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Loader Class Initialized
DEBUG - 2014-08-17 22:59:06 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:59:06 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:59:07 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:59:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:59:07 --> Session Class Initialized
DEBUG - 2014-08-17 22:59:07 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:59:07 --> Session routines successfully run
DEBUG - 2014-08-17 22:59:07 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:59:07 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:59:07 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:59:07 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:07 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:07 --> Controller Class Initialized
DEBUG - 2014-08-17 22:59:07 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:59:07 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:59:07 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:59:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:59:07 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:07 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:59:08 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 22:59:08 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:08 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 22:59:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 22:59:08 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 22:59:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 22:59:08 --> Final output sent to browser
DEBUG - 2014-08-17 22:59:08 --> Total execution time: 2.5840
DEBUG - 2014-08-17 22:59:14 --> Config Class Initialized
DEBUG - 2014-08-17 22:59:14 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:59:14 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:59:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:59:14 --> URI Class Initialized
DEBUG - 2014-08-17 22:59:14 --> Router Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Output Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Security Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Input Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:59:15 --> Language Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Language Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Config Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Loader Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:59:15 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:59:15 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:59:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:59:15 --> Session Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:59:15 --> Session routines successfully run
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Controller Class Initialized
DEBUG - 2014-08-17 22:59:15 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 22:59:15 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:59:15 --> Form Validation Class Initialized
DEBUG - 2014-08-17 22:59:15 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 22:59:15 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:15 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 22:59:15 --> mPDF class is loaded.
ERROR - 2014-08-17 22:59:15 --> Severity: Notice  --> Undefined variable: params C:\xampp\htdocs\vmv2\application\libraries\pdf.php 15
ERROR - 2014-08-17 22:59:15 --> Severity: Warning  --> include(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensed.mtx.php): failed to open stream: No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3018
ERROR - 2014-08-17 22:59:15 --> Severity: Warning  --> include(): Failed opening 'C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensed.mtx.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3018
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined index: unAGlyphs C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3104
ERROR - 2014-08-17 22:59:16 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensed.cgm): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3116
ERROR - 2014-08-17 22:59:16 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensed.z): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3117
ERROR - 2014-08-17 22:59:16 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensed.cw127.php): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3118
ERROR - 2014-08-17 22:59:16 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensed.cw): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3119
ERROR - 2014-08-17 22:59:16 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 22:59:16 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined index: BODY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined offset: -1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1150
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27505
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27608
ERROR - 2014-08-17 22:59:16 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 9158
DEBUG - 2014-08-17 22:59:59 --> Config Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Hooks Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Utf8 Class Initialized
DEBUG - 2014-08-17 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 22:59:59 --> URI Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Router Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Output Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Security Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Input Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 22:59:59 --> Language Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Language Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Config Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Loader Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Helper loaded: url_helper
DEBUG - 2014-08-17 22:59:59 --> Helper loaded: common_helper
DEBUG - 2014-08-17 22:59:59 --> Database Driver Class Initialized
ERROR - 2014-08-17 22:59:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 22:59:59 --> Session Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Helper loaded: string_helper
DEBUG - 2014-08-17 22:59:59 --> Session routines successfully run
DEBUG - 2014-08-17 22:59:59 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 22:59:59 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 22:59:59 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 22:59:59 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Model Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Controller Class Initialized
DEBUG - 2014-08-17 22:59:59 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 22:59:59 --> Helper loaded: form_helper
DEBUG - 2014-08-17 22:59:59 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:00:00 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:00:00 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:00:00 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:00 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:00:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:00:00 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:00:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:00:00 --> Final output sent to browser
DEBUG - 2014-08-17 23:00:00 --> Total execution time: 1.3147
DEBUG - 2014-08-17 23:00:15 --> Config Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:00:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:00:15 --> URI Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Router Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Output Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Security Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Input Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:00:15 --> Language Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Language Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Config Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Loader Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:00:15 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:00:15 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:00:15 --> Session Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:00:15 --> Session routines successfully run
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Controller Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 23:00:15 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:00:15 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:00:15 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:15 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:00:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:00:16 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:00:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:00:16 --> Final output sent to browser
DEBUG - 2014-08-17 23:00:16 --> Total execution time: 1.2077
DEBUG - 2014-08-17 23:00:19 --> Config Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:00:19 --> URI Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Router Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Output Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Security Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Input Class Initialized
DEBUG - 2014-08-17 23:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:00:20 --> Language Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Language Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Config Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Loader Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:00:20 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:00:20 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:00:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:00:20 --> Session Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:00:20 --> Session routines successfully run
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Controller Class Initialized
DEBUG - 2014-08-17 23:00:20 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:00:20 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:00:20 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:00:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:00:20 --> Model Class Initialized
DEBUG - 2014-08-17 23:00:20 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:00:20 --> mPDF class is loaded.
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined variable: params C:\xampp\htdocs\vmv2\application\libraries\pdf.php 15
ERROR - 2014-08-17 23:00:20 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:00:20 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined index: BODY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined offset: -1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1150
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27505
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27608
ERROR - 2014-08-17 23:00:20 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 9158
DEBUG - 2014-08-17 23:00:20 --> Helper loaded: download_helper
DEBUG - 2014-08-17 23:01:31 --> Config Class Initialized
DEBUG - 2014-08-17 23:01:31 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:01:31 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:01:31 --> URI Class Initialized
DEBUG - 2014-08-17 23:01:31 --> Router Class Initialized
DEBUG - 2014-08-17 23:01:31 --> Output Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Security Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Input Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:01:32 --> Language Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Language Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Config Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Loader Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:01:32 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:01:32 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:01:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:01:32 --> Session Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:01:32 --> Session routines successfully run
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Controller Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 23:01:32 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:01:32 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:01:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:01:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:01:33 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:01:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:01:33 --> Final output sent to browser
DEBUG - 2014-08-17 23:01:33 --> Total execution time: 1.4415
DEBUG - 2014-08-17 23:01:36 --> Config Class Initialized
DEBUG - 2014-08-17 23:01:36 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:01:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:01:37 --> URI Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Router Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Output Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Security Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Input Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:01:37 --> Language Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Language Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Config Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Loader Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:01:37 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:01:37 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:01:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:01:37 --> Session Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:01:37 --> Session routines successfully run
DEBUG - 2014-08-17 23:01:37 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:01:37 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:01:37 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:01:37 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Controller Class Initialized
DEBUG - 2014-08-17 23:01:37 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:01:37 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:01:37 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:01:37 --> mPDF class is loaded.
ERROR - 2014-08-17 23:01:37 --> Severity: Notice  --> Undefined variable: params C:\xampp\htdocs\vmv2\application\libraries\pdf.php 15
DEBUG - 2014-08-17 23:01:37 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:01:37 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:01:38 --> Model Class Initialized
DEBUG - 2014-08-17 23:01:38 --> File loaded: application/modules/payment/views/print_paid_items.php
ERROR - 2014-08-17 23:01:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:01:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:01:38 --> Severity: Notice  --> Undefined index: BODY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:01:38 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:01:38 --> Severity: Notice  --> Undefined offset: -1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1150
ERROR - 2014-08-17 23:01:38 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27505
ERROR - 2014-08-17 23:01:38 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27608
ERROR - 2014-08-17 23:01:38 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 9158
DEBUG - 2014-08-17 23:01:38 --> Helper loaded: download_helper
DEBUG - 2014-08-17 23:02:50 --> Config Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:02:50 --> URI Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Router Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Output Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Security Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Input Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:02:50 --> Language Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Language Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Config Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Loader Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:02:50 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:02:50 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:02:50 --> Session Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:02:50 --> Session routines successfully run
DEBUG - 2014-08-17 23:02:50 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:02:50 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:02:50 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:02:50 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Controller Class Initialized
DEBUG - 2014-08-17 23:02:50 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:02:50 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:02:50 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:02:50 --> mPDF class is loaded.
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined variable: params C:\xampp\htdocs\vmv2\application\libraries\pdf.php 15
DEBUG - 2014-08-17 23:02:51 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:02:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:51 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:02:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:02:51 --> File loaded: application/modules/payment/views/print_paid_items.php
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: BODY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined offset: -1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1150
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:51 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:51 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Warning  --> include(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensedB.mtx.php): failed to open stream: No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3018
ERROR - 2014-08-17 23:02:52 --> Severity: Warning  --> include(): Failed opening 'C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensedB.mtx.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3018
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: unAGlyphs C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3104
ERROR - 2014-08-17 23:02:52 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensedB.cgm): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3116
ERROR - 2014-08-17 23:02:52 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensedB.z): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3117
ERROR - 2014-08-17 23:02:52 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensedB.cw127.php): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3118
ERROR - 2014-08-17 23:02:52 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavuserifcondensedB.cw): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3119
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:52 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:52 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:53 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:53 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:54 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:54 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: hyphens C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 5889
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:55 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:55 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:56 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:56 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:57 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:57 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:58 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:58 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: DIV>>ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:02:59 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:02:59 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:00 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:00 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:01 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:01 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: Warning  --> include(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavusanscondensed.mtx.php): failed to open stream: No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3018
ERROR - 2014-08-17 23:03:02 --> Severity: Warning  --> include(): Failed opening 'C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavusanscondensed.mtx.php' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3018
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: unAGlyphs C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3104
ERROR - 2014-08-17 23:03:02 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavusanscondensed.cgm): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3116
ERROR - 2014-08-17 23:03:02 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavusanscondensed.z): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3117
ERROR - 2014-08-17 23:03:02 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavusanscondensed.cw127.php): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3118
ERROR - 2014-08-17 23:03:02 --> Severity: Warning  --> unlink(C:/xampp/htdocs/vmv2/application/third_party/mpdf/ttfontdata/dejavusanscondensed.cw): No such file or directory C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3119
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:03:02 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:03:02 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27505
ERROR - 2014-08-17 23:03:03 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27608
ERROR - 2014-08-17 23:03:03 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 9158
DEBUG - 2014-08-17 23:03:03 --> Helper loaded: download_helper
ERROR - 2014-08-17 23:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 93
ERROR - 2014-08-17 23:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 94
ERROR - 2014-08-17 23:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 95
ERROR - 2014-08-17 23:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 96
ERROR - 2014-08-17 23:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 97
ERROR - 2014-08-17 23:03:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 98
DEBUG - 2014-08-17 23:07:24 --> Config Class Initialized
DEBUG - 2014-08-17 23:07:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:07:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:07:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:07:24 --> URI Class Initialized
DEBUG - 2014-08-17 23:07:24 --> Router Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Output Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Security Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Input Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:07:25 --> Language Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Language Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Config Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Loader Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:07:25 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:07:25 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:07:25 --> Session Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:07:25 --> Session routines successfully run
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Controller Class Initialized
DEBUG - 2014-08-17 23:07:25 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:07:25 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:07:25 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:07:25 --> mPDF class is loaded.
ERROR - 2014-08-17 23:07:25 --> Severity: Notice  --> Undefined variable: params C:\xampp\htdocs\vmv2\application\libraries\pdf.php 15
DEBUG - 2014-08-17 23:07:25 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:07:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:07:25 --> File loaded: application/modules/payment/views/print_paid_items.php
ERROR - 2014-08-17 23:07:25 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:25 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:25 --> Severity: Notice  --> Undefined index: BODY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:25 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:25 --> Severity: Notice  --> Undefined offset: -1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1150
ERROR - 2014-08-17 23:07:25 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:25 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:25 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>>SI C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOP-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>>NAME-DATE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DATETIME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:26 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:26 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>ID>>LOCATION-SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SI_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:27 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:27 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOCATION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>MEDREP C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>MEDREP_NAME C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:28 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>ITEM_HOLDER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:29 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:29 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: hyphens C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 5889
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:30 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:30 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_P2 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:31 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:31 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>LOT_NUM C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:32 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:32 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:33 --> Severity: Notice  --> Undefined index: CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:34 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>EXPIRY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:34 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:34 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>QTY C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>PRICE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:35 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:35 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:37 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:37 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:37 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: DIV>>ID>>ITEMS_END C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:38 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:38 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:39 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DESCRIPTION C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:39 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:39 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:39 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:39 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SPACER_1 C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:39 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:39 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>END_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:41 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:41 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV>>ID>>MID-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV>>ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV>>ID>>DISCOUNT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_RESULT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:42 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:42 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_VAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>DISCOUNT_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:43 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:43 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>SMALL-SPACE C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1003
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>ID>>TOTAL C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>TOTAL_TEXT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>STRONG C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:44 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:44 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CLEAR C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 18502
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:45 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: DIV C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 966
ERROR - 2014-08-17 23:07:45 --> Severity: Notice  --> Undefined index: CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1011
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 969
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>NOPRINT C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CENTER C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>BLOCK C:\xampp\htdocs\vmv2\application\third_party\mpdf\classes\cssmgr.php 1007
ERROR - 2014-08-17 23:07:46 --> Severity: Notice  --> Undefined index: direction C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 15861
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:46 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined index: outline-s C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 3892
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 96
ERROR - 2014-08-17 23:07:47 --> Severity: 8192  --> preg_replace(): The /e modifier is deprecated, use preg_replace_callback instead C:\xampp\htdocs\vmv2\application\third_party\mpdf\includes\functions.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27505
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 27608
ERROR - 2014-08-17 23:07:47 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\xampp\htdocs\vmv2\application\third_party\mpdf\mpdf.php 9158
DEBUG - 2014-08-17 23:07:47 --> Helper loaded: download_helper
ERROR - 2014-08-17 23:07:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 93
ERROR - 2014-08-17 23:07:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 94
ERROR - 2014-08-17 23:07:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 95
ERROR - 2014-08-17 23:07:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 96
ERROR - 2014-08-17 23:07:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 97
ERROR - 2014-08-17 23:07:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\system\core\Exceptions.php:185) C:\xampp\htdocs\vmv2\system\helpers\download_helper.php 98
DEBUG - 2014-08-17 23:09:07 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:09:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:09:07 --> URI Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Router Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Output Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Security Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Input Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:09:07 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Loader Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:09:07 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:09:07 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:09:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:09:07 --> Session Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:09:07 --> Session routines successfully run
DEBUG - 2014-08-17 23:09:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:09:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:09:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:09:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:07 --> Controller Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:09:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:09:24 --> URI Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Router Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Output Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Security Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Input Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:09:24 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:24 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Loader Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:09:25 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:09:25 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:09:25 --> Session Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:09:25 --> Session routines successfully run
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Controller Class Initialized
DEBUG - 2014-08-17 23:09:25 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:09:25 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:09:25 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:09:25 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:09:25 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:25 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:09:25 --> Final output sent to browser
DEBUG - 2014-08-17 23:09:25 --> Total execution time: 1.0947
DEBUG - 2014-08-17 23:09:30 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:09:30 --> URI Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Router Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Output Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Security Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Input Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:09:30 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Loader Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:09:30 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:09:30 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:09:30 --> Session Class Initialized
DEBUG - 2014-08-17 23:09:30 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:09:30 --> Session routines successfully run
DEBUG - 2014-08-17 23:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:09:30 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:31 --> Controller Class Initialized
DEBUG - 2014-08-17 23:09:31 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:09:31 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:09:31 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:09:31 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:09:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:31 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:09:31 --> Final output sent to browser
DEBUG - 2014-08-17 23:09:31 --> Total execution time: 1.1375
DEBUG - 2014-08-17 23:09:38 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:09:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:09:38 --> URI Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Router Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Output Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Security Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Input Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:09:38 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Language Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Config Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Loader Class Initialized
DEBUG - 2014-08-17 23:09:38 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:09:38 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:09:38 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:09:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:09:39 --> Session Class Initialized
DEBUG - 2014-08-17 23:09:39 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:09:39 --> Session routines successfully run
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> Controller Class Initialized
DEBUG - 2014-08-17 23:09:39 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:09:39 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:09:39 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:09:39 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:09:39 --> Model Class Initialized
DEBUG - 2014-08-17 23:09:39 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:09:39 --> Final output sent to browser
DEBUG - 2014-08-17 23:09:39 --> Total execution time: 1.1207
DEBUG - 2014-08-17 23:16:04 --> Config Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:16:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:16:05 --> URI Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Router Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Output Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Security Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Input Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:16:05 --> Language Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Language Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Config Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Loader Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:16:05 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:16:05 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:16:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:16:05 --> Session Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:16:05 --> Session routines successfully run
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Controller Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 23:16:05 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:16:05 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:16:05 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:05 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:16:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:06 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:16:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:16:06 --> Model Class Initialized
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:16:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:16:06 --> Final output sent to browser
DEBUG - 2014-08-17 23:16:06 --> Total execution time: 1.4376
DEBUG - 2014-08-17 23:25:06 --> Config Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:25:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:25:07 --> URI Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Router Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Output Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Security Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Input Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:25:07 --> Language Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Language Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Config Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Loader Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:25:07 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:25:07 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:25:07 --> Session Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:25:07 --> Session routines successfully run
DEBUG - 2014-08-17 23:25:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:25:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:25:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:25:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Controller Class Initialized
DEBUG - 2014-08-17 23:25:07 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:25:07 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:25:07 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:25:07 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:25:07 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:25:08 --> Model Class Initialized
DEBUG - 2014-08-17 23:25:08 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:25:08 --> Final output sent to browser
DEBUG - 2014-08-17 23:25:08 --> Total execution time: 1.1548
DEBUG - 2014-08-17 23:41:30 --> Config Class Initialized
DEBUG - 2014-08-17 23:41:30 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:41:30 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:41:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:41:30 --> URI Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Router Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Output Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Security Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Input Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:41:31 --> Language Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Language Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Config Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Loader Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:41:31 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:41:31 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:41:31 --> Session Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:41:31 --> Session routines successfully run
DEBUG - 2014-08-17 23:41:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:41:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:41:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:41:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Controller Class Initialized
DEBUG - 2014-08-17 23:41:31 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:41:32 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:41:32 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:41:32 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:41:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:41:32 --> Model Class Initialized
DEBUG - 2014-08-17 23:41:32 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:41:32 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:41:32 --> Helper loaded: file_helper
ERROR - 2014-08-17 23:41:32 --> Severity: Warning  --> require_once(C:/xampp/htdocs/vmv2/application/third_party/dompdf/lib/php-font-lib/classes/Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\vmv2\application\third_party\dompdf\dompdf_config.inc.php 332
DEBUG - 2014-08-17 23:42:04 --> Config Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:42:04 --> URI Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Router Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Output Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Security Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Input Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:42:04 --> Language Class Initialized
DEBUG - 2014-08-17 23:42:04 --> Language Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Config Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Loader Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:42:05 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:42:05 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:42:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:42:05 --> Session Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:42:05 --> Session routines successfully run
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Controller Class Initialized
DEBUG - 2014-08-17 23:42:05 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:42:05 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:42:05 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:42:05 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:42:05 --> Model Class Initialized
DEBUG - 2014-08-17 23:42:05 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:42:05 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:42:05 --> Helper loaded: file_helper
ERROR - 2014-08-17 23:42:05 --> Severity: Warning  --> require_once(C:/xampp/htdocs/vmv2/application/third_party/dompdf/lib/php-font-lib/classes/Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\vmv2\application\third_party\dompdf\dompdf_config.inc.php 332
DEBUG - 2014-08-17 23:45:45 --> Config Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:45:45 --> URI Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Router Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Output Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Security Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Input Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:45:45 --> Language Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Language Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Config Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Loader Class Initialized
DEBUG - 2014-08-17 23:45:45 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:45:46 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:45:46 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:45:46 --> Session Class Initialized
DEBUG - 2014-08-17 23:45:46 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:45:46 --> Session routines successfully run
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> Controller Class Initialized
DEBUG - 2014-08-17 23:45:46 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 23:45:46 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:45:46 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:45:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:45:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:45:47 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:45:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:45:47 --> Final output sent to browser
DEBUG - 2014-08-17 23:45:47 --> Total execution time: 1.6776
DEBUG - 2014-08-17 23:45:51 --> Config Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:45:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:45:51 --> URI Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Router Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Output Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Security Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Input Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:45:51 --> Language Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Language Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Config Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Loader Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:45:51 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:45:51 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:45:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:45:51 --> Session Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:45:51 --> Session routines successfully run
DEBUG - 2014-08-17 23:45:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:45:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:45:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:45:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:51 --> Controller Class Initialized
DEBUG - 2014-08-17 23:45:52 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:45:52 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:45:52 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:45:52 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:45:52 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:45:52 --> Model Class Initialized
DEBUG - 2014-08-17 23:45:52 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:45:52 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:45:52 --> Helper loaded: file_helper
ERROR - 2014-08-17 23:45:52 --> Severity: Warning  --> require_once(C:/xampp/htdocs/vmv2/application/third_party/dompdf/lib/php-font-lib/classes/Font.php): failed to open stream: No such file or directory C:\xampp\htdocs\vmv2\application\third_party\dompdf\dompdf_config.inc.php 332
DEBUG - 2014-08-17 23:46:11 --> Config Class Initialized
DEBUG - 2014-08-17 23:46:11 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:46:11 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:46:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:46:12 --> URI Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Router Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Output Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Security Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Input Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:46:12 --> Language Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Language Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Config Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Loader Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:46:12 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:46:12 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:46:12 --> Session Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:46:12 --> Session routines successfully run
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Controller Class Initialized
DEBUG - 2014-08-17 23:46:12 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:46:12 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:46:12 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:46:12 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:46:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:46:12 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:46:12 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:46:12 --> Helper loaded: file_helper
DEBUG - 2014-08-17 23:46:13 --> Final output sent to browser
DEBUG - 2014-08-17 23:46:13 --> Total execution time: 1.6224
DEBUG - 2014-08-17 23:48:28 --> Config Class Initialized
DEBUG - 2014-08-17 23:48:28 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:48:28 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:48:28 --> URI Class Initialized
DEBUG - 2014-08-17 23:48:28 --> Router Class Initialized
DEBUG - 2014-08-17 23:48:28 --> Output Class Initialized
DEBUG - 2014-08-17 23:48:28 --> Security Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Input Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:48:29 --> Language Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Language Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Config Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Loader Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:48:29 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:48:29 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:48:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:48:29 --> Session Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:48:29 --> Session routines successfully run
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Controller Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 23:48:29 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:48:29 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:48:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:48:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:48:30 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:48:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:48:30 --> Final output sent to browser
DEBUG - 2014-08-17 23:48:30 --> Total execution time: 1.5424
DEBUG - 2014-08-17 23:48:34 --> Config Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:48:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:48:34 --> URI Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Router Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Output Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Security Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Input Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:48:34 --> Language Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Language Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Config Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Loader Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:48:34 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:48:34 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:48:34 --> Session Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:48:34 --> Session routines successfully run
DEBUG - 2014-08-17 23:48:34 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:48:34 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:48:34 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:48:34 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Controller Class Initialized
DEBUG - 2014-08-17 23:48:34 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:48:35 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:48:35 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:48:35 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:48:35 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:48:35 --> Model Class Initialized
DEBUG - 2014-08-17 23:48:35 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:48:35 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:48:35 --> Helper loaded: file_helper
DEBUG - 2014-08-17 23:48:35 --> Final output sent to browser
DEBUG - 2014-08-17 23:48:35 --> Total execution time: 1.3662
DEBUG - 2014-08-17 23:49:26 --> Config Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:49:26 --> URI Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Router Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Output Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Security Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Input Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:49:26 --> Language Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Language Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Config Class Initialized
DEBUG - 2014-08-17 23:49:26 --> Loader Class Initialized
DEBUG - 2014-08-17 23:49:27 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:49:27 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:49:27 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:49:27 --> Session Class Initialized
DEBUG - 2014-08-17 23:49:27 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:49:27 --> Session routines successfully run
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> Controller Class Initialized
DEBUG - 2014-08-17 23:49:27 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:49:27 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:49:27 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:49:27 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:49:27 --> Model Class Initialized
DEBUG - 2014-08-17 23:49:27 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:49:27 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:49:27 --> Helper loaded: file_helper
DEBUG - 2014-08-17 23:49:28 --> Final output sent to browser
DEBUG - 2014-08-17 23:49:28 --> Total execution time: 1.5489
DEBUG - 2014-08-17 23:50:09 --> Config Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:50:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:50:09 --> URI Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Router Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Output Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Security Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Input Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:50:09 --> Language Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Language Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Config Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Loader Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:50:09 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:50:09 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:50:09 --> Session Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:50:09 --> Session routines successfully run
DEBUG - 2014-08-17 23:50:09 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:50:09 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:50:09 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:50:09 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Controller Class Initialized
DEBUG - 2014-08-17 23:50:09 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:50:10 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:50:10 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:50:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:50:10 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:50:10 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:10 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:50:10 --> Final output sent to browser
DEBUG - 2014-08-17 23:50:10 --> Total execution time: 1.1208
DEBUG - 2014-08-17 23:50:16 --> Config Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:50:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:50:16 --> URI Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Router Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Output Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Security Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Input Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:50:16 --> Language Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Language Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Config Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Loader Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:50:16 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:50:16 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:50:16 --> Session Class Initialized
DEBUG - 2014-08-17 23:50:16 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:50:16 --> Session routines successfully run
DEBUG - 2014-08-17 23:50:16 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:17 --> Controller Class Initialized
DEBUG - 2014-08-17 23:50:17 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:50:17 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:50:17 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:50:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:50:17 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:17 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:50:17 --> Final output sent to browser
DEBUG - 2014-08-17 23:50:17 --> Total execution time: 1.3760
DEBUG - 2014-08-17 23:50:40 --> Config Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:50:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:50:40 --> URI Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Router Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Output Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Security Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Input Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:50:40 --> Language Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Language Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Config Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Loader Class Initialized
DEBUG - 2014-08-17 23:50:40 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:50:40 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:50:41 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:50:41 --> Session Class Initialized
DEBUG - 2014-08-17 23:50:41 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:50:41 --> Session routines successfully run
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> Controller Class Initialized
DEBUG - 2014-08-17 23:50:41 --> Payment MX_Controller Initialized
DEBUG - 2014-08-17 23:50:41 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:50:41 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:50:41 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:50:41 --> Model Class Initialized
DEBUG - 2014-08-17 23:50:41 --> File loaded: application/modules/payment/views/print_paid_items.php
DEBUG - 2014-08-17 23:50:41 --> Helper loaded: dompdf_helper
DEBUG - 2014-08-17 23:50:41 --> Helper loaded: file_helper
DEBUG - 2014-08-17 23:50:42 --> Final output sent to browser
DEBUG - 2014-08-17 23:50:42 --> Total execution time: 1.5232
DEBUG - 2014-08-17 23:52:11 --> Config Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Hooks Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Utf8 Class Initialized
DEBUG - 2014-08-17 23:52:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-17 23:52:11 --> URI Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Router Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Output Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Security Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Input Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-17 23:52:11 --> Language Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Language Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Config Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Loader Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Helper loaded: url_helper
DEBUG - 2014-08-17 23:52:11 --> Helper loaded: common_helper
DEBUG - 2014-08-17 23:52:11 --> Database Driver Class Initialized
ERROR - 2014-08-17 23:52:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-17 23:52:11 --> Session Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Helper loaded: string_helper
DEBUG - 2014-08-17 23:52:11 --> Session routines successfully run
DEBUG - 2014-08-17 23:52:11 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-17 23:52:11 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-17 23:52:11 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-17 23:52:11 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:11 --> Controller Class Initialized
DEBUG - 2014-08-17 23:52:12 --> Order MX_Controller Initialized
DEBUG - 2014-08-17 23:52:12 --> Helper loaded: form_helper
DEBUG - 2014-08-17 23:52:12 --> Form Validation Class Initialized
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-17 23:52:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-17 23:52:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-17 23:52:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-17 23:52:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-17 23:52:12 --> Model Class Initialized
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-17 23:52:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-17 23:52:12 --> Final output sent to browser
DEBUG - 2014-08-17 23:52:12 --> Total execution time: 1.5706
