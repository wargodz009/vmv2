<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-18 00:09:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:09:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:09:31 --> URI Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Router Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Output Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Security Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Input Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:09:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Loader Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:09:31 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:09:31 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:09:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:09:31 --> Session Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:09:31 --> Session routines successfully run
DEBUG - 2014-08-18 00:09:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:09:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:09:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:09:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Controller Class Initialized
DEBUG - 2014-08-18 00:09:31 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 00:09:31 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:09:31 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:09:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:09:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:09:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:09:32 --> Final output sent to browser
DEBUG - 2014-08-18 00:09:32 --> Total execution time: 0.3206
DEBUG - 2014-08-18 00:09:35 --> Config Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:09:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:09:35 --> URI Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Router Class Initialized
DEBUG - 2014-08-18 00:09:35 --> No URI present. Default controller set.
DEBUG - 2014-08-18 00:09:35 --> Output Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Security Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Input Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:09:35 --> Language Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Language Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Config Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Loader Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:09:35 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:09:35 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:09:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:09:35 --> Session Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:09:35 --> Session routines successfully run
DEBUG - 2014-08-18 00:09:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:09:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:09:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:09:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Controller Class Initialized
DEBUG - 2014-08-18 00:09:35 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:09:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:09:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:09:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:09:35 --> Final output sent to browser
DEBUG - 2014-08-18 00:09:35 --> Total execution time: 0.3279
DEBUG - 2014-08-18 00:09:37 --> Config Class Initialized
DEBUG - 2014-08-18 00:09:37 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:09:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:09:38 --> URI Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Router Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Output Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Security Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Input Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:09:38 --> Language Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Language Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Config Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Loader Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:09:38 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:09:38 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:09:38 --> Session Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:09:38 --> Session routines successfully run
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Controller Class Initialized
DEBUG - 2014-08-18 00:09:38 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:09:38 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:09:38 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:09:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:09:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:09:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:09:38 --> Final output sent to browser
DEBUG - 2014-08-18 00:09:38 --> Total execution time: 0.3542
DEBUG - 2014-08-18 00:11:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:11:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:11:25 --> URI Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Router Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Output Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Security Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Input Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:11:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Loader Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:11:25 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:11:25 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:11:25 --> Session Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:11:25 --> Session routines successfully run
DEBUG - 2014-08-18 00:11:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:11:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:11:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:11:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Controller Class Initialized
DEBUG - 2014-08-18 00:11:25 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:11:25 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:11:25 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:11:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:11:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:11:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:11:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:11:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:11:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:11:26 --> Final output sent to browser
DEBUG - 2014-08-18 00:11:26 --> Total execution time: 0.4934
DEBUG - 2014-08-18 00:11:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:11:29 --> URI Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Router Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Output Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Security Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Input Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:11:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Loader Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:11:29 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:11:29 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:11:29 --> Session Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:11:29 --> Session routines successfully run
DEBUG - 2014-08-18 00:11:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:11:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:11:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:11:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Controller Class Initialized
DEBUG - 2014-08-18 00:11:29 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:11:30 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:11:30 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:11:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:11:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:11:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:11:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:11:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:11:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:11:30 --> Final output sent to browser
DEBUG - 2014-08-18 00:11:30 --> Total execution time: 0.5045
DEBUG - 2014-08-18 00:11:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:11:31 --> URI Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Router Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Output Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Security Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Input Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:11:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Loader Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:11:31 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:11:31 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:11:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:11:31 --> Session Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:11:31 --> Session routines successfully run
DEBUG - 2014-08-18 00:11:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:11:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:11:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:11:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:31 --> Controller Class Initialized
DEBUG - 2014-08-18 00:11:32 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:11:32 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:11:32 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:11:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:11:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:11:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:11:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:11:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:11:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:11:32 --> Final output sent to browser
DEBUG - 2014-08-18 00:11:32 --> Total execution time: 0.5035
DEBUG - 2014-08-18 00:18:15 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:18:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:18:15 --> URI Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Router Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Output Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Security Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Input Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:18:15 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Loader Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:18:15 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:18:15 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:18:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:18:15 --> Session Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:18:15 --> Session routines successfully run
DEBUG - 2014-08-18 00:18:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:18:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:18:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:18:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:15 --> Controller Class Initialized
DEBUG - 2014-08-18 00:18:16 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:18:16 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:18:16 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:18:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:18:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:18:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:18:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:18:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:18:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:18:16 --> Final output sent to browser
DEBUG - 2014-08-18 00:18:16 --> Total execution time: 0.4743
DEBUG - 2014-08-18 00:18:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:18:33 --> URI Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Router Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Output Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Security Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Input Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:18:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Loader Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:18:33 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:18:33 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:18:33 --> Session Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:18:33 --> Session routines successfully run
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Controller Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:18:33 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:18:33 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:18:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:18:33 --> URI Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Router Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Output Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Security Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Input Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:18:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Loader Class Initialized
DEBUG - 2014-08-18 00:18:33 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:18:33 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:18:33 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:18:34 --> Session Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:18:34 --> Session routines successfully run
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Controller Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:18:34 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:18:34 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:18:34 --> URI Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Router Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Output Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Security Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Input Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:18:34 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Language Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Config Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Loader Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:18:34 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:18:34 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:18:34 --> Session Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:18:34 --> Session routines successfully run
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Controller Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:18:34 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:18:34 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:18:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:18:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:18:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:18:35 --> Final output sent to browser
DEBUG - 2014-08-18 00:18:35 --> Total execution time: 0.6604
DEBUG - 2014-08-18 00:19:51 --> Config Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:19:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:19:51 --> URI Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Router Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Output Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Security Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Input Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:19:51 --> Language Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Language Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Config Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Loader Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:19:51 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:19:51 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:19:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:19:51 --> Session Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:19:51 --> Session routines successfully run
DEBUG - 2014-08-18 00:19:51 --> Model Class Initialized
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:19:51 --> Model Class Initialized
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:19:51 --> Model Class Initialized
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:19:51 --> Model Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Model Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Controller Class Initialized
DEBUG - 2014-08-18 00:19:51 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:19:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:19:51 --> Model Class Initialized
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:19:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:19:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:19:51 --> Final output sent to browser
DEBUG - 2014-08-18 00:19:51 --> Total execution time: 0.2800
DEBUG - 2014-08-18 00:21:24 --> Config Class Initialized
DEBUG - 2014-08-18 00:21:24 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:21:24 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:21:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:21:24 --> URI Class Initialized
DEBUG - 2014-08-18 00:21:24 --> Router Class Initialized
DEBUG - 2014-08-18 00:21:24 --> Output Class Initialized
DEBUG - 2014-08-18 00:21:24 --> Security Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Input Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:21:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Loader Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:21:25 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:21:25 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:21:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:21:25 --> Session Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:21:25 --> Session routines successfully run
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Controller Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:21:25 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:21:25 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:21:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:21:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:21:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:21:25 --> Final output sent to browser
DEBUG - 2014-08-18 00:21:25 --> Total execution time: 0.5901
DEBUG - 2014-08-18 00:21:27 --> Config Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:21:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:21:27 --> URI Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Router Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Output Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Security Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Input Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:21:27 --> Language Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Language Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Config Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Loader Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:21:27 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:21:27 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:21:27 --> Session Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:21:27 --> Session routines successfully run
DEBUG - 2014-08-18 00:21:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:21:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:21:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:21:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Controller Class Initialized
DEBUG - 2014-08-18 00:21:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:21:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:21:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:21:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:21:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:21:27 --> Final output sent to browser
DEBUG - 2014-08-18 00:21:27 --> Total execution time: 0.2946
DEBUG - 2014-08-18 00:23:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:23:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:23:25 --> URI Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Router Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Output Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Security Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Input Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:23:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Loader Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:23:25 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:23:25 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:23:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:23:25 --> Session Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:23:25 --> Session routines successfully run
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Controller Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:23:25 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:23:25 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:23:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:23:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:23:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:23:25 --> Final output sent to browser
DEBUG - 2014-08-18 00:23:25 --> Total execution time: 0.5983
DEBUG - 2014-08-18 00:23:28 --> Config Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:23:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:23:28 --> URI Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Router Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Output Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Security Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Input Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:23:28 --> Language Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Language Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Config Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Loader Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:23:28 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:23:28 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:23:28 --> Session Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:23:28 --> Session routines successfully run
DEBUG - 2014-08-18 00:23:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:23:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:23:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:23:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Controller Class Initialized
DEBUG - 2014-08-18 00:23:28 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:23:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:23:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:23:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:23:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:23:28 --> Final output sent to browser
DEBUG - 2014-08-18 00:23:28 --> Total execution time: 0.3479
DEBUG - 2014-08-18 00:24:53 --> Config Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:24:53 --> URI Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Router Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Output Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Security Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Input Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:24:53 --> Language Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Language Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Config Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Loader Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:24:53 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:24:53 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:24:53 --> Session Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:24:53 --> Session routines successfully run
DEBUG - 2014-08-18 00:24:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:24:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:24:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:24:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Controller Class Initialized
DEBUG - 2014-08-18 00:24:53 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:24:54 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:24:54 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:24:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:24:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:24:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:24:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:24:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:24:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:24:54 --> Final output sent to browser
DEBUG - 2014-08-18 00:24:54 --> Total execution time: 0.6063
DEBUG - 2014-08-18 00:24:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:24:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:24:56 --> URI Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Router Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Output Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Security Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Input Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:24:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Loader Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:24:56 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:24:56 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:24:56 --> Session Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:24:56 --> Session routines successfully run
DEBUG - 2014-08-18 00:24:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:24:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:24:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:24:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Controller Class Initialized
DEBUG - 2014-08-18 00:24:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:24:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:24:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:24:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:24:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:24:56 --> Final output sent to browser
DEBUG - 2014-08-18 00:24:56 --> Total execution time: 0.3331
DEBUG - 2014-08-18 00:25:45 --> Config Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:25:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:25:45 --> URI Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Router Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Output Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Security Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Input Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:25:45 --> Language Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Language Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Config Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Loader Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:25:45 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:25:45 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:25:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:25:45 --> Session Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:25:45 --> Session routines successfully run
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Controller Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:25:45 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:25:45 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:25:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:25:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:25:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:25:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:25:46 --> Final output sent to browser
DEBUG - 2014-08-18 00:25:46 --> Total execution time: 0.6204
DEBUG - 2014-08-18 00:25:48 --> Config Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:25:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:25:48 --> URI Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Router Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Output Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Security Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Input Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:25:48 --> Language Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Language Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Config Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Loader Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:25:48 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:25:48 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:25:48 --> Session Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:25:48 --> Session routines successfully run
DEBUG - 2014-08-18 00:25:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:25:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:25:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:25:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Controller Class Initialized
DEBUG - 2014-08-18 00:25:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:25:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:25:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:25:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:25:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:25:48 --> Final output sent to browser
DEBUG - 2014-08-18 00:25:48 --> Total execution time: 0.3122
DEBUG - 2014-08-18 00:26:30 --> Config Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:26:30 --> URI Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Router Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Output Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Security Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Input Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:26:30 --> Language Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Language Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Config Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Loader Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:26:30 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:26:30 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:26:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:26:30 --> Session Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:26:30 --> Session routines successfully run
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Controller Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:26:30 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:26:30 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:26:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:30 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:26:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:26:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:26:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:26:31 --> Final output sent to browser
DEBUG - 2014-08-18 00:26:31 --> Total execution time: 0.6319
DEBUG - 2014-08-18 00:26:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:26:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:26:33 --> URI Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Router Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Output Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Security Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Input Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:26:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Loader Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:26:33 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:26:33 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:26:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:26:33 --> Session Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:26:33 --> Session routines successfully run
DEBUG - 2014-08-18 00:26:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:26:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:26:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:26:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Controller Class Initialized
DEBUG - 2014-08-18 00:26:33 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:26:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:26:33 --> Model Class Initialized
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:26:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:26:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:26:33 --> Final output sent to browser
DEBUG - 2014-08-18 00:26:33 --> Total execution time: 0.3275
DEBUG - 2014-08-18 00:27:39 --> Config Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:27:40 --> URI Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Router Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Output Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Security Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Input Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:27:40 --> Language Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Language Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Config Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Loader Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:27:40 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:27:40 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:27:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:27:40 --> Session Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:27:40 --> Session routines successfully run
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Controller Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:27:40 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:27:40 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:27:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:27:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:27:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:27:40 --> Final output sent to browser
DEBUG - 2014-08-18 00:27:40 --> Total execution time: 0.6266
DEBUG - 2014-08-18 00:27:42 --> Config Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:27:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:27:42 --> URI Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Router Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Output Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Security Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Input Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:27:42 --> Language Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Language Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Config Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Loader Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:27:42 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:27:42 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:27:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:27:42 --> Session Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:27:42 --> Session routines successfully run
DEBUG - 2014-08-18 00:27:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:27:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:27:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:27:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Controller Class Initialized
DEBUG - 2014-08-18 00:27:42 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:27:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:27:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:27:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:27:42 --> Final output sent to browser
DEBUG - 2014-08-18 00:27:42 --> Total execution time: 0.3297
DEBUG - 2014-08-18 00:29:02 --> Config Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:29:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:29:02 --> URI Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Router Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Output Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Security Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Input Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:29:02 --> Language Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Language Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Config Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Loader Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:29:02 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:29:02 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:29:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:29:02 --> Session Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:29:02 --> Session routines successfully run
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Controller Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:29:02 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:29:02 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:29:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:29:03 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:29:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:29:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:29:03 --> Final output sent to browser
DEBUG - 2014-08-18 00:29:03 --> Total execution time: 0.6921
DEBUG - 2014-08-18 00:29:06 --> Config Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:29:06 --> URI Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Router Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Output Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Security Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Input Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:29:06 --> Language Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Language Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Config Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Loader Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:29:06 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:29:06 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:29:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:29:06 --> Session Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:29:06 --> Session routines successfully run
DEBUG - 2014-08-18 00:29:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:29:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:29:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:29:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Controller Class Initialized
DEBUG - 2014-08-18 00:29:06 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:29:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:29:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:29:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:29:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:29:06 --> Final output sent to browser
DEBUG - 2014-08-18 00:29:06 --> Total execution time: 0.5631
DEBUG - 2014-08-18 00:32:44 --> Config Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:32:44 --> URI Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Router Class Initialized
DEBUG - 2014-08-18 00:32:44 --> No URI present. Default controller set.
DEBUG - 2014-08-18 00:32:44 --> Output Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Security Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Input Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:32:44 --> Language Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Language Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Config Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Loader Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:32:44 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:32:44 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:32:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:32:44 --> Session Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:32:44 --> Session routines successfully run
DEBUG - 2014-08-18 00:32:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:32:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:32:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:32:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Controller Class Initialized
DEBUG - 2014-08-18 00:32:44 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:32:44 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-18 00:32:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:32:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:32:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:32:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:32:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:32:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:32:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:32:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:32:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:32:45 --> Final output sent to browser
DEBUG - 2014-08-18 00:32:45 --> Total execution time: 0.4432
DEBUG - 2014-08-18 00:32:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:32:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:32:56 --> URI Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Router Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Output Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Security Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Input Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:32:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Loader Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:32:56 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:32:56 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:32:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:32:56 --> Session Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:32:56 --> Session routines successfully run
DEBUG - 2014-08-18 00:32:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:32:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:32:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:32:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Controller Class Initialized
DEBUG - 2014-08-18 00:32:56 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:32:56 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:32:56 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:32:56 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:32:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Config Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:33:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:33:24 --> URI Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Router Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Output Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Security Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Input Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:33:24 --> Language Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Language Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Config Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Loader Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:33:24 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:33:24 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:33:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:33:24 --> Session Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:33:24 --> Session routines successfully run
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Controller Class Initialized
DEBUG - 2014-08-18 00:33:24 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:33:24 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:33:24 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:33:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:33:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:33:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:33:24 --> Final output sent to browser
DEBUG - 2014-08-18 00:33:24 --> Total execution time: 0.5081
DEBUG - 2014-08-18 00:36:19 --> Config Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:36:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:36:19 --> URI Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Router Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Output Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Security Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Input Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:36:19 --> Language Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Language Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Config Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Loader Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:36:19 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:36:19 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:36:19 --> Session Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:36:19 --> Session routines successfully run
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:36:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:36:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:36:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Controller Class Initialized
DEBUG - 2014-08-18 00:36:19 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:36:19 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:36:19 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:36:19 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:36:19 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:36:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:37:59 --> Config Class Initialized
DEBUG - 2014-08-18 00:37:59 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:37:59 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:38:00 --> URI Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Router Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Output Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Security Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Input Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:38:00 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Loader Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:38:00 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:38:00 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:38:00 --> Session Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:38:00 --> Session routines successfully run
DEBUG - 2014-08-18 00:38:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:38:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:38:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:38:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Controller Class Initialized
DEBUG - 2014-08-18 00:38:00 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:38:00 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:38:00 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:38:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:38:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:38:14 --> URI Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Router Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Output Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Security Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Input Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:38:14 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Loader Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:38:14 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:38:14 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:38:14 --> Session Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:38:14 --> Session routines successfully run
DEBUG - 2014-08-18 00:38:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:38:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:38:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:38:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Controller Class Initialized
DEBUG - 2014-08-18 00:38:14 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:38:14 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:38:14 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:38:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:38:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:38:20 --> URI Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Router Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Output Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Security Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Input Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:38:20 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Loader Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:38:20 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:38:20 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:38:20 --> Session Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:38:20 --> Session routines successfully run
DEBUG - 2014-08-18 00:38:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:38:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:38:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:38:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Controller Class Initialized
DEBUG - 2014-08-18 00:38:20 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:38:20 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:38:20 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:38:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:38:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:38:29 --> URI Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Router Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Output Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Security Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Input Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:38:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Loader Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:38:29 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:38:29 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:38:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:38:29 --> Session Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:38:29 --> Session routines successfully run
DEBUG - 2014-08-18 00:38:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:38:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:38:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:38:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Controller Class Initialized
DEBUG - 2014-08-18 00:38:29 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:38:29 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:38:29 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:38:29 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:38:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:38:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:38:36 --> URI Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Router Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Output Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Security Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Input Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:38:36 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Language Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Config Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Loader Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:38:36 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:38:36 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:38:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:38:36 --> Session Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:38:36 --> Session routines successfully run
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Controller Class Initialized
DEBUG - 2014-08-18 00:38:36 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:38:36 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:38:36 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:38:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:38:36 --> Model Class Initialized
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:38:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:38:36 --> Final output sent to browser
DEBUG - 2014-08-18 00:38:36 --> Total execution time: 0.5137
DEBUG - 2014-08-18 00:39:03 --> Config Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:39:03 --> URI Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Router Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Output Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Security Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Input Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:39:03 --> Language Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Language Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Config Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Loader Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:39:03 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:39:03 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:39:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:39:03 --> Session Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:39:03 --> Session routines successfully run
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Controller Class Initialized
DEBUG - 2014-08-18 00:39:03 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:39:03 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:39:03 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:39:03 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:39:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:39:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:39:03 --> Final output sent to browser
DEBUG - 2014-08-18 00:39:03 --> Total execution time: 0.5248
DEBUG - 2014-08-18 00:42:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:42:16 --> URI Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Router Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Output Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Security Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Input Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:42:16 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Loader Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:42:16 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:42:16 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:42:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:42:16 --> Session Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:42:16 --> Session routines successfully run
DEBUG - 2014-08-18 00:42:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:42:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:42:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:42:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Controller Class Initialized
DEBUG - 2014-08-18 00:42:16 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:42:16 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:42:16 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:42:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:42:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:42:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:42:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:42:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:42:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:42:17 --> Final output sent to browser
DEBUG - 2014-08-18 00:42:17 --> Total execution time: 0.5180
DEBUG - 2014-08-18 00:42:45 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:45 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:42:45 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:42:45 --> URI Class Initialized
DEBUG - 2014-08-18 00:42:45 --> Router Class Initialized
DEBUG - 2014-08-18 00:42:45 --> Output Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Security Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Input Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:42:46 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Loader Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:42:46 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:42:46 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:42:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:42:46 --> Session Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:42:46 --> Session routines successfully run
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Controller Class Initialized
DEBUG - 2014-08-18 00:42:46 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:42:46 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:42:46 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:42:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:42:46 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:42:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:42:46 --> Final output sent to browser
DEBUG - 2014-08-18 00:42:46 --> Total execution time: 0.5207
DEBUG - 2014-08-18 00:42:53 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:42:53 --> URI Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Router Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Output Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Security Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Input Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:42:53 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Loader Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:42:53 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:42:53 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:42:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:42:53 --> Session Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:42:53 --> Session routines successfully run
DEBUG - 2014-08-18 00:42:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:42:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:42:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:42:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Controller Class Initialized
DEBUG - 2014-08-18 00:42:53 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:42:53 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:42:53 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:42:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:42:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:42:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:42:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:42:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:42:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:42:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:42:54 --> Final output sent to browser
DEBUG - 2014-08-18 00:42:54 --> Total execution time: 0.6734
DEBUG - 2014-08-18 00:42:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:42:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:42:56 --> URI Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Router Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Output Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Security Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Input Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:42:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Loader Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:42:56 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:42:56 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:42:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:42:56 --> Session Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:42:56 --> Session routines successfully run
DEBUG - 2014-08-18 00:42:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:42:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:42:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:42:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Controller Class Initialized
DEBUG - 2014-08-18 00:42:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:42:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:42:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:42:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:42:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:42:56 --> Final output sent to browser
DEBUG - 2014-08-18 00:42:56 --> Total execution time: 0.3904
DEBUG - 2014-08-18 00:43:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:43:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:43:09 --> URI Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Router Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Output Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Security Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Input Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:43:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Loader Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:43:09 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:43:09 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:43:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:43:09 --> Session Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:43:09 --> Session routines successfully run
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Controller Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:43:09 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:43:09 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:43:09 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:43:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:43:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:43:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:43:10 --> Final output sent to browser
DEBUG - 2014-08-18 00:43:10 --> Total execution time: 0.7228
DEBUG - 2014-08-18 00:43:11 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:43:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:43:11 --> URI Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Router Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Output Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Security Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Input Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:43:11 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Loader Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:43:11 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:43:11 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:43:11 --> Session Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:43:11 --> Session routines successfully run
DEBUG - 2014-08-18 00:43:11 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:43:11 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:43:11 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:43:11 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Controller Class Initialized
DEBUG - 2014-08-18 00:43:11 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:43:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:43:11 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:43:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:43:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:43:11 --> Final output sent to browser
DEBUG - 2014-08-18 00:43:11 --> Total execution time: 0.4034
DEBUG - 2014-08-18 00:43:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:16 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:43:16 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:43:16 --> URI Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Router Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Output Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Security Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Input Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:43:17 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Loader Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:43:17 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:43:17 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:43:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:43:17 --> Session Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:43:17 --> Session routines successfully run
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Controller Class Initialized
DEBUG - 2014-08-18 00:43:17 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:43:17 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:43:17 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:43:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:43:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:43:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:43:17 --> Final output sent to browser
DEBUG - 2014-08-18 00:43:17 --> Total execution time: 0.5563
DEBUG - 2014-08-18 00:43:20 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:43:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:43:20 --> URI Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Router Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Output Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Security Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Input Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:43:20 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Loader Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:43:20 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:43:20 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:43:20 --> Session Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:43:20 --> Session routines successfully run
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Controller Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:43:20 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:43:20 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:43:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:43:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:43:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:43:20 --> Final output sent to browser
DEBUG - 2014-08-18 00:43:20 --> Total execution time: 0.7035
DEBUG - 2014-08-18 00:43:22 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:43:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:43:22 --> URI Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Router Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Output Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Security Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Input Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:43:22 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Language Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Config Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Loader Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:43:22 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:43:22 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:43:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:43:22 --> Session Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:43:22 --> Session routines successfully run
DEBUG - 2014-08-18 00:43:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:43:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:43:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:43:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Controller Class Initialized
DEBUG - 2014-08-18 00:43:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:43:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:43:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:43:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:43:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:43:22 --> Final output sent to browser
DEBUG - 2014-08-18 00:43:22 --> Total execution time: 0.4034
DEBUG - 2014-08-18 00:45:07 --> Config Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:45:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:45:07 --> URI Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Router Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Output Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Security Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Input Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:45:07 --> Language Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Language Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Config Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Loader Class Initialized
DEBUG - 2014-08-18 00:45:07 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:45:07 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:45:07 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:45:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:45:08 --> Session Class Initialized
DEBUG - 2014-08-18 00:45:08 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:45:08 --> Session routines successfully run
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> Controller Class Initialized
DEBUG - 2014-08-18 00:45:08 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:45:08 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:45:08 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:45:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:45:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:45:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:45:08 --> Final output sent to browser
DEBUG - 2014-08-18 00:45:08 --> Total execution time: 0.7327
DEBUG - 2014-08-18 00:45:10 --> Config Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:45:10 --> URI Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Router Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Output Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Security Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Input Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:45:10 --> Language Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Language Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Config Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Loader Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:45:10 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:45:10 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:45:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:45:10 --> Session Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:45:10 --> Session routines successfully run
DEBUG - 2014-08-18 00:45:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:45:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:45:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:45:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Controller Class Initialized
DEBUG - 2014-08-18 00:45:10 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:45:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:45:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:45:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:45:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:45:10 --> Final output sent to browser
DEBUG - 2014-08-18 00:45:10 --> Total execution time: 0.4643
DEBUG - 2014-08-18 00:46:18 --> Config Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:46:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:46:18 --> URI Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Router Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Output Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Security Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Input Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:46:18 --> Language Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Language Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Config Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Loader Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:46:18 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:46:18 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:46:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:46:18 --> Session Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:46:18 --> Session routines successfully run
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Controller Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:46:18 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:46:18 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:46:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:46:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:46:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:03 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:03 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:03 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:03 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:03 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:03 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:03 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:04 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:04 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:04 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:47:04 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:47:04 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:04 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:04 --> Total execution time: 0.7178
DEBUG - 2014-08-18 00:47:06 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:06 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:06 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:06 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:06 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:06 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:06 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:06 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:06 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:47:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:06 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:06 --> Total execution time: 0.4075
DEBUG - 2014-08-18 00:47:08 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:08 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:08 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:08 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:08 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:08 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:08 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:08 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:47:08 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:47:08 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:08 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:08 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:08 --> Total execution time: 0.5722
DEBUG - 2014-08-18 00:47:13 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:13 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:13 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:13 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:13 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:14 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:14 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:14 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:14 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:14 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:47:14 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:47:14 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:14 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:14 --> Total execution time: 0.8781
DEBUG - 2014-08-18 00:47:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:16 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:16 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:16 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:16 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:16 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:16 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:16 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:47:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:16 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:16 --> Total execution time: 0.4332
DEBUG - 2014-08-18 00:47:17 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:17 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:17 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:17 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:17 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:17 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:17 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:17 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:47:17 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:47:17 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:47:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:18 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:18 --> Total execution time: 0.5937
DEBUG - 2014-08-18 00:47:21 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:21 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:22 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:22 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:22 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:22 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:22 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:22 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:47:22 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:47:22 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:22 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:22 --> Total execution time: 0.7634
DEBUG - 2014-08-18 00:47:24 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:24 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:24 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:24 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:24 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:24 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:24 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:24 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:47:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:24 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:24 --> Total execution time: 0.4536
DEBUG - 2014-08-18 00:47:26 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:26 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:27 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:27 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:27 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:27 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:27 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:47:27 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:47:27 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:27 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:27 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:27 --> Total execution time: 0.7563
DEBUG - 2014-08-18 00:47:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:47:29 --> URI Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Router Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Output Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Security Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Input Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:47:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Loader Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:47:29 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:47:29 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:47:29 --> Session Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:47:29 --> Session routines successfully run
DEBUG - 2014-08-18 00:47:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:47:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:47:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:47:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Controller Class Initialized
DEBUG - 2014-08-18 00:47:29 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:47:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:47:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:47:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:47:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:47:29 --> Final output sent to browser
DEBUG - 2014-08-18 00:47:29 --> Total execution time: 0.4908
DEBUG - 2014-08-18 00:49:02 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:49:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:49:02 --> URI Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Router Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Output Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Security Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Input Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:49:02 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Loader Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:49:02 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:49:02 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:49:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:49:02 --> Session Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:49:02 --> Session routines successfully run
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Controller Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:49:02 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:49:02 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:49:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:49:02 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:49:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:49:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:49:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:49:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:49:03 --> Final output sent to browser
DEBUG - 2014-08-18 00:49:03 --> Total execution time: 0.7810
DEBUG - 2014-08-18 00:49:04 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:49:04 --> URI Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Router Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Output Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Security Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Input Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:49:04 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Loader Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:49:04 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:49:04 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:49:04 --> Session Class Initialized
DEBUG - 2014-08-18 00:49:04 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:49:04 --> Session routines successfully run
DEBUG - 2014-08-18 00:49:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:49:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:49:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:49:05 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:05 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:05 --> Controller Class Initialized
DEBUG - 2014-08-18 00:49:05 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:49:05 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:49:05 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:49:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:49:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:49:05 --> Final output sent to browser
DEBUG - 2014-08-18 00:49:05 --> Total execution time: 0.5269
DEBUG - 2014-08-18 00:49:07 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:49:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:49:07 --> URI Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Router Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Output Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Security Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Input Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:49:07 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Loader Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:49:07 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:49:07 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:49:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:49:07 --> Session Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:49:07 --> Session routines successfully run
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Controller Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:49:07 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:49:07 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:49:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:49:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:49:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:49:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:49:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:49:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:49:08 --> Final output sent to browser
DEBUG - 2014-08-18 00:49:08 --> Total execution time: 0.8666
DEBUG - 2014-08-18 00:49:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:49:09 --> URI Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Router Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Output Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Security Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Input Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:49:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Loader Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:49:09 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:49:09 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:49:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:49:09 --> Session Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:49:09 --> Session routines successfully run
DEBUG - 2014-08-18 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Controller Class Initialized
DEBUG - 2014-08-18 00:49:09 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:49:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:49:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:49:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:49:09 --> Final output sent to browser
DEBUG - 2014-08-18 00:49:09 --> Total execution time: 0.5759
DEBUG - 2014-08-18 00:49:12 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:49:12 --> URI Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Router Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Output Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Security Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Input Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:49:12 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Loader Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:49:12 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:49:12 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:49:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:49:12 --> Session Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:49:12 --> Session routines successfully run
DEBUG - 2014-08-18 00:49:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:49:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:49:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:49:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Controller Class Initialized
DEBUG - 2014-08-18 00:49:12 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:49:12 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:49:12 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:49:12 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:49:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:49:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:49:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:49:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:49:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:49:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:49:13 --> Final output sent to browser
DEBUG - 2014-08-18 00:49:13 --> Total execution time: 0.7751
DEBUG - 2014-08-18 00:49:14 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:14 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:49:14 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:49:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:49:14 --> URI Class Initialized
DEBUG - 2014-08-18 00:49:14 --> Router Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Output Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Security Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Input Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:49:15 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Language Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Config Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Loader Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:49:15 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:49:15 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:49:15 --> Session Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:49:15 --> Session routines successfully run
DEBUG - 2014-08-18 00:49:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:49:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:49:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:49:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Controller Class Initialized
DEBUG - 2014-08-18 00:49:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:49:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:49:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:49:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:49:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:49:15 --> Final output sent to browser
DEBUG - 2014-08-18 00:49:15 --> Total execution time: 0.4970
DEBUG - 2014-08-18 00:50:23 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:23 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:23 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:23 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:23 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:23 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:23 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:50:23 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:50:23 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:23 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:23 --> Total execution time: 0.8234
DEBUG - 2014-08-18 00:50:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:25 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:25 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:25 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:25 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:25 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:25 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:25 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:50:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:26 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:26 --> Total execution time: 0.5176
DEBUG - 2014-08-18 00:50:28 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:28 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:28 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:28 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:28 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:28 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:28 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:50:28 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:50:28 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:50:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:50:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:50:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:29 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:29 --> Total execution time: 0.8154
DEBUG - 2014-08-18 00:50:30 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:30 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:30 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:30 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:30 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:30 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:30 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:30 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:50:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:31 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:31 --> Total execution time: 0.5405
DEBUG - 2014-08-18 00:50:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:31 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:31 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:31 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:31 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:31 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:50:31 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:50:31 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:50:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:50:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:32 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:32 --> Total execution time: 0.9577
DEBUG - 2014-08-18 00:50:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:33 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:33 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:34 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:34 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:34 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:34 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:50:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:34 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:34 --> Total execution time: 0.6707
DEBUG - 2014-08-18 00:50:34 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:50:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:50:34 --> URI Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Router Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Output Class Initialized
DEBUG - 2014-08-18 00:50:34 --> Security Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Input Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:50:35 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Language Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Config Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Loader Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:50:35 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:50:35 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:50:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:50:35 --> Session Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:50:35 --> Session routines successfully run
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Controller Class Initialized
DEBUG - 2014-08-18 00:50:35 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:50:35 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:50:35 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:50:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:50:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:50:35 --> Final output sent to browser
DEBUG - 2014-08-18 00:50:35 --> Total execution time: 0.7735
DEBUG - 2014-08-18 00:51:01 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:01 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:01 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:01 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:01 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:01 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:01 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:01 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:01 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:01 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:01 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:01 --> Total execution time: 0.6940
DEBUG - 2014-08-18 00:51:06 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:06 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:06 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:06 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:06 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:06 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:07 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:07 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:07 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:07 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:07 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:07 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:07 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:07 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:07 --> Total execution time: 0.8228
DEBUG - 2014-08-18 00:51:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:09 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:09 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:09 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:09 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:09 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:09 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:09 --> Total execution time: 0.5614
DEBUG - 2014-08-18 00:51:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:09 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:09 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:09 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:09 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:10 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:10 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:10 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:10 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:10 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:10 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:10 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:10 --> Total execution time: 0.8298
DEBUG - 2014-08-18 00:51:12 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:12 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:12 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:12 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:12 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:12 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:12 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:51:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:12 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:12 --> Total execution time: 0.5419
DEBUG - 2014-08-18 00:51:13 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:13 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:13 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:13 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:13 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:13 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:13 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:13 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:13 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:13 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:13 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:13 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:13 --> Total execution time: 0.7253
DEBUG - 2014-08-18 00:51:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:16 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:16 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:16 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:16 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:16 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:16 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:16 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:16 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:16 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:17 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:17 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:17 --> Total execution time: 0.8403
DEBUG - 2014-08-18 00:51:18 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:18 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:18 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:18 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:18 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:18 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:19 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:19 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:19 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:19 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:19 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:19 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:19 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:51:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:19 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:19 --> Total execution time: 0.5875
DEBUG - 2014-08-18 00:51:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:29 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:29 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:29 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:29 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:29 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:29 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:29 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:29 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:30 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:30 --> Total execution time: 0.8198
DEBUG - 2014-08-18 00:51:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:31 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:31 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:31 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:31 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:31 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:31 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:51:31 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:51:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:32 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:32 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:51:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:51:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:32 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:32 --> Total execution time: 0.5480
DEBUG - 2014-08-18 00:51:42 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:42 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:42 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:42 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:42 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:42 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:42 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:42 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:42 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:42 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:43 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:43 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:43 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:43 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:43 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:43 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:43 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:43 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:43 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:44 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:44 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:44 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:44 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:44 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:44 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:44 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:45 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:45 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:45 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:45 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:45 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:45 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:45 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:45 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:45 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:46 --> Total execution time: 1.1035
DEBUG - 2014-08-18 00:51:47 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:47 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:47 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:47 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:47 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:47 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:47 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:47 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:47 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:47 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:47 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:47 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:51:47 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:51:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:48 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:51:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:48 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:48 --> Total execution time: 0.6355
DEBUG - 2014-08-18 00:51:48 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:48 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:48 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:48 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:48 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:49 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:49 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:49 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:49 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:49 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:49 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:49 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:49 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:49 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:49 --> Total execution time: 0.7138
DEBUG - 2014-08-18 00:51:51 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:51 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:51 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:51 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:52 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:52 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:52 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:52 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:52 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:52 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:52 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:52 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:52 --> Total execution time: 0.8986
DEBUG - 2014-08-18 00:51:54 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:54 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:54 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:54 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:54 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:54 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:54 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:54 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:51:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:54 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:54 --> Total execution time: 0.6132
DEBUG - 2014-08-18 00:51:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:56 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:56 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:56 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:56 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:56 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:56 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:56 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:57 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:57 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:57 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:57 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:57 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:57 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:57 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:57 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Controller Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:51:57 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:51:57 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:57 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:51:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:51:58 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:51:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:51:58 --> Final output sent to browser
DEBUG - 2014-08-18 00:51:58 --> Total execution time: 0.9374
DEBUG - 2014-08-18 00:51:59 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:51:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:51:59 --> URI Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Router Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Output Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Security Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Input Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:51:59 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Language Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Config Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Loader Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:51:59 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:51:59 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:51:59 --> Session Class Initialized
DEBUG - 2014-08-18 00:51:59 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:51:59 --> Session routines successfully run
DEBUG - 2014-08-18 00:51:59 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:51:59 --> Model Class Initialized
DEBUG - 2014-08-18 00:51:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:00 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:00 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:00 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:52:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:00 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:00 --> Total execution time: 0.5985
DEBUG - 2014-08-18 00:52:01 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:01 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:01 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:01 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:01 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:01 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:01 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:01 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:52:01 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:52:01 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:01 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:52:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:02 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:02 --> Total execution time: 0.7750
DEBUG - 2014-08-18 00:52:14 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:14 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:14 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:14 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:14 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:14 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:14 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:14 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:52:14 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:52:14 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:52:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:14 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:52:14 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:15 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:15 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:15 --> Total execution time: 0.7757
DEBUG - 2014-08-18 00:52:18 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:18 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:18 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:18 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:18 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:18 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:18 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:52:18 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:52:18 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:18 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:19 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:19 --> Total execution time: 0.9116
DEBUG - 2014-08-18 00:52:20 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:20 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:20 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:20 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:20 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:20 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:20 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:20 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:21 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:21 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:52:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:21 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:21 --> Total execution time: 0.7226
DEBUG - 2014-08-18 00:52:22 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:22 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:22 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:22 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:22 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:22 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:22 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:22 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:52:22 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:52:22 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:23 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:23 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:23 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:23 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:23 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:23 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:52:23 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:52:23 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:52:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:24 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:24 --> Total execution time: 1.0299
DEBUG - 2014-08-18 00:52:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:25 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:25 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:25 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:26 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:26 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:26 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:26 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:26 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:52:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:26 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:26 --> Total execution time: 0.5977
DEBUG - 2014-08-18 00:52:27 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:27 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:52:27 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:52:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:52:27 --> URI Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Router Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Output Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Security Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Input Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:52:28 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Language Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Config Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Loader Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:52:28 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:52:28 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:52:28 --> Session Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:52:28 --> Session routines successfully run
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Controller Class Initialized
DEBUG - 2014-08-18 00:52:28 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:52:28 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:52:28 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:52:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:52:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:52:28 --> Final output sent to browser
DEBUG - 2014-08-18 00:52:28 --> Total execution time: 0.7963
DEBUG - 2014-08-18 00:53:03 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:03 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:03 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:03 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:03 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:03 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:03 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:03 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:53:03 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:53:03 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:53:03 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 00:53:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:04 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:04 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:04 --> Total execution time: 0.8024
DEBUG - 2014-08-18 00:53:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:09 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:09 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:09 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:09 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:09 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:09 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:10 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:53:10 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:53:10 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:53:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:53:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:53:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:10 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:10 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:10 --> Total execution time: 0.9986
DEBUG - 2014-08-18 00:53:12 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:12 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:12 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:12 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:12 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:12 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:12 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:12 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:12 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:12 --> Total execution time: 0.6689
DEBUG - 2014-08-18 00:53:37 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:37 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:37 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:37 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:37 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:37 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:37 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:37 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:38 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:53:38 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:53:38 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:38 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:38 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:38 --> Total execution time: 0.9853
DEBUG - 2014-08-18 00:53:40 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:40 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:40 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:40 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:40 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:40 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:40 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:40 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:40 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:40 --> Total execution time: 0.6467
DEBUG - 2014-08-18 00:53:48 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:48 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:48 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:48 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:48 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:48 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:48 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:48 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:49 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:49 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:49 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:49 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:49 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:53:49 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:53:49 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:53:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:53:49 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:49 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:49 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:49 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:49 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:50 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:50 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:50 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:50 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:50 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:53:50 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:53:50 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:50 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:50 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:50 --> Total execution time: 0.9885
DEBUG - 2014-08-18 00:53:52 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:53:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:53:52 --> URI Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Router Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Output Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Security Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Input Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:53:52 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Language Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Config Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Loader Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:53:52 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:53:52 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:53:52 --> Session Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:53:52 --> Session routines successfully run
DEBUG - 2014-08-18 00:53:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:53:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:53:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:53:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Controller Class Initialized
DEBUG - 2014-08-18 00:53:52 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:53:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:53:52 --> Model Class Initialized
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:53:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:53:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:53:52 --> Final output sent to browser
DEBUG - 2014-08-18 00:53:52 --> Total execution time: 0.6720
DEBUG - 2014-08-18 00:54:23 --> Config Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:54:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:54:23 --> URI Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Router Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Output Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Security Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Input Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:54:23 --> Language Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Language Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Config Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Loader Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:54:23 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:54:23 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:54:23 --> Session Class Initialized
DEBUG - 2014-08-18 00:54:23 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:54:23 --> Session routines successfully run
DEBUG - 2014-08-18 00:54:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:54:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:54:23 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> Controller Class Initialized
DEBUG - 2014-08-18 00:54:24 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:54:24 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:54:24 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:54:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:54:24 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:54:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:54:24 --> Final output sent to browser
DEBUG - 2014-08-18 00:54:24 --> Total execution time: 1.1857
DEBUG - 2014-08-18 00:54:26 --> Config Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:54:26 --> URI Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Router Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Output Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Security Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Input Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:54:26 --> Language Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Language Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Config Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Loader Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:54:26 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:54:26 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:54:26 --> Session Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:54:26 --> Session routines successfully run
DEBUG - 2014-08-18 00:54:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:54:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:54:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:54:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Controller Class Initialized
DEBUG - 2014-08-18 00:54:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:54:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:54:26 --> Model Class Initialized
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:54:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:54:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:54:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:54:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:54:27 --> Final output sent to browser
DEBUG - 2014-08-18 00:54:27 --> Total execution time: 0.6456
DEBUG - 2014-08-18 00:55:34 --> Config Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:55:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:55:34 --> URI Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Router Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Output Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Security Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Input Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:55:34 --> Language Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Language Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Config Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Loader Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:55:34 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:55:34 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:55:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:55:34 --> Session Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:55:34 --> Session routines successfully run
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Controller Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 00:55:34 --> Helper loaded: form_helper
DEBUG - 2014-08-18 00:55:34 --> Form Validation Class Initialized
DEBUG - 2014-08-18 00:55:34 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:34 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:55:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:55:35 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:55:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:55:35 --> Final output sent to browser
DEBUG - 2014-08-18 00:55:35 --> Total execution time: 1.0217
DEBUG - 2014-08-18 00:55:37 --> Config Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Hooks Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Utf8 Class Initialized
DEBUG - 2014-08-18 00:55:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 00:55:37 --> URI Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Router Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Output Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Security Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Input Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 00:55:37 --> Language Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Language Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Config Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Loader Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Helper loaded: url_helper
DEBUG - 2014-08-18 00:55:37 --> Helper loaded: common_helper
DEBUG - 2014-08-18 00:55:37 --> Database Driver Class Initialized
ERROR - 2014-08-18 00:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 00:55:37 --> Session Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Helper loaded: string_helper
DEBUG - 2014-08-18 00:55:37 --> Session routines successfully run
DEBUG - 2014-08-18 00:55:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 00:55:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 00:55:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 00:55:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Controller Class Initialized
DEBUG - 2014-08-18 00:55:37 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 00:55:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 00:55:37 --> Model Class Initialized
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 00:55:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 00:55:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 00:55:37 --> Final output sent to browser
DEBUG - 2014-08-18 00:55:37 --> Total execution time: 0.6876
DEBUG - 2014-08-18 01:02:42 --> Config Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:02:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:02:42 --> URI Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Router Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Output Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Security Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Input Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:02:42 --> Language Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Language Class Initialized
DEBUG - 2014-08-18 01:02:42 --> Config Class Initialized
DEBUG - 2014-08-18 01:02:43 --> Loader Class Initialized
DEBUG - 2014-08-18 01:02:43 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:02:43 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:02:43 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:02:43 --> Session Class Initialized
DEBUG - 2014-08-18 01:02:43 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:02:43 --> Session routines successfully run
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> Controller Class Initialized
DEBUG - 2014-08-18 01:02:43 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 01:02:43 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:02:43 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:02:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:02:43 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:02:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:02:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:02:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:02:44 --> Final output sent to browser
DEBUG - 2014-08-18 01:02:44 --> Total execution time: 1.4567
DEBUG - 2014-08-18 01:02:47 --> Config Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:02:47 --> URI Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Router Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Output Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Security Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Input Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:02:47 --> Language Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Language Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Config Class Initialized
DEBUG - 2014-08-18 01:02:47 --> Loader Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:02:48 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:02:48 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:02:48 --> Session Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:02:48 --> Session routines successfully run
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Controller Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Order MX_Controller Initialized
DEBUG - 2014-08-18 01:02:48 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:02:48 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:02:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:02:48 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:02:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:02:48 --> Final output sent to browser
DEBUG - 2014-08-18 01:02:48 --> Total execution time: 1.0601
DEBUG - 2014-08-18 01:02:50 --> Config Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:02:50 --> URI Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Router Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Output Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Security Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Input Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:02:50 --> Language Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Language Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Config Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Loader Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:02:50 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:02:50 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:02:50 --> Session Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:02:50 --> Session routines successfully run
DEBUG - 2014-08-18 01:02:50 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:02:50 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:02:50 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:02:50 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Controller Class Initialized
DEBUG - 2014-08-18 01:02:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:02:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:02:50 --> Model Class Initialized
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 01:02:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:02:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:02:50 --> Final output sent to browser
DEBUG - 2014-08-18 01:02:50 --> Total execution time: 0.6483
DEBUG - 2014-08-18 01:03:06 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:06 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:06 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:06 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:07 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:07 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:07 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:07 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:07 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:07 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:07 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:07 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:07 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:07 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:07 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:07 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:07 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:07 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:07 --> Total execution time: 0.8054
DEBUG - 2014-08-18 01:03:10 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:10 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:10 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:10 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:10 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:10 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:10 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:10 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:10 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:10 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:11 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:11 --> Total execution time: 0.9386
DEBUG - 2014-08-18 01:03:12 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:12 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:12 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:12 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:12 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:12 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:12 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:13 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:13 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:13 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 01:03:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:13 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:13 --> Total execution time: 0.7889
DEBUG - 2014-08-18 01:03:16 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:16 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:16 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:16 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:16 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:16 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:16 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:16 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:16 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:16 --> Form Validation Class Initialized
ERROR - 2014-08-18 01:03:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 137
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:17 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:17 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:17 --> Total execution time: 0.8452
DEBUG - 2014-08-18 01:03:24 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:24 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:24 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:24 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:24 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:24 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:24 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:24 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:24 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:24 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:24 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:25 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:25 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:25 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:25 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:25 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:25 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:25 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:25 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:25 --> Total execution time: 0.9583
DEBUG - 2014-08-18 01:03:27 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:27 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:27 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:27 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:27 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:27 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:27 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:27 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:27 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:27 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:27 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:27 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 01:03:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:27 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:27 --> Total execution time: 0.8003
DEBUG - 2014-08-18 01:03:36 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:36 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:36 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:36 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:37 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:37 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:37 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:37 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:37 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:37 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:37 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:37 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:37 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:37 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:37 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/payment/views/manage_paid_items.php
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:37 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:37 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:37 --> Total execution time: 0.8254
DEBUG - 2014-08-18 01:03:43 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:43 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:43 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:43 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:43 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:43 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:43 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:43 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:44 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:44 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:44 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:44 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:44 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Payment MX_Controller Initialized
DEBUG - 2014-08-18 01:03:44 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:03:44 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:44 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:44 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:44 --> Total execution time: 0.9416
DEBUG - 2014-08-18 01:03:46 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:46 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:46 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Language Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Loader Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:03:46 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:03:46 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:03:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:03:46 --> Session Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:03:46 --> Session routines successfully run
DEBUG - 2014-08-18 01:03:46 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:03:46 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:03:46 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:03:46 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Controller Class Initialized
DEBUG - 2014-08-18 01:03:46 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:03:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:03:46 --> Model Class Initialized
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 01:03:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:03:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:03:46 --> Final output sent to browser
DEBUG - 2014-08-18 01:03:46 --> Total execution time: 0.6740
DEBUG - 2014-08-18 01:03:59 --> Config Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:03:59 --> URI Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Router Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Output Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Security Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Input Class Initialized
DEBUG - 2014-08-18 01:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:03:59 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:00 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:00 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:00 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:00 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:00 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:00 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:00 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:00 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:00 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:00 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:00 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:00 --> Total execution time: 0.7929
DEBUG - 2014-08-18 01:04:03 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:03 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:03 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:03 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:03 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:03 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:03 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:03 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:03 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:03 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:04 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:04 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:04 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:04 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:04 --> Employee MX_Controller Initialized
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:04 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:04 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:04 --> Total execution time: 0.7764
DEBUG - 2014-08-18 01:04:08 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:08 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:08 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:08 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:08 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:08 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:08 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:08 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:08 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:08 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:08 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:08 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:09 --> User MX_Controller Initialized
DEBUG - 2014-08-18 01:04:09 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:04:09 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:04:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 01:04:09 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:09 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:09 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:09 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:09 --> Total execution time: 1.0255
DEBUG - 2014-08-18 01:04:10 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:10 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:10 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:10 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:11 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:11 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:11 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:11 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:11 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:11 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:11 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:11 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:11 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:11 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 01:04:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:11 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:11 --> Total execution time: 0.7617
DEBUG - 2014-08-18 01:04:12 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:12 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:12 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:12 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:12 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:12 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:12 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:12 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:12 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:12 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:12 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:12 --> Client MX_Controller Initialized
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:13 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:13 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:13 --> Total execution time: 0.7810
DEBUG - 2014-08-18 01:04:16 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:16 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:16 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:16 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:16 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:16 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:16 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:16 --> Report MX_Controller Initialized
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:16 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:16 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:16 --> Total execution time: 0.7909
DEBUG - 2014-08-18 01:04:21 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:21 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:21 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:21 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:21 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:21 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:21 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Setting MX_Controller Initialized
DEBUG - 2014-08-18 01:04:21 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:04:21 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-18 01:04:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:22 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:22 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:22 --> Total execution time: 0.9672
DEBUG - 2014-08-18 01:04:23 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:23 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:23 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:23 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:23 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:23 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:23 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:23 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:23 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:23 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:23 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:24 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:24 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:24 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-18 01:04:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:24 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:24 --> Total execution time: 0.7292
DEBUG - 2014-08-18 01:04:34 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:34 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:34 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:34 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:34 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:34 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:34 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:34 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:34 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:34 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:35 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:35 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:35 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:35 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:35 --> Setting MX_Controller Initialized
DEBUG - 2014-08-18 01:04:35 --> Helper loaded: form_helper
DEBUG - 2014-08-18 01:04:35 --> Form Validation Class Initialized
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:35 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:35 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:35 --> Total execution time: 0.8715
DEBUG - 2014-08-18 01:04:38 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:38 --> Hooks Class Initialized
DEBUG - 2014-08-18 01:04:38 --> Utf8 Class Initialized
DEBUG - 2014-08-18 01:04:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-18 01:04:39 --> URI Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Router Class Initialized
DEBUG - 2014-08-18 01:04:39 --> No URI present. Default controller set.
DEBUG - 2014-08-18 01:04:39 --> Output Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Security Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Input Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-18 01:04:39 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Language Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Config Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Loader Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Helper loaded: url_helper
DEBUG - 2014-08-18 01:04:39 --> Helper loaded: common_helper
DEBUG - 2014-08-18 01:04:39 --> Database Driver Class Initialized
ERROR - 2014-08-18 01:04:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-18 01:04:39 --> Session Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Helper loaded: string_helper
DEBUG - 2014-08-18 01:04:39 --> Session routines successfully run
DEBUG - 2014-08-18 01:04:39 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-18 01:04:39 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-18 01:04:39 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-18 01:04:39 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Controller Class Initialized
DEBUG - 2014-08-18 01:04:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-18 01:04:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-18 01:04:39 --> Model Class Initialized
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-18 01:04:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-18 01:04:39 --> Final output sent to browser
DEBUG - 2014-08-18 01:04:39 --> Total execution time: 0.8354
