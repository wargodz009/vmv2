<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-22 22:27:17 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:17 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:27:17 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:27:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:27:17 --> URI Class Initialized
DEBUG - 2014-08-22 22:27:17 --> Router Class Initialized
DEBUG - 2014-08-22 22:27:17 --> No URI present. Default controller set.
DEBUG - 2014-08-22 22:27:18 --> Output Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Security Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Input Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:27:18 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Loader Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:27:18 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:27:18 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:27:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:27:18 --> Session Class Initialized
DEBUG - 2014-08-22 22:27:18 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:27:18 --> A session cookie was not found.
DEBUG - 2014-08-22 22:27:18 --> Session routines successfully run
DEBUG - 2014-08-22 22:27:18 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Controller Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 22:27:19 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:27:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:27:19 --> URI Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Router Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Output Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Security Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Input Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:27:19 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Loader Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:27:19 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:27:19 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:27:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:27:19 --> Session Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:27:19 --> Session routines successfully run
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Controller Class Initialized
DEBUG - 2014-08-22 22:27:19 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:27:19 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:27:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:27:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:27:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:27:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:27:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:27:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:27:20 --> Final output sent to browser
DEBUG - 2014-08-22 22:27:20 --> Total execution time: 0.6350
DEBUG - 2014-08-22 22:27:26 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:27:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:27:26 --> URI Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Router Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Output Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Security Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Input Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:27:26 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Loader Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:27:26 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:27:26 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:27:26 --> Session Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:27:26 --> Session routines successfully run
DEBUG - 2014-08-22 22:27:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:27:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:27:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:27:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Controller Class Initialized
DEBUG - 2014-08-22 22:27:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 22:27:27 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:27:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:27:27 --> URI Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Router Class Initialized
DEBUG - 2014-08-22 22:27:27 --> No URI present. Default controller set.
DEBUG - 2014-08-22 22:27:27 --> Output Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Security Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Input Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:27:27 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Language Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Config Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Loader Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:27:27 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:27:27 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:27:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:27:27 --> Session Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:27:27 --> Session routines successfully run
DEBUG - 2014-08-22 22:27:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:27:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:27:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:27:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Controller Class Initialized
DEBUG - 2014-08-22 22:27:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:27:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:27:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:27:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:27:27 --> Final output sent to browser
DEBUG - 2014-08-22 22:27:27 --> Total execution time: 0.6325
DEBUG - 2014-08-22 22:37:03 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:37:03 --> URI Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Router Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Output Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Security Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Input Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:37:03 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Loader Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:37:03 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:37:03 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:37:03 --> Session Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:37:03 --> Session routines successfully run
DEBUG - 2014-08-22 22:37:03 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:37:03 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:37:03 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:37:03 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:03 --> Controller Class Initialized
DEBUG - 2014-08-22 22:37:04 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:37:04 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:37:04 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:37:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:37:04 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:04 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:37:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:37:04 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:37:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:37:04 --> Final output sent to browser
DEBUG - 2014-08-22 22:37:04 --> Total execution time: 1.0679
DEBUG - 2014-08-22 22:37:15 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:37:15 --> URI Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Router Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Output Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Security Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Input Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:37:15 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Loader Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:37:15 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:37:15 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:37:15 --> Session Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:37:15 --> Session routines successfully run
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Controller Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:37:15 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:37:15 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:37:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:37:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:37:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:37:15 --> Final output sent to browser
DEBUG - 2014-08-22 22:37:15 --> Total execution time: 0.6427
DEBUG - 2014-08-22 22:37:42 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:37:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:37:42 --> URI Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Router Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Output Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Security Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Input Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:37:42 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Loader Class Initialized
DEBUG - 2014-08-22 22:37:42 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:37:42 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:37:42 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:37:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:37:43 --> Session Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:37:43 --> Session routines successfully run
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Controller Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:37:43 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:37:43 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:37:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:37:43 --> URI Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Router Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Output Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Security Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Input Class Initialized
DEBUG - 2014-08-22 22:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:37:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Loader Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:37:44 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:37:44 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:37:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:37:44 --> Session Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:37:44 --> Session routines successfully run
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Controller Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:37:44 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:37:44 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:37:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:37:45 --> URI Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Router Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Output Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Security Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Input Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:37:45 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Language Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Config Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Loader Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:37:45 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:37:45 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:37:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:37:45 --> Session Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:37:45 --> Session routines successfully run
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Controller Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:37:45 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:37:45 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:37:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:37:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:37:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:37:45 --> Final output sent to browser
DEBUG - 2014-08-22 22:37:45 --> Total execution time: 0.7234
DEBUG - 2014-08-22 22:38:26 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:38:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:38:26 --> URI Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Router Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Output Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Security Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Input Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:38:26 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Loader Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:38:26 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:38:26 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:38:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:38:26 --> Session Class Initialized
DEBUG - 2014-08-22 22:38:26 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:38:26 --> Session routines successfully run
DEBUG - 2014-08-22 22:38:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:38:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:38:26 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:38:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:27 --> Controller Class Initialized
DEBUG - 2014-08-22 22:38:27 --> Permission MX_Controller Initialized
DEBUG - 2014-08-22 22:38:27 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:38:27 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:38:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:38:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:38:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:38:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:38:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:38:27 --> Final output sent to browser
DEBUG - 2014-08-22 22:38:27 --> Total execution time: 0.7726
DEBUG - 2014-08-22 22:38:30 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:38:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:38:30 --> URI Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Router Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Output Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Security Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Input Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:38:30 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Loader Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:38:30 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:38:30 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:38:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:38:30 --> Session Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:38:30 --> Session routines successfully run
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Controller Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:38:30 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:38:30 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:38:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:38:31 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:38:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:38:31 --> Final output sent to browser
DEBUG - 2014-08-22 22:38:31 --> Total execution time: 0.6753
DEBUG - 2014-08-22 22:38:33 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:38:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:38:33 --> URI Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Router Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Output Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Security Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Input Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:38:33 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Loader Class Initialized
DEBUG - 2014-08-22 22:38:33 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:38:33 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:38:33 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:38:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:38:34 --> Session Class Initialized
DEBUG - 2014-08-22 22:38:34 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:38:34 --> Session routines successfully run
DEBUG - 2014-08-22 22:38:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:38:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:38:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:38:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:34 --> Controller Class Initialized
DEBUG - 2014-08-22 22:38:34 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:38:34 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:38:34 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/setting/views/maintenance_page.php
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:38:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:38:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:38:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:38:34 --> Final output sent to browser
DEBUG - 2014-08-22 22:38:34 --> Total execution time: 0.5686
DEBUG - 2014-08-22 22:38:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:38:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:38:38 --> URI Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Router Class Initialized
DEBUG - 2014-08-22 22:38:38 --> No URI present. Default controller set.
DEBUG - 2014-08-22 22:38:38 --> Output Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Security Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Input Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:38:38 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Loader Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:38:38 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:38:38 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:38:38 --> Session Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:38:38 --> Session routines successfully run
DEBUG - 2014-08-22 22:38:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:38:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:38:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:38:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Controller Class Initialized
DEBUG - 2014-08-22 22:38:38 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:38:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:38:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:38:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:38:38 --> Final output sent to browser
DEBUG - 2014-08-22 22:38:38 --> Total execution time: 0.5562
DEBUG - 2014-08-22 22:38:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:38:44 --> URI Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Router Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Output Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Security Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Input Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:38:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Loader Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:38:44 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:38:44 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:38:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:38:44 --> Session Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:38:44 --> Session routines successfully run
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Controller Class Initialized
DEBUG - 2014-08-22 22:38:44 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 22:38:44 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:38:44 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:38:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:38:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:38:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:38:44 --> Final output sent to browser
DEBUG - 2014-08-22 22:38:44 --> Total execution time: 0.8292
DEBUG - 2014-08-22 22:42:30 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:42:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:42:30 --> URI Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Router Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Output Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Security Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Input Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:42:30 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Loader Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:42:30 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:42:30 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:42:30 --> Session Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:42:30 --> Session routines successfully run
DEBUG - 2014-08-22 22:42:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:42:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:42:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:42:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Controller Class Initialized
DEBUG - 2014-08-22 22:42:30 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 22:42:30 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:42:30 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:42:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:42:30 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:42:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:42:30 --> Final output sent to browser
DEBUG - 2014-08-22 22:42:30 --> Total execution time: 0.6104
DEBUG - 2014-08-22 22:42:34 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:34 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:42:35 --> URI Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Router Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Output Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Security Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Input Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:42:35 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Loader Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:42:35 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:42:35 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:42:35 --> Session Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:42:35 --> Session routines successfully run
DEBUG - 2014-08-22 22:42:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:42:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:42:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:42:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Controller Class Initialized
DEBUG - 2014-08-22 22:42:35 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:42:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:42:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:42:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:42:35 --> Final output sent to browser
DEBUG - 2014-08-22 22:42:35 --> Total execution time: 0.5339
DEBUG - 2014-08-22 22:42:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:42:38 --> URI Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Router Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Output Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Security Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Input Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:42:38 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Loader Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:42:38 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:42:38 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:42:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:42:38 --> Session Class Initialized
DEBUG - 2014-08-22 22:42:38 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:42:38 --> Session routines successfully run
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> Controller Class Initialized
DEBUG - 2014-08-22 22:42:39 --> Item MX_Controller Initialized
DEBUG - 2014-08-22 22:42:39 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:42:39 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:42:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:42:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:42:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:42:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:42:39 --> Final output sent to browser
DEBUG - 2014-08-22 22:42:39 --> Total execution time: 0.7511
DEBUG - 2014-08-22 22:42:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:42:44 --> URI Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Router Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Output Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Security Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Input Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:42:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Loader Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:42:44 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:42:44 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:42:44 --> Session Class Initialized
DEBUG - 2014-08-22 22:42:44 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:42:44 --> Session routines successfully run
DEBUG - 2014-08-22 22:42:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:42:44 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:42:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:42:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:45 --> Controller Class Initialized
DEBUG - 2014-08-22 22:42:45 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:42:45 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:42:45 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:42:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:42:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:45 --> Model Class Initialized
ERROR - 2014-08-22 22:42:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\setting\models\setting_model.php 9
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:42:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:42:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:42:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:42:45 --> Final output sent to browser
DEBUG - 2014-08-22 22:42:45 --> Total execution time: 0.8312
DEBUG - 2014-08-22 22:44:09 --> Config Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:44:09 --> URI Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Router Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Output Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Security Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Input Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:44:09 --> Language Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Language Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Config Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Loader Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:44:09 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:44:09 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:44:09 --> Session Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:44:09 --> Session routines successfully run
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Controller Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:44:09 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:44:09 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:09 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:44:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:44:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:44:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:44:10 --> Final output sent to browser
DEBUG - 2014-08-22 22:44:10 --> Total execution time: 0.7709
DEBUG - 2014-08-22 22:45:06 --> Config Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:45:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:45:06 --> URI Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Router Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Output Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Security Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Input Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:45:06 --> Language Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Language Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Config Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Loader Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:45:06 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:45:06 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:45:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:45:06 --> Session Class Initialized
DEBUG - 2014-08-22 22:45:06 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:45:06 --> Session routines successfully run
DEBUG - 2014-08-22 22:45:06 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> Controller Class Initialized
DEBUG - 2014-08-22 22:45:07 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:45:07 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:45:07 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:45:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:45:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:45:07 --> Model Class Initialized
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:45:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:45:07 --> Final output sent to browser
DEBUG - 2014-08-22 22:45:07 --> Total execution time: 0.8390
DEBUG - 2014-08-22 22:49:59 --> Config Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:49:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:49:59 --> URI Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Router Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Output Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Security Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Input Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:49:59 --> Language Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Language Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Config Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Loader Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:49:59 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:49:59 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:49:59 --> Session Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:49:59 --> Session routines successfully run
DEBUG - 2014-08-22 22:49:59 --> Model Class Initialized
DEBUG - 2014-08-22 22:49:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:49:59 --> Model Class Initialized
DEBUG - 2014-08-22 22:49:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:49:59 --> Model Class Initialized
DEBUG - 2014-08-22 22:49:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:49:59 --> Model Class Initialized
DEBUG - 2014-08-22 22:49:59 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:00 --> Controller Class Initialized
DEBUG - 2014-08-22 22:50:00 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:50:00 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:50:00 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:50:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:50:00 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:00 --> Model Class Initialized
ERROR - 2014-08-22 22:50:00 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\vmv2\application\modules\batch\controllers\batch.php 59
ERROR - 2014-08-22 22:50:00 --> Severity: Notice  --> Object of class stdClass to string conversion C:\xampp\htdocs\vmv2\application\modules\batch\controllers\batch.php 59
ERROR - 2014-08-22 22:50:00 --> Severity: Notice  --> Undefined variable: Object C:\xampp\htdocs\vmv2\application\modules\batch\controllers\batch.php 59
ERROR - 2014-08-22 22:50:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\batch\controllers\batch.php 59
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:50:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:50:00 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:50:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:50:00 --> Final output sent to browser
DEBUG - 2014-08-22 22:50:00 --> Total execution time: 0.8117
DEBUG - 2014-08-22 22:50:26 --> Config Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:50:26 --> URI Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Router Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Output Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Security Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Input Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:50:26 --> Language Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Language Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Config Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Loader Class Initialized
DEBUG - 2014-08-22 22:50:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:50:27 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:50:27 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:50:27 --> Session Class Initialized
DEBUG - 2014-08-22 22:50:27 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:50:27 --> Session routines successfully run
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> Controller Class Initialized
DEBUG - 2014-08-22 22:50:27 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:50:27 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:50:27 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:50:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:50:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:50:27 --> Model Class Initialized
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:50:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:50:27 --> Final output sent to browser
DEBUG - 2014-08-22 22:50:27 --> Total execution time: 0.7921
DEBUG - 2014-08-22 22:51:16 --> Config Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:51:16 --> URI Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Router Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Output Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Security Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Input Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:51:16 --> Language Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Language Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Config Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Loader Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:51:16 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:51:16 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:51:16 --> Session Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:51:16 --> Session routines successfully run
DEBUG - 2014-08-22 22:51:16 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:51:16 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:51:16 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:51:16 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:16 --> Controller Class Initialized
DEBUG - 2014-08-22 22:51:17 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:51:17 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:51:17 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:51:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:51:17 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:17 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:51:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:51:17 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:51:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:51:17 --> Final output sent to browser
DEBUG - 2014-08-22 22:51:17 --> Total execution time: 0.7951
DEBUG - 2014-08-22 22:51:46 --> Config Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:51:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:51:46 --> URI Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Router Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Output Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Security Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Input Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:51:46 --> Language Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Language Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Config Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Loader Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:51:46 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:51:46 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:51:46 --> Session Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:51:46 --> Session routines successfully run
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Controller Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:51:46 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:51:46 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:51:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:51:46 --> Model Class Initialized
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:51:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:51:46 --> Final output sent to browser
DEBUG - 2014-08-22 22:51:46 --> Total execution time: 0.7863
DEBUG - 2014-08-22 22:52:19 --> Config Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:52:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:52:19 --> URI Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Router Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Output Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Security Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Input Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:52:19 --> Language Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Language Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Config Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Loader Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:52:19 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:52:19 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:52:19 --> Session Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:52:19 --> Session routines successfully run
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Controller Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:52:19 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:52:19 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:52:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:52:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:52:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:52:20 --> Final output sent to browser
DEBUG - 2014-08-22 22:52:20 --> Total execution time: 0.8128
DEBUG - 2014-08-22 22:52:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:52:38 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:52:38 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:52:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:52:38 --> URI Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Router Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Output Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Security Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Input Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:52:39 --> Language Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Language Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Config Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Loader Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:52:39 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:52:39 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:52:39 --> Session Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:52:39 --> Session routines successfully run
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Controller Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:52:39 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:52:39 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:52:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:52:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:52:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:52:39 --> Final output sent to browser
DEBUG - 2014-08-22 22:52:39 --> Total execution time: 0.8100
DEBUG - 2014-08-22 22:52:51 --> Config Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:52:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:52:51 --> URI Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Router Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Output Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Security Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Input Class Initialized
DEBUG - 2014-08-22 22:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:52:51 --> Language Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Language Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Config Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Loader Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:52:52 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:52:52 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:52:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:52:52 --> Session Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:52:52 --> Session routines successfully run
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Controller Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:52:52 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:52:52 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:52:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:52:52 --> Model Class Initialized
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:52:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:52:52 --> Final output sent to browser
DEBUG - 2014-08-22 22:52:52 --> Total execution time: 0.8115
DEBUG - 2014-08-22 22:53:12 --> Config Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:53:12 --> URI Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Router Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Output Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Security Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Input Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:53:12 --> Language Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Language Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Config Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Loader Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:53:12 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:53:12 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:53:12 --> Session Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:53:12 --> Session routines successfully run
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Controller Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 22:53:12 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:53:12 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:53:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:53:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:53:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:53:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:53:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:53:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:53:13 --> Final output sent to browser
DEBUG - 2014-08-22 22:53:13 --> Total execution time: 0.8642
DEBUG - 2014-08-22 22:53:57 --> Config Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:53:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:53:57 --> URI Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Router Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Output Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Security Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Input Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:53:57 --> Language Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Language Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Config Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Loader Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:53:57 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:53:57 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:53:57 --> Session Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:53:57 --> Session routines successfully run
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Controller Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:53:57 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:53:57 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:53:57 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:53:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:53:57 --> Model Class Initialized
DEBUG - 2014-08-22 22:53:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:53:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:53:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:53:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:53:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:53:58 --> Final output sent to browser
DEBUG - 2014-08-22 22:53:58 --> Total execution time: 0.8436
DEBUG - 2014-08-22 22:55:53 --> Config Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:55:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:55:53 --> URI Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Router Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Output Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Security Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Input Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:55:53 --> Language Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Language Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Config Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Loader Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:55:53 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:55:53 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:55:53 --> Session Class Initialized
DEBUG - 2014-08-22 22:55:53 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:55:53 --> Session routines successfully run
DEBUG - 2014-08-22 22:55:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:55:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:55:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:55:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:54 --> Controller Class Initialized
DEBUG - 2014-08-22 22:55:54 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:55:54 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:55:54 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:55:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:55:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:55:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:55:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:55:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:55:54 --> Final output sent to browser
DEBUG - 2014-08-22 22:55:54 --> Total execution time: 0.8321
DEBUG - 2014-08-22 22:56:14 --> Config Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:56:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:56:14 --> URI Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Router Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Output Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Security Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Input Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:56:14 --> Language Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Language Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Config Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Loader Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:56:14 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:56:14 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:56:14 --> Session Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:56:14 --> Session routines successfully run
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Controller Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:56:14 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:56:14 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:14 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:56:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:56:15 --> Model Class Initialized
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:56:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:56:15 --> Final output sent to browser
DEBUG - 2014-08-22 22:56:15 --> Total execution time: 0.8574
DEBUG - 2014-08-22 22:57:19 --> Config Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:57:19 --> URI Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Router Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Output Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Security Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Input Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:57:19 --> Language Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Language Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Config Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Loader Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:57:19 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:57:19 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:57:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:57:19 --> Session Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:57:19 --> Session routines successfully run
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Controller Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Item MX_Controller Initialized
DEBUG - 2014-08-22 22:57:19 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:57:19 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:19 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:57:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:57:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:57:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:57:20 --> Final output sent to browser
DEBUG - 2014-08-22 22:57:20 --> Total execution time: 0.8309
DEBUG - 2014-08-22 22:57:24 --> Config Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:57:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:57:24 --> URI Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Router Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Output Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Security Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Input Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:57:24 --> Language Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Language Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Config Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Loader Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:57:24 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:57:24 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:57:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:57:24 --> Session Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:57:24 --> Session routines successfully run
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Controller Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:57:24 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:57:24 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:57:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:57:24 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:57:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:57:24 --> Final output sent to browser
DEBUG - 2014-08-22 22:57:24 --> Total execution time: 0.8627
DEBUG - 2014-08-22 22:57:27 --> Config Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:57:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:57:27 --> URI Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Router Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Output Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Security Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Input Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:57:27 --> Language Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Language Class Initialized
DEBUG - 2014-08-22 22:57:27 --> Config Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Loader Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:57:28 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:57:28 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:57:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:57:28 --> Session Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:57:28 --> Session routines successfully run
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Controller Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:57:28 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:57:28 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:57:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:57:28 --> Model Class Initialized
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:57:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:57:28 --> Final output sent to browser
DEBUG - 2014-08-22 22:57:28 --> Total execution time: 0.8510
DEBUG - 2014-08-22 22:58:10 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:58:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:58:10 --> URI Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Router Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Output Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Security Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Input Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:58:10 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Loader Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:58:10 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:58:10 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:58:10 --> Session Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:58:10 --> Session routines successfully run
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Controller Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:58:10 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:58:10 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 22:58:11 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:58:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:58:11 --> URI Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Router Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Output Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Security Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Input Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:58:11 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Loader Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:58:11 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:58:11 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:58:11 --> Session Class Initialized
DEBUG - 2014-08-22 22:58:11 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:58:12 --> Session routines successfully run
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Controller Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:58:12 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:58:12 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 22:58:12 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:58:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:58:12 --> URI Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Router Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Output Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Security Class Initialized
DEBUG - 2014-08-22 22:58:12 --> Input Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:58:13 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Loader Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:58:13 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:58:13 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:58:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:58:13 --> Session Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:58:13 --> Session routines successfully run
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Controller Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:58:13 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:58:13 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:58:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:58:13 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:58:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:58:13 --> Final output sent to browser
DEBUG - 2014-08-22 22:58:13 --> Total execution time: 1.0133
DEBUG - 2014-08-22 22:58:34 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:58:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:58:34 --> URI Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Router Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Output Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Security Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Input Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:58:34 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Loader Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:58:34 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:58:34 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:58:34 --> Session Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:58:34 --> Session routines successfully run
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Controller Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:58:34 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:58:34 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:34 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:58:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:58:35 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:58:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:58:35 --> Final output sent to browser
DEBUG - 2014-08-22 22:58:35 --> Total execution time: 0.9118
DEBUG - 2014-08-22 22:58:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:58:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:58:44 --> URI Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Router Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Output Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Security Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Input Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:58:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Loader Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:58:44 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:58:44 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:58:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:58:44 --> Session Class Initialized
DEBUG - 2014-08-22 22:58:44 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:58:45 --> Session routines successfully run
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> Controller Class Initialized
DEBUG - 2014-08-22 22:58:45 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:58:45 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:58:45 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:58:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:58:45 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:58:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:58:45 --> Final output sent to browser
DEBUG - 2014-08-22 22:58:45 --> Total execution time: 0.9033
DEBUG - 2014-08-22 22:58:53 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:58:53 --> URI Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Router Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Output Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Security Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Input Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:58:53 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Language Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Config Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Loader Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:58:53 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:58:53 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:58:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:58:53 --> Session Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:58:53 --> Session routines successfully run
DEBUG - 2014-08-22 22:58:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:58:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:58:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:58:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Controller Class Initialized
DEBUG - 2014-08-22 22:58:53 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:58:54 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:58:54 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:58:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:58:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:58:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:58:54 --> Model Class Initialized
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:58:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:58:54 --> Final output sent to browser
DEBUG - 2014-08-22 22:58:54 --> Total execution time: 0.9301
DEBUG - 2014-08-22 22:59:09 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:09 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:59:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:59:10 --> URI Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Router Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Output Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Security Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Input Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:59:10 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Loader Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:59:10 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:59:10 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:59:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:59:10 --> Session Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:59:10 --> Session routines successfully run
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Controller Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:59:10 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:59:10 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:59:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:59:10 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:59:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:59:10 --> Final output sent to browser
DEBUG - 2014-08-22 22:59:10 --> Total execution time: 0.9515
DEBUG - 2014-08-22 22:59:20 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:59:20 --> URI Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Router Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Output Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Security Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Input Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:59:20 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Loader Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:59:20 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:59:20 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:59:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:59:20 --> Session Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:59:20 --> Session routines successfully run
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Controller Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:59:20 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:59:20 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:59:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:59:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:59:21 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:59:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:59:21 --> Final output sent to browser
DEBUG - 2014-08-22 22:59:21 --> Total execution time: 0.9589
DEBUG - 2014-08-22 22:59:29 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:59:29 --> URI Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Router Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Output Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Security Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Input Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:59:29 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Loader Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:59:29 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:59:29 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:59:29 --> Session Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:59:29 --> Session routines successfully run
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Controller Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:59:29 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:59:29 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:59:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:59:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:59:30 --> Final output sent to browser
DEBUG - 2014-08-22 22:59:30 --> Total execution time: 0.9285
DEBUG - 2014-08-22 22:59:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Hooks Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Utf8 Class Initialized
DEBUG - 2014-08-22 22:59:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 22:59:38 --> URI Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Router Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Output Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Security Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Input Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 22:59:38 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Language Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Config Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Loader Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Helper loaded: url_helper
DEBUG - 2014-08-22 22:59:38 --> Helper loaded: common_helper
DEBUG - 2014-08-22 22:59:38 --> Database Driver Class Initialized
ERROR - 2014-08-22 22:59:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 22:59:38 --> Session Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Helper loaded: string_helper
DEBUG - 2014-08-22 22:59:38 --> Session routines successfully run
DEBUG - 2014-08-22 22:59:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 22:59:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 22:59:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 22:59:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Controller Class Initialized
DEBUG - 2014-08-22 22:59:38 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 22:59:38 --> Helper loaded: form_helper
DEBUG - 2014-08-22 22:59:38 --> Form Validation Class Initialized
DEBUG - 2014-08-22 22:59:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 22:59:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 22:59:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 22:59:39 --> Model Class Initialized
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 22:59:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 22:59:39 --> Final output sent to browser
DEBUG - 2014-08-22 22:59:39 --> Total execution time: 0.9433
DEBUG - 2014-08-22 23:00:03 --> Config Class Initialized
DEBUG - 2014-08-22 23:00:03 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:00:03 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:00:03 --> URI Class Initialized
DEBUG - 2014-08-22 23:00:03 --> Router Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Output Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Security Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Input Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:00:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Loader Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:00:04 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:00:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:00:04 --> Session Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:00:04 --> Session routines successfully run
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Controller Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:00:04 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:00:04 --> URI Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Router Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Output Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Security Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Input Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:00:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Loader Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:00:04 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:00:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:00:04 --> Session Class Initialized
DEBUG - 2014-08-22 23:00:04 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:00:05 --> Session routines successfully run
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Controller Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:00:05 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:00:05 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Config Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:00:05 --> URI Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Router Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Output Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Security Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Input Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:00:05 --> Language Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Language Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Config Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Loader Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:00:05 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:00:05 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:00:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:00:05 --> Session Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:00:05 --> Session routines successfully run
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Controller Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:00:05 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:00:05 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:00:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:23 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:23 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:23 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:23 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:23 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:23 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:23 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:23 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:06:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:06:23 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:06:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:06:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:06:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:06:24 --> Final output sent to browser
DEBUG - 2014-08-22 23:06:24 --> Total execution time: 0.9814
DEBUG - 2014-08-22 23:06:25 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:25 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:25 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:25 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:25 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:25 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:25 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:25 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:25 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:25 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:26 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:26 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:26 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:26 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:26 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:26 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:26 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:35 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:35 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:35 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:35 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:35 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:35 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:35 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:35 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:35 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:35 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:35 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:35 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:35 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:36 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:06:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:06:36 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:06:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:06:36 --> Final output sent to browser
DEBUG - 2014-08-22 23:06:36 --> Total execution time: 0.9806
DEBUG - 2014-08-22 23:06:37 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:37 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:37 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:37 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:37 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:37 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:37 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:37 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:37 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:37 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:37 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:37 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:37 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:37 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:38 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:38 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:38 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:38 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:38 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:38 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:38 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:41 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:41 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:41 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:42 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:42 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:42 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:42 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:42 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:42 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:06:42 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:42 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:06:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:06:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:06:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:06:42 --> Final output sent to browser
DEBUG - 2014-08-22 23:06:42 --> Total execution time: 1.0466
DEBUG - 2014-08-22 23:06:48 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:48 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:48 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:48 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:48 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:48 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:48 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Item MX_Controller Initialized
DEBUG - 2014-08-22 23:06:48 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:48 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:06:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:06:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:06:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:06:49 --> Final output sent to browser
DEBUG - 2014-08-22 23:06:49 --> Total execution time: 1.1225
DEBUG - 2014-08-22 23:06:51 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:51 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:06:51 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:06:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:06:51 --> URI Class Initialized
DEBUG - 2014-08-22 23:06:51 --> Router Class Initialized
DEBUG - 2014-08-22 23:06:51 --> Output Class Initialized
DEBUG - 2014-08-22 23:06:51 --> Security Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Input Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:06:52 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Language Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Config Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Loader Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:06:52 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:06:52 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:06:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:06:52 --> Session Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:06:52 --> Session routines successfully run
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Controller Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Item MX_Controller Initialized
DEBUG - 2014-08-22 23:06:52 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:06:52 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:06:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:06:52 --> Model Class Initialized
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:06:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:06:52 --> Final output sent to browser
DEBUG - 2014-08-22 23:06:52 --> Total execution time: 0.9344
DEBUG - 2014-08-22 23:07:02 --> Config Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:07:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:07:02 --> URI Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Router Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Output Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Security Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Input Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:07:02 --> Language Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Language Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Config Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Loader Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:07:02 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:07:02 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:07:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:07:02 --> Session Class Initialized
DEBUG - 2014-08-22 23:07:02 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:07:02 --> Session routines successfully run
DEBUG - 2014-08-22 23:07:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:07:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:07:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:07:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Controller Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Item MX_Controller Initialized
DEBUG - 2014-08-22 23:07:03 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:07:03 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:07:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:07:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:07:07 --> Config Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:07:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:07:07 --> URI Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Router Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Output Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Security Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Input Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:07:07 --> Language Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Language Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Config Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Loader Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:07:07 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:07:07 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:07:07 --> Session Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:07:07 --> Session routines successfully run
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Controller Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Item MX_Controller Initialized
DEBUG - 2014-08-22 23:07:07 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:07:07 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:07:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:07:07 --> Model Class Initialized
DEBUG - 2014-08-22 23:07:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:07:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:07:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:07:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:07:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:07:08 --> Final output sent to browser
DEBUG - 2014-08-22 23:07:08 --> Total execution time: 1.0287
DEBUG - 2014-08-22 23:09:01 --> Config Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:09:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:09:01 --> URI Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Router Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Output Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Security Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Input Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:09:01 --> Language Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Language Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Config Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Loader Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:09:01 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:09:01 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:09:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:09:01 --> Session Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:09:01 --> Session routines successfully run
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Controller Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:09:01 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:09:01 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:09:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:09:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:09:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:09:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:09:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:09:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:09:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:09:02 --> Final output sent to browser
DEBUG - 2014-08-22 23:09:02 --> Total execution time: 1.0480
DEBUG - 2014-08-22 23:09:03 --> Config Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:09:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:09:03 --> URI Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Router Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Output Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Security Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Input Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:09:03 --> Language Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Language Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Config Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Loader Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:09:03 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:09:03 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:09:03 --> Session Class Initialized
DEBUG - 2014-08-22 23:09:03 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:09:03 --> Session routines successfully run
DEBUG - 2014-08-22 23:09:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:09:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:09:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:09:03 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Controller Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:09:04 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:09:04 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:09:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:09:04 --> URI Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Router Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Output Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Security Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Input Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:09:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Loader Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:09:04 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:09:04 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:09:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:09:04 --> Session Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:09:04 --> Session routines successfully run
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Controller Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:09:04 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:09:04 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:09:04 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Config Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:10:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:10:46 --> URI Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Router Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Output Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Security Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Input Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:10:46 --> Language Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Language Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Config Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Loader Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:10:46 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:10:46 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:10:46 --> Session Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:10:46 --> Session routines successfully run
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Controller Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:10:46 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:10:46 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:10:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:10:46 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:10:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:10:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:10:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:10:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:10:47 --> Final output sent to browser
DEBUG - 2014-08-22 23:10:47 --> Total execution time: 1.0505
DEBUG - 2014-08-22 23:10:48 --> Config Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:10:48 --> URI Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Router Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Output Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Security Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Input Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:10:48 --> Language Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Language Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Config Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Loader Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:10:48 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:10:48 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:10:48 --> Session Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:10:48 --> Session routines successfully run
DEBUG - 2014-08-22 23:10:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:10:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:10:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:10:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Controller Class Initialized
DEBUG - 2014-08-22 23:10:48 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:10:48 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:10:49 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Config Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:10:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:10:49 --> URI Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Router Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Output Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Security Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Input Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:10:49 --> Language Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Language Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Config Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Loader Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:10:49 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:10:49 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:10:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:10:49 --> Session Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:10:49 --> Session routines successfully run
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Controller Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Batch MX_Controller Initialized
DEBUG - 2014-08-22 23:10:49 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:10:49 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:10:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:15:04 --> URI Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Router Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Output Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Security Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Input Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:15:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Language Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Config Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Loader Class Initialized
DEBUG - 2014-08-22 23:15:04 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:15:05 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:15:05 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:15:05 --> Session Class Initialized
DEBUG - 2014-08-22 23:15:05 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:15:05 --> Session routines successfully run
DEBUG - 2014-08-22 23:15:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:15:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:15:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:15:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:05 --> Controller Class Initialized
DEBUG - 2014-08-22 23:15:05 --> Client MX_Controller Initialized
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:15:05 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:15:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:15:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:15:05 --> Final output sent to browser
DEBUG - 2014-08-22 23:15:05 --> Total execution time: 0.8246
DEBUG - 2014-08-22 23:15:08 --> Config Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:15:08 --> URI Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Router Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Output Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Security Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Input Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:15:08 --> Language Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Language Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Config Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Loader Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:15:08 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:15:08 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:15:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:15:08 --> Session Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:15:08 --> Session routines successfully run
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Controller Class Initialized
DEBUG - 2014-08-22 23:15:08 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:15:08 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:15:08 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:15:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:15:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:15:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:15:09 --> Final output sent to browser
DEBUG - 2014-08-22 23:15:09 --> Total execution time: 1.1255
DEBUG - 2014-08-22 23:15:13 --> Config Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:15:13 --> URI Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Router Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Output Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Security Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Input Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:15:13 --> Language Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Language Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Config Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Loader Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:15:13 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:15:13 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:15:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:15:13 --> Session Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:15:13 --> Session routines successfully run
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Controller Class Initialized
DEBUG - 2014-08-22 23:15:13 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:15:13 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:15:13 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:15:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:15:13 --> Model Class Initialized
DEBUG - 2014-08-22 23:15:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:15:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:15:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:15:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:15:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:15:14 --> Final output sent to browser
DEBUG - 2014-08-22 23:15:14 --> Total execution time: 1.0216
DEBUG - 2014-08-22 23:16:42 --> Config Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:16:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:16:42 --> URI Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Router Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Output Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Security Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Input Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:16:42 --> Language Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Language Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Config Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Loader Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:16:42 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:16:42 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:16:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:16:42 --> Session Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:16:42 --> Session routines successfully run
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Controller Class Initialized
DEBUG - 2014-08-22 23:16:42 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:16:42 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:16:42 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:16:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:16:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:16:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:16:43 --> Final output sent to browser
DEBUG - 2014-08-22 23:16:43 --> Total execution time: 1.0342
DEBUG - 2014-08-22 23:17:17 --> Config Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:17:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:17:17 --> URI Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Router Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Output Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Security Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Input Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:17:17 --> Language Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Language Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Config Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Loader Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:17:17 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:17:17 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:17:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:17:17 --> Session Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:17:17 --> Session routines successfully run
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Controller Class Initialized
DEBUG - 2014-08-22 23:17:17 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:17:17 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:17:17 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:17:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:17:18 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:17:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:17:18 --> Final output sent to browser
DEBUG - 2014-08-22 23:17:18 --> Total execution time: 1.0339
DEBUG - 2014-08-22 23:17:27 --> Config Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:17:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:17:27 --> URI Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Router Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Output Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Security Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Input Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:17:27 --> Language Class Initialized
DEBUG - 2014-08-22 23:17:27 --> Language Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Config Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Loader Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:17:28 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:17:28 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:17:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:17:28 --> Session Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:17:28 --> Session routines successfully run
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Controller Class Initialized
DEBUG - 2014-08-22 23:17:28 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:17:28 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:17:28 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:17:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:17:29 --> Config Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:17:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:17:29 --> URI Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Router Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Output Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Security Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Input Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:17:29 --> Language Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Language Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Config Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Loader Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:17:29 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:17:29 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:17:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:17:29 --> Session Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:17:29 --> Session routines successfully run
DEBUG - 2014-08-22 23:17:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:17:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:17:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:17:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:29 --> Controller Class Initialized
DEBUG - 2014-08-22 23:17:29 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:17:29 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:17:30 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:17:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:17:30 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:30 --> Model Class Initialized
DEBUG - 2014-08-22 23:17:30 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:17:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:18:08 --> Config Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:18:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:18:08 --> URI Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Router Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Output Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Security Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Input Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:18:08 --> Language Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Language Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Config Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Loader Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:18:08 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:18:08 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:18:08 --> Session Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:18:08 --> Session routines successfully run
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Controller Class Initialized
DEBUG - 2014-08-22 23:18:08 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:18:08 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:18:08 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:08 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:18:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:18:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:18:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:18:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:18:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:18:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:18:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:18:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:18:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:18:09 --> Final output sent to browser
DEBUG - 2014-08-22 23:18:09 --> Total execution time: 1.1490
DEBUG - 2014-08-22 23:18:16 --> Config Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:18:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:18:16 --> URI Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Router Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Output Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Security Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Input Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:18:16 --> Language Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Language Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Config Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Loader Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:18:16 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:18:16 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:18:16 --> Session Class Initialized
DEBUG - 2014-08-22 23:18:16 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:18:16 --> Session routines successfully run
DEBUG - 2014-08-22 23:18:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:18:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:18:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:18:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:17 --> Controller Class Initialized
DEBUG - 2014-08-22 23:18:17 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:18:17 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:18:17 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:18:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:18:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:18:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:18:17 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:18:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:18:17 --> Final output sent to browser
DEBUG - 2014-08-22 23:18:17 --> Total execution time: 1.0820
DEBUG - 2014-08-22 23:18:30 --> Config Class Initialized
DEBUG - 2014-08-22 23:18:30 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:18:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:18:31 --> URI Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Router Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Output Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Security Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Input Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:18:31 --> Language Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Language Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Config Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Loader Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:18:31 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:18:31 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:18:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:18:31 --> Session Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:18:31 --> Session routines successfully run
DEBUG - 2014-08-22 23:18:31 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:18:31 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:18:31 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:18:31 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:31 --> Controller Class Initialized
DEBUG - 2014-08-22 23:18:31 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:18:31 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:18:31 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:18:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:18:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:18:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:18:32 --> Final output sent to browser
DEBUG - 2014-08-22 23:18:32 --> Total execution time: 1.4720
DEBUG - 2014-08-22 23:20:09 --> Config Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:20:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:20:09 --> URI Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Router Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Output Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Security Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Input Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:20:09 --> Language Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Language Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Config Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Loader Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:20:09 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:20:09 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:20:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:20:09 --> Session Class Initialized
DEBUG - 2014-08-22 23:20:09 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:20:09 --> Session routines successfully run
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> Controller Class Initialized
DEBUG - 2014-08-22 23:20:10 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:20:10 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:20:10 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:20:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:20:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:20:10 --> Model Class Initialized
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:20:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:20:10 --> Final output sent to browser
DEBUG - 2014-08-22 23:20:10 --> Total execution time: 1.1006
DEBUG - 2014-08-22 23:21:08 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:08 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:08 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:08 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:08 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:08 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:08 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:08 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:08 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:09 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:09 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:09 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:09 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:21:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:21:09 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:21:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:21:09 --> Final output sent to browser
DEBUG - 2014-08-22 23:21:09 --> Total execution time: 1.4981
DEBUG - 2014-08-22 23:21:21 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:21 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:21 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:22 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:22 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:22 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:22 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:22 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:22 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:22 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:21:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:26 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:26 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:26 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:27 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:27 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:27 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:27 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:27 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:27 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:21:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:21:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:21:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:21:27 --> Final output sent to browser
DEBUG - 2014-08-22 23:21:27 --> Total execution time: 1.2245
DEBUG - 2014-08-22 23:21:32 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:32 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:32 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:32 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:32 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:32 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:32 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:32 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:32 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:32 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:21:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:21:33 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:21:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:21:33 --> Final output sent to browser
DEBUG - 2014-08-22 23:21:33 --> Total execution time: 1.1158
DEBUG - 2014-08-22 23:21:41 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:41 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:41 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:41 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:41 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:41 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:41 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:42 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:42 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:42 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:42 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:21:42 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:42 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:43 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:43 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:43 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:43 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:43 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:43 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:43 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:43 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:43 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:21:44 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:21:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:21:44 --> URI Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Router Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Output Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Security Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Input Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:21:44 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Language Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Config Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Loader Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:21:44 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:21:44 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:21:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:21:44 --> Session Class Initialized
DEBUG - 2014-08-22 23:21:44 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:21:44 --> Session routines successfully run
DEBUG - 2014-08-22 23:21:44 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:21:44 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:21:44 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:21:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:45 --> Controller Class Initialized
DEBUG - 2014-08-22 23:21:45 --> User MX_Controller Initialized
DEBUG - 2014-08-22 23:21:45 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:21:45 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:21:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:21:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:21:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:21:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:21:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:21:45 --> Final output sent to browser
DEBUG - 2014-08-22 23:21:45 --> Total execution time: 1.3733
DEBUG - 2014-08-22 23:22:44 --> Config Class Initialized
DEBUG - 2014-08-22 23:22:44 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:22:44 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:22:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:22:45 --> URI Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Router Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Output Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Security Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Input Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:22:45 --> Language Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Language Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Config Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Loader Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:22:45 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:22:45 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:22:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:22:45 --> Session Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:22:45 --> Session routines successfully run
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Controller Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Setting MX_Controller Initialized
DEBUG - 2014-08-22 23:22:45 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:22:45 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:22:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:22:45 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:22:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:22:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:22:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:22:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:22:46 --> Final output sent to browser
DEBUG - 2014-08-22 23:22:46 --> Total execution time: 1.1448
DEBUG - 2014-08-22 23:22:49 --> Config Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:22:50 --> URI Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Router Class Initialized
DEBUG - 2014-08-22 23:22:50 --> No URI present. Default controller set.
DEBUG - 2014-08-22 23:22:50 --> Output Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Security Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Input Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:22:50 --> Language Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Language Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Config Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Loader Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:22:50 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:22:50 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:22:50 --> Session Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:22:50 --> Session routines successfully run
DEBUG - 2014-08-22 23:22:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:22:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:22:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:22:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Controller Class Initialized
DEBUG - 2014-08-22 23:22:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:22:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:22:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:22:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:22:50 --> Final output sent to browser
DEBUG - 2014-08-22 23:22:50 --> Total execution time: 0.9604
DEBUG - 2014-08-22 23:29:49 --> Config Class Initialized
DEBUG - 2014-08-22 23:29:49 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:29:50 --> URI Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Router Class Initialized
DEBUG - 2014-08-22 23:29:50 --> No URI present. Default controller set.
DEBUG - 2014-08-22 23:29:50 --> Output Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Security Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Input Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:29:50 --> Language Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Language Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Config Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Loader Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:29:50 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:29:50 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:29:50 --> Session Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:29:50 --> Session routines successfully run
DEBUG - 2014-08-22 23:29:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:29:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:29:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:29:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Controller Class Initialized
DEBUG - 2014-08-22 23:29:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:29:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:29:50 --> Model Class Initialized
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:29:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:29:50 --> Final output sent to browser
DEBUG - 2014-08-22 23:29:50 --> Total execution time: 0.9913
DEBUG - 2014-08-22 23:30:00 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:30:01 --> URI Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Router Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Output Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Security Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Input Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:30:01 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Loader Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:30:01 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:30:01 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:30:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:30:01 --> Session Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:30:01 --> Session routines successfully run
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Controller Class Initialized
DEBUG - 2014-08-22 23:30:01 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 23:30:01 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:30:01 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:30:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:30:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:30:01 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:30:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:30:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:30:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:30:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:30:02 --> Final output sent to browser
DEBUG - 2014-08-22 23:30:02 --> Total execution time: 1.1390
DEBUG - 2014-08-22 23:30:05 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:30:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:30:05 --> URI Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Router Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Output Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Security Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Input Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:30:05 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Loader Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:30:05 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:30:05 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:30:05 --> Session Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:30:05 --> Session routines successfully run
DEBUG - 2014-08-22 23:30:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:30:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:30:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:30:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:05 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:06 --> Controller Class Initialized
DEBUG - 2014-08-22 23:30:06 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 23:30:06 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:30:06 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 23:30:06 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 23:30:06 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:30:06 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:06 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:30:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:30:06 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:30:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:30:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:30:06 --> Final output sent to browser
DEBUG - 2014-08-22 23:30:06 --> Total execution time: 1.3853
DEBUG - 2014-08-22 23:30:25 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:25 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:30:25 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:30:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:30:26 --> URI Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Router Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Output Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Security Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Input Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:30:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Loader Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:30:26 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:30:26 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:30:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:30:26 --> Session Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:30:26 --> Session routines successfully run
DEBUG - 2014-08-22 23:30:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:30:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:30:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:30:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Controller Class Initialized
DEBUG - 2014-08-22 23:30:26 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 23:30:26 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:30:26 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:30:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 23:30:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 23:30:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:30:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:30:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:30:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:30:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:30:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:30:27 --> Final output sent to browser
DEBUG - 2014-08-22 23:30:27 --> Total execution time: 1.5698
DEBUG - 2014-08-22 23:30:37 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:30:37 --> URI Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Router Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Output Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Security Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Input Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:30:37 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Language Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Config Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Loader Class Initialized
DEBUG - 2014-08-22 23:30:37 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:30:37 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:30:38 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:30:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:30:38 --> Session Class Initialized
DEBUG - 2014-08-22 23:30:38 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:30:38 --> Session routines successfully run
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> Controller Class Initialized
DEBUG - 2014-08-22 23:30:38 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 23:30:38 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:30:38 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:30:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:30:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:30:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:30:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:30:39 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:30:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:30:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:30:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:30:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:30:39 --> Final output sent to browser
DEBUG - 2014-08-22 23:30:39 --> Total execution time: 1.7543
DEBUG - 2014-08-22 23:31:11 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:11 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:11 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:12 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:12 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:12 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:12 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:12 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 23:31:12 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:12 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:31:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:31:12 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:31:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:31:12 --> Final output sent to browser
DEBUG - 2014-08-22 23:31:12 --> Total execution time: 1.2159
DEBUG - 2014-08-22 23:31:15 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:15 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:15 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:16 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:16 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:16 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:16 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Order MX_Controller Initialized
DEBUG - 2014-08-22 23:31:16 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:16 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:31:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:31:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:31:16 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:31:17 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:31:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:31:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:31:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:31:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:31:17 --> Final output sent to browser
DEBUG - 2014-08-22 23:31:17 --> Total execution time: 1.4060
DEBUG - 2014-08-22 23:31:28 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:28 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:28 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:28 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:28 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:28 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:28 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:29 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:29 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:29 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:29 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:31:29 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:29 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/payment/views/index.php
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:31:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:31:29 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:31:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:31:29 --> Final output sent to browser
DEBUG - 2014-08-22 23:31:29 --> Total execution time: 1.0705
DEBUG - 2014-08-22 23:31:31 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:31 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:31 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:31 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:31 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:31 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:32 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:32 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:32 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:32 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:31:32 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:32 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:31:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:31:32 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:31:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:31:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:31:32 --> Final output sent to browser
DEBUG - 2014-08-22 23:31:33 --> Total execution time: 1.3378
DEBUG - 2014-08-22 23:31:36 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:36 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:36 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:36 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:37 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:37 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:37 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:37 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:37 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:37 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:31:37 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:37 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:31:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:31:37 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:31:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:31:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:31:37 --> Final output sent to browser
DEBUG - 2014-08-22 23:31:37 --> Total execution time: 1.2580
DEBUG - 2014-08-22 23:31:47 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:47 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:47 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:47 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:47 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:47 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:47 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:47 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:47 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:47 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:47 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:47 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:31:48 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:48 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:31:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:31:48 --> URI Class Initialized
DEBUG - 2014-08-22 23:31:48 --> Router Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Output Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Security Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Input Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:31:49 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Language Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Config Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Loader Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:31:49 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:31:49 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:31:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:31:49 --> Session Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:31:49 --> Session routines successfully run
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Controller Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:31:49 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:31:49 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> Model Class Initialized
DEBUG - 2014-08-22 23:31:49 --> DB Transaction Failure
ERROR - 2014-08-22 23:31:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`vmv2`.`payment`, CONSTRAINT `FK_payment_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`))
DEBUG - 2014-08-22 23:31:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-08-22 23:32:55 --> Config Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:32:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:32:55 --> URI Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Router Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Output Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Security Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Input Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:32:55 --> Language Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Language Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Config Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Loader Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:32:55 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:32:55 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:32:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:32:55 --> Session Class Initialized
DEBUG - 2014-08-22 23:32:55 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:32:55 --> Session routines successfully run
DEBUG - 2014-08-22 23:32:55 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> Controller Class Initialized
DEBUG - 2014-08-22 23:32:56 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:32:56 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:32:56 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:32:56 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:32:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:32:56 --> Model Class Initialized
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:32:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:32:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:32:56 --> Final output sent to browser
DEBUG - 2014-08-22 23:32:56 --> Total execution time: 1.2474
DEBUG - 2014-08-22 23:33:01 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:33:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:33:01 --> URI Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Router Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Output Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Security Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Input Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:33:01 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Loader Class Initialized
DEBUG - 2014-08-22 23:33:01 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:33:01 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:33:02 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:33:02 --> Session Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:33:02 --> Session routines successfully run
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Controller Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:33:02 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:33:02 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:33:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:33:20 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:20 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:33:20 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:33:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:33:20 --> URI Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Router Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Output Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Security Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Input Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:33:21 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Loader Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:33:21 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:33:21 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:33:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:33:21 --> Session Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:33:21 --> Session routines successfully run
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Controller Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:33:21 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:33:21 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:33:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:33:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:33:21 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:33:22 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-22 23:33:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-22 23:33:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:33:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:33:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:33:22 --> Final output sent to browser
DEBUG - 2014-08-22 23:33:22 --> Total execution time: 1.2869
DEBUG - 2014-08-22 23:33:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:33:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:33:26 --> URI Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Router Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Output Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Security Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Input Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:33:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Loader Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:33:26 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:33:26 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:33:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:33:26 --> Session Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:33:26 --> Session routines successfully run
DEBUG - 2014-08-22 23:33:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:33:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:33:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:33:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Controller Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Payment MX_Controller Initialized
DEBUG - 2014-08-22 23:33:26 --> Helper loaded: form_helper
DEBUG - 2014-08-22 23:33:26 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:33:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-22 23:33:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:27 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:27 --> Form Validation Class Initialized
DEBUG - 2014-08-22 23:33:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-22 23:33:38 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Hooks Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Utf8 Class Initialized
DEBUG - 2014-08-22 23:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-22 23:33:38 --> URI Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Router Class Initialized
DEBUG - 2014-08-22 23:33:38 --> No URI present. Default controller set.
DEBUG - 2014-08-22 23:33:38 --> Output Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Security Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Input Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-22 23:33:38 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Language Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Config Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Loader Class Initialized
DEBUG - 2014-08-22 23:33:38 --> Helper loaded: url_helper
DEBUG - 2014-08-22 23:33:38 --> Helper loaded: common_helper
DEBUG - 2014-08-22 23:33:38 --> Database Driver Class Initialized
ERROR - 2014-08-22 23:33:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-22 23:33:39 --> Session Class Initialized
DEBUG - 2014-08-22 23:33:39 --> Helper loaded: string_helper
DEBUG - 2014-08-22 23:33:39 --> Session routines successfully run
DEBUG - 2014-08-22 23:33:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-22 23:33:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-22 23:33:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-22 23:33:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:39 --> Controller Class Initialized
DEBUG - 2014-08-22 23:33:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-22 23:33:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-22 23:33:39 --> Model Class Initialized
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-22 23:33:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-22 23:33:39 --> Final output sent to browser
DEBUG - 2014-08-22 23:33:39 --> Total execution time: 1.1903
