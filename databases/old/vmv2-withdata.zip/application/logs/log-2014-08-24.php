<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-24 16:25:48 --> Config Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 16:25:48 --> URI Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Router Class Initialized
DEBUG - 2014-08-24 16:25:48 --> No URI present. Default controller set.
DEBUG - 2014-08-24 16:25:48 --> Output Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Security Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Input Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 16:25:48 --> Language Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Language Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Config Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Loader Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 16:25:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 16:25:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 16:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 16:25:48 --> Session Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 16:25:48 --> A session cookie was not found.
DEBUG - 2014-08-24 16:25:48 --> Session routines successfully run
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Controller Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 16:25:48 --> Config Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 16:25:48 --> URI Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Router Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Output Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Security Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Input Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 16:25:48 --> Language Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Language Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Config Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Loader Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 16:25:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 16:25:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 16:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 16:25:48 --> Session Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 16:25:48 --> Session routines successfully run
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Controller Class Initialized
DEBUG - 2014-08-24 16:25:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 16:25:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 16:25:48 --> Model Class Initialized
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 16:25:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 16:25:48 --> Final output sent to browser
DEBUG - 2014-08-24 16:25:48 --> Total execution time: 0.1043
DEBUG - 2014-08-24 16:26:02 --> Config Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Hooks Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Utf8 Class Initialized
DEBUG - 2014-08-24 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 16:26:02 --> URI Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Router Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Output Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Security Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Input Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 16:26:02 --> Language Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Language Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Config Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Loader Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Helper loaded: url_helper
DEBUG - 2014-08-24 16:26:02 --> Helper loaded: common_helper
DEBUG - 2014-08-24 16:26:02 --> Database Driver Class Initialized
ERROR - 2014-08-24 16:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 16:26:02 --> Session Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Helper loaded: string_helper
DEBUG - 2014-08-24 16:26:02 --> Session routines successfully run
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Controller Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 16:26:02 --> Config Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Hooks Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Utf8 Class Initialized
DEBUG - 2014-08-24 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 16:26:02 --> URI Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Router Class Initialized
DEBUG - 2014-08-24 16:26:02 --> No URI present. Default controller set.
DEBUG - 2014-08-24 16:26:02 --> Output Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Security Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Input Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 16:26:02 --> Language Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Language Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Config Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Loader Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Helper loaded: url_helper
DEBUG - 2014-08-24 16:26:02 --> Helper loaded: common_helper
DEBUG - 2014-08-24 16:26:02 --> Database Driver Class Initialized
ERROR - 2014-08-24 16:26:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 16:26:02 --> Session Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Helper loaded: string_helper
DEBUG - 2014-08-24 16:26:02 --> Session routines successfully run
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Controller Class Initialized
DEBUG - 2014-08-24 16:26:02 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 16:26:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 16:26:02 --> Model Class Initialized
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 16:26:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 16:26:02 --> Final output sent to browser
DEBUG - 2014-08-24 16:26:02 --> Total execution time: 0.1946
DEBUG - 2014-08-24 16:36:25 --> Config Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Hooks Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Utf8 Class Initialized
DEBUG - 2014-08-24 16:36:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 16:36:25 --> URI Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Router Class Initialized
DEBUG - 2014-08-24 16:36:25 --> No URI present. Default controller set.
DEBUG - 2014-08-24 16:36:25 --> Output Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Security Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Input Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 16:36:25 --> Language Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Language Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Config Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Loader Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Helper loaded: url_helper
DEBUG - 2014-08-24 16:36:25 --> Helper loaded: common_helper
DEBUG - 2014-08-24 16:36:25 --> Database Driver Class Initialized
ERROR - 2014-08-24 16:36:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 16:36:25 --> Session Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Helper loaded: string_helper
DEBUG - 2014-08-24 16:36:25 --> Session routines successfully run
DEBUG - 2014-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Controller Class Initialized
DEBUG - 2014-08-24 16:36:25 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 16:36:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 16:36:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 16:36:25 --> Final output sent to browser
DEBUG - 2014-08-24 16:36:25 --> Total execution time: 0.1125
DEBUG - 2014-08-24 17:08:19 --> Config Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:08:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:08:19 --> URI Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Router Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Output Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Security Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Input Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:08:19 --> Language Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Language Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Config Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Loader Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:08:19 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:08:19 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:08:19 --> Session Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:08:19 --> Session routines successfully run
DEBUG - 2014-08-24 17:08:19 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:08:19 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:08:19 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:08:19 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Controller Class Initialized
DEBUG - 2014-08-24 17:08:19 --> Order MX_Controller Initialized
DEBUG - 2014-08-24 17:08:19 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:08:19 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-24 17:08:20 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-24 17:08:20 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:08:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:08:20 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:08:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:08:20 --> Final output sent to browser
DEBUG - 2014-08-24 17:08:20 --> Total execution time: 0.1846
DEBUG - 2014-08-24 17:08:22 --> Config Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:08:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:08:22 --> URI Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Router Class Initialized
DEBUG - 2014-08-24 17:08:22 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:08:22 --> Output Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Security Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Input Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:08:22 --> Language Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Language Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Config Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Loader Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:08:22 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:08:22 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:08:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:08:22 --> Session Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:08:22 --> Session routines successfully run
DEBUG - 2014-08-24 17:08:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:08:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:08:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:08:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Controller Class Initialized
DEBUG - 2014-08-24 17:08:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:08:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:08:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:08:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:08:22 --> Final output sent to browser
DEBUG - 2014-08-24 17:08:22 --> Total execution time: 0.0980
DEBUG - 2014-08-24 17:09:56 --> Config Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:09:56 --> URI Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Router Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Output Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Security Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Input Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:09:56 --> Language Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Language Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Config Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Loader Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:09:56 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:09:56 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:09:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:09:56 --> Session Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:09:56 --> Session routines successfully run
DEBUG - 2014-08-24 17:09:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:09:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:09:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:09:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Controller Class Initialized
DEBUG - 2014-08-24 17:09:56 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:09:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:09:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:09:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:09:56 --> Final output sent to browser
DEBUG - 2014-08-24 17:09:56 --> Total execution time: 0.1009
DEBUG - 2014-08-24 17:09:59 --> Config Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:09:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:09:59 --> URI Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Router Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Output Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Security Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Input Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:09:59 --> Language Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Language Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Config Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Loader Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:09:59 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:09:59 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:09:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:09:59 --> Session Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:09:59 --> Session routines successfully run
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Controller Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:09:59 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:09:59 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:09:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:09:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:09:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:09:59 --> Final output sent to browser
DEBUG - 2014-08-24 17:09:59 --> Total execution time: 0.3412
DEBUG - 2014-08-24 17:10:06 --> Config Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:10:06 --> URI Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Router Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Output Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Security Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Input Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:10:06 --> Language Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Language Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Config Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Loader Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:10:06 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:10:06 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:10:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:10:06 --> Session Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:10:06 --> Session routines successfully run
DEBUG - 2014-08-24 17:10:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:10:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:10:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:10:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Controller Class Initialized
DEBUG - 2014-08-24 17:10:06 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/report/views/generate_report_form.php
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:10:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:10:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:10:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:10:06 --> Final output sent to browser
DEBUG - 2014-08-24 17:10:06 --> Total execution time: 0.1065
DEBUG - 2014-08-24 17:10:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:10:09 --> URI Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Router Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Output Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Security Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Input Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:10:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Loader Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:10:09 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:10:09 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:10:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:10:09 --> Session Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:10:09 --> Session routines successfully run
DEBUG - 2014-08-24 17:10:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:10:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:10:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:10:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Controller Class Initialized
DEBUG - 2014-08-24 17:10:09 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/report/views/view_report.php
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:10:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:10:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:10:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:10:09 --> Final output sent to browser
DEBUG - 2014-08-24 17:10:09 --> Total execution time: 0.1157
DEBUG - 2014-08-24 17:10:12 --> Config Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:10:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:10:12 --> URI Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Router Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Output Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Security Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Input Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:10:12 --> Language Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Language Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Config Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Loader Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:10:12 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:10:12 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:10:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:10:12 --> Session Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:10:12 --> Session routines successfully run
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Controller Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:10:12 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:10:12 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:10:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:10:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:10:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:10:12 --> Final output sent to browser
DEBUG - 2014-08-24 17:10:12 --> Total execution time: 0.1591
DEBUG - 2014-08-24 17:15:43 --> Config Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:15:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:15:43 --> URI Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Router Class Initialized
DEBUG - 2014-08-24 17:15:43 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:15:43 --> Output Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Security Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Input Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:15:43 --> Language Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Language Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Config Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Loader Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:15:43 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:15:43 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:15:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:15:43 --> Session Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:15:43 --> Session routines successfully run
DEBUG - 2014-08-24 17:15:43 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:15:43 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:15:43 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:15:43 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Controller Class Initialized
DEBUG - 2014-08-24 17:15:43 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:15:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:15:43 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:15:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:15:43 --> Final output sent to browser
DEBUG - 2014-08-24 17:15:43 --> Total execution time: 0.1065
DEBUG - 2014-08-24 17:15:48 --> Config Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:15:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:15:48 --> URI Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Router Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Output Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Security Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Input Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:15:48 --> Language Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Language Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Config Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Loader Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:15:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:15:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:15:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:15:48 --> Session Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:15:48 --> Session routines successfully run
DEBUG - 2014-08-24 17:15:48 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:15:48 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:15:48 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:15:48 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Controller Class Initialized
DEBUG - 2014-08-24 17:15:48 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:15:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:15:48 --> Model Class Initialized
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:15:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:15:48 --> Final output sent to browser
DEBUG - 2014-08-24 17:15:48 --> Total execution time: 0.0995
DEBUG - 2014-08-24 17:21:47 --> Config Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:21:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:21:47 --> URI Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Router Class Initialized
DEBUG - 2014-08-24 17:21:47 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:21:47 --> Output Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Security Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Input Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:21:47 --> Language Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Language Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Config Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Loader Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:21:47 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:21:47 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:21:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:21:47 --> Session Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:21:47 --> Session routines successfully run
DEBUG - 2014-08-24 17:21:47 --> Model Class Initialized
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:21:47 --> Model Class Initialized
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:21:47 --> Model Class Initialized
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:21:47 --> Model Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Model Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Controller Class Initialized
DEBUG - 2014-08-24 17:21:47 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:21:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:21:47 --> Model Class Initialized
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:21:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:21:47 --> Final output sent to browser
DEBUG - 2014-08-24 17:21:47 --> Total execution time: 0.0867
DEBUG - 2014-08-24 17:24:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:24:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:24:44 --> URI Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Router Class Initialized
DEBUG - 2014-08-24 17:24:44 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:24:44 --> Output Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Security Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Input Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:24:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Loader Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:24:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:24:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:24:44 --> Session Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:24:44 --> Session routines successfully run
DEBUG - 2014-08-24 17:24:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:24:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:24:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:24:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Controller Class Initialized
DEBUG - 2014-08-24 17:24:44 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:24:44 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:24:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:24:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:24:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:24:44 --> Final output sent to browser
DEBUG - 2014-08-24 17:24:44 --> Total execution time: 0.1248
DEBUG - 2014-08-24 17:25:18 --> Config Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:25:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:25:18 --> URI Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Router Class Initialized
DEBUG - 2014-08-24 17:25:18 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:25:18 --> Output Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Security Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Input Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:25:18 --> Language Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Language Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Config Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Loader Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:25:18 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:25:18 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:25:18 --> Session Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:25:18 --> Session routines successfully run
DEBUG - 2014-08-24 17:25:18 --> Model Class Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:25:18 --> Model Class Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:25:18 --> Model Class Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:25:18 --> Model Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Model Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Controller Class Initialized
DEBUG - 2014-08-24 17:25:18 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:25:18 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:25:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:25:18 --> Model Class Initialized
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:25:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:25:18 --> Final output sent to browser
DEBUG - 2014-08-24 17:25:18 --> Total execution time: 0.0992
DEBUG - 2014-08-24 17:26:27 --> Config Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:26:27 --> URI Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Router Class Initialized
DEBUG - 2014-08-24 17:26:27 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:26:27 --> Output Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Security Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Input Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:26:27 --> Language Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Language Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Config Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Loader Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:26:27 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:26:27 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:26:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:26:27 --> Session Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:26:27 --> Session routines successfully run
DEBUG - 2014-08-24 17:26:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:26:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:26:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:26:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Controller Class Initialized
DEBUG - 2014-08-24 17:26:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:26:27 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:26:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:26:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:26:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:26:27 --> Final output sent to browser
DEBUG - 2014-08-24 17:26:27 --> Total execution time: 0.1062
DEBUG - 2014-08-24 17:26:36 --> Config Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:26:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:26:36 --> URI Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Router Class Initialized
DEBUG - 2014-08-24 17:26:36 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:26:36 --> Output Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Security Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Input Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:26:36 --> Language Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Language Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Config Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Loader Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:26:36 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:26:36 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:26:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:26:36 --> Session Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:26:36 --> Session routines successfully run
DEBUG - 2014-08-24 17:26:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:26:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:26:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:26:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Controller Class Initialized
DEBUG - 2014-08-24 17:26:36 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:26:36 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:26:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:26:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:26:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:26:36 --> Final output sent to browser
DEBUG - 2014-08-24 17:26:36 --> Total execution time: 0.1143
DEBUG - 2014-08-24 17:28:08 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:28:08 --> URI Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Router Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Output Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Security Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Input Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:28:08 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Loader Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:28:08 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:28:08 --> Session Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:28:08 --> Session routines successfully run
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Controller Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:28:08 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:28:08 --> URI Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Router Class Initialized
DEBUG - 2014-08-24 17:28:08 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:28:08 --> Output Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Security Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Input Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:28:08 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Loader Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:28:08 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:28:08 --> Session Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:28:08 --> Session routines successfully run
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Controller Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:28:08 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:28:08 --> URI Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Router Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Output Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Security Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Input Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:28:08 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Loader Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:28:08 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:28:08 --> Session Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:28:08 --> Session routines successfully run
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Controller Class Initialized
DEBUG - 2014-08-24 17:28:08 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:28:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:28:08 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:28:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:28:08 --> Final output sent to browser
DEBUG - 2014-08-24 17:28:08 --> Total execution time: 0.1128
DEBUG - 2014-08-24 17:28:11 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:28:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:28:11 --> URI Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Router Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Output Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Security Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Input Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:28:11 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Loader Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:28:11 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:28:11 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:28:11 --> Session Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:28:11 --> Session routines successfully run
DEBUG - 2014-08-24 17:28:11 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:28:11 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:28:11 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:28:11 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Controller Class Initialized
DEBUG - 2014-08-24 17:28:11 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:28:12 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:28:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:28:12 --> URI Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Router Class Initialized
DEBUG - 2014-08-24 17:28:12 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:28:12 --> Output Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Security Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Input Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:28:12 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Language Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Config Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Loader Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:28:12 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:28:12 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:28:12 --> Session Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:28:12 --> Session routines successfully run
DEBUG - 2014-08-24 17:28:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:28:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:28:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:28:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Controller Class Initialized
DEBUG - 2014-08-24 17:28:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:28:12 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:28:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:28:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:28:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:28:12 --> Final output sent to browser
DEBUG - 2014-08-24 17:28:12 --> Total execution time: 0.1128
DEBUG - 2014-08-24 17:29:21 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:21 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:21 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:29:21 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:21 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:21 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:21 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:21 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:21 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:21 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:21 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:21 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:21 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:21 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:29:21 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:29:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:29:21 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:29:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:29:21 --> Final output sent to browser
DEBUG - 2014-08-24 17:29:21 --> Total execution time: 0.1265
DEBUG - 2014-08-24 17:29:24 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:24 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:24 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:29:24 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:24 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:24 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:24 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:24 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:24 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:24 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:24 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:24 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:24 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:24 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:29:24 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:29:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:29:24 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:29:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:29:24 --> Final output sent to browser
DEBUG - 2014-08-24 17:29:24 --> Total execution time: 0.1000
DEBUG - 2014-08-24 17:29:29 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:29 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:29 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:29 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:29 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:29 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:29 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Setting MX_Controller Initialized
DEBUG - 2014-08-24 17:29:29 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:29:29 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:29:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:29:29 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:29:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:29:29 --> Final output sent to browser
DEBUG - 2014-08-24 17:29:29 --> Total execution time: 0.1781
DEBUG - 2014-08-24 17:29:36 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:36 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:36 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:36 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:36 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:36 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:36 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Setting MX_Controller Initialized
DEBUG - 2014-08-24 17:29:36 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:29:36 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:29:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:29:36 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:29:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:29:36 --> Final output sent to browser
DEBUG - 2014-08-24 17:29:36 --> Total execution time: 0.1964
DEBUG - 2014-08-24 17:29:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:44 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:44 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:44 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Setting MX_Controller Initialized
DEBUG - 2014-08-24 17:29:44 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:29:44 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:45 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:45 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:45 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Setting MX_Controller Initialized
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:29:45 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:45 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:45 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:45 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Setting MX_Controller Initialized
DEBUG - 2014-08-24 17:29:45 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:29:45 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:29:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:29:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:29:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:29:45 --> Final output sent to browser
DEBUG - 2014-08-24 17:29:45 --> Total execution time: 0.2312
DEBUG - 2014-08-24 17:29:54 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:54 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:54 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:54 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:54 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:54 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:54 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:54 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:54 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:29:54 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:54 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:54 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:54 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:54 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:54 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:54 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:54 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:54 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:54 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:54 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:29:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:29:54 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:29:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:29:54 --> Final output sent to browser
DEBUG - 2014-08-24 17:29:54 --> Total execution time: 0.1276
DEBUG - 2014-08-24 17:29:59 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:59 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:59 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:59 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:59 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:59 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:59 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:59 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:29:59 --> URI Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Router Class Initialized
DEBUG - 2014-08-24 17:29:59 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:29:59 --> Output Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Security Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Input Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:29:59 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Language Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Config Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Loader Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:29:59 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:29:59 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:29:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:29:59 --> Session Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:29:59 --> Session routines successfully run
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Model Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Controller Class Initialized
DEBUG - 2014-08-24 17:29:59 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:29:59 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:29:59 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:00 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:00 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:00 --> Total execution time: 0.1355
DEBUG - 2014-08-24 17:30:03 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:03 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:03 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:03 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:03 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:03 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:03 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:03 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:03 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:30:03 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:03 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:03 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:03 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:03 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:03 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:03 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:03 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:03 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:03 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:03 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:03 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:03 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:03 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:03 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:03 --> Total execution time: 0.1102
DEBUG - 2014-08-24 17:30:06 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:06 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:06 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:06 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:06 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:06 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:06 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:06 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:06 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:06 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:30:06 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:06 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:06 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:06 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:06 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:06 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:06 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:30:07 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:07 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:07 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:07 --> Total execution time: 0.1194
DEBUG - 2014-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:09 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:09 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:09 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:09 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:09 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:09 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:30:09 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:09 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:09 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:09 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:09 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:09 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:09 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:09 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:09 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:09 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:09 --> Total execution time: 0.1253
DEBUG - 2014-08-24 17:30:22 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:22 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:22 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:22 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:22 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:22 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:22 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:22 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:22 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:22 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:22 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:22 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:22 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:22 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:22 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:22 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:22 --> Total execution time: 0.1016
DEBUG - 2014-08-24 17:30:27 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:27 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:27 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:27 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:27 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:27 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:27 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:27 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:27 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:27 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:30:27 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:27 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:27 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:27 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:27 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:27 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:30:27 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:27 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:27 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:27 --> Total execution time: 0.1180
DEBUG - 2014-08-24 17:30:30 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:30 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:30 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:30 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:30 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:30 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:30 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:30 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:30 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:30 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:30 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:30 --> Employee MX_Controller Initialized
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:30 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:30 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:30 --> Total execution time: 0.1041
DEBUG - 2014-08-24 17:30:33 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:33 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:33 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:33 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:33 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:33 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:33 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:33 --> User MX_Controller Initialized
DEBUG - 2014-08-24 17:30:33 --> Helper loaded: form_helper
DEBUG - 2014-08-24 17:30:33 --> Form Validation Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:33 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:33 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:33 --> Total execution time: 0.2834
DEBUG - 2014-08-24 17:30:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:45 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:45 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:45 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:45 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:45 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:30:45 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:45 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:45 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:45 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:45 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:45 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:45 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:45 --> Total execution time: 0.1139
DEBUG - 2014-08-24 17:30:56 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:56 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:56 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:56 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:56 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:56 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:56 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:56 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:30:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:30:56 --> URI Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Router Class Initialized
DEBUG - 2014-08-24 17:30:56 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:30:56 --> Output Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Security Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Input Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:30:56 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Language Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Config Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Loader Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:30:56 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:30:56 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:30:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:30:56 --> Session Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:30:56 --> Session routines successfully run
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Controller Class Initialized
DEBUG - 2014-08-24 17:30:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:30:56 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:30:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:30:56 --> Model Class Initialized
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:30:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:30:56 --> Final output sent to browser
DEBUG - 2014-08-24 17:30:56 --> Total execution time: 0.1183
DEBUG - 2014-08-24 17:33:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:33:44 --> URI Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Router Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Output Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Security Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Input Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:33:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Loader Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:33:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:33:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:33:44 --> Session Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:33:44 --> Session routines successfully run
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Controller Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:33:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:33:44 --> URI Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Router Class Initialized
DEBUG - 2014-08-24 17:33:44 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:33:44 --> Output Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Security Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Input Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:33:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Language Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Loader Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:33:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:33:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:33:44 --> Session Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:33:44 --> Session routines successfully run
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Controller Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:33:44 --> Config Class Initialized
DEBUG - 2014-08-24 17:33:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:33:45 --> URI Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Router Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Output Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Security Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Input Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:33:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Language Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Config Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Loader Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:33:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:33:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:33:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:33:45 --> Session Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:33:45 --> Session routines successfully run
DEBUG - 2014-08-24 17:33:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:33:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:33:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:33:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Controller Class Initialized
DEBUG - 2014-08-24 17:33:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:33:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:33:45 --> Model Class Initialized
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:33:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:33:45 --> Final output sent to browser
DEBUG - 2014-08-24 17:33:45 --> Total execution time: 0.0915
DEBUG - 2014-08-24 17:34:12 --> Config Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:34:12 --> URI Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Router Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Output Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Security Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Input Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:34:12 --> Language Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Language Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Config Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Loader Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:34:12 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:34:12 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:34:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:34:12 --> Session Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:34:12 --> Session routines successfully run
DEBUG - 2014-08-24 17:34:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:34:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:34:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:34:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Controller Class Initialized
DEBUG - 2014-08-24 17:34:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:34:13 --> Config Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Hooks Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Utf8 Class Initialized
DEBUG - 2014-08-24 17:34:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 17:34:13 --> URI Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Router Class Initialized
DEBUG - 2014-08-24 17:34:13 --> No URI present. Default controller set.
DEBUG - 2014-08-24 17:34:13 --> Output Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Security Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Input Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 17:34:13 --> Language Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Language Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Config Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Loader Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Helper loaded: url_helper
DEBUG - 2014-08-24 17:34:13 --> Helper loaded: common_helper
DEBUG - 2014-08-24 17:34:13 --> Database Driver Class Initialized
ERROR - 2014-08-24 17:34:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 17:34:13 --> Session Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Helper loaded: string_helper
DEBUG - 2014-08-24 17:34:13 --> Session routines successfully run
DEBUG - 2014-08-24 17:34:13 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 17:34:13 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 17:34:13 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 17:34:13 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Controller Class Initialized
DEBUG - 2014-08-24 17:34:13 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 17:34:13 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 17:34:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 17:34:13 --> Model Class Initialized
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 17:34:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 17:34:13 --> Final output sent to browser
DEBUG - 2014-08-24 17:34:13 --> Total execution time: 0.1424
DEBUG - 2014-08-24 18:02:26 --> Config Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:02:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:02:26 --> URI Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Router Class Initialized
DEBUG - 2014-08-24 18:02:26 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:02:26 --> Output Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Security Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Input Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:02:26 --> Language Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Language Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Config Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Loader Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:02:26 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:02:26 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:02:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:02:26 --> Session Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:02:26 --> Session routines successfully run
DEBUG - 2014-08-24 18:02:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:02:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:02:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:02:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Controller Class Initialized
DEBUG - 2014-08-24 18:02:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:02:26 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:02:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:02:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:02:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:02:26 --> Final output sent to browser
DEBUG - 2014-08-24 18:02:26 --> Total execution time: 0.1315
DEBUG - 2014-08-24 18:03:46 --> Config Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:03:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:03:46 --> URI Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Router Class Initialized
DEBUG - 2014-08-24 18:03:46 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:03:46 --> Output Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Security Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Input Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:03:46 --> Language Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Language Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Config Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Loader Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:03:46 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:03:46 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:03:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:03:46 --> Session Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:03:46 --> Session routines successfully run
DEBUG - 2014-08-24 18:03:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:03:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:03:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:03:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Controller Class Initialized
DEBUG - 2014-08-24 18:03:46 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:03:46 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:03:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:03:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:03:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:03:46 --> Final output sent to browser
DEBUG - 2014-08-24 18:03:46 --> Total execution time: 0.1162
DEBUG - 2014-08-24 18:03:53 --> Config Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:03:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:03:53 --> URI Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Router Class Initialized
DEBUG - 2014-08-24 18:03:53 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:03:53 --> Output Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Security Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Input Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:03:53 --> Language Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Language Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Config Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Loader Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:03:53 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:03:53 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:03:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:03:53 --> Session Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:03:53 --> Session routines successfully run
DEBUG - 2014-08-24 18:03:53 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:03:53 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:03:53 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:03:53 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Controller Class Initialized
DEBUG - 2014-08-24 18:03:53 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:03:53 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:03:53 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:03:53 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:03:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:03:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:03:54 --> Model Class Initialized
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:03:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:03:54 --> Final output sent to browser
DEBUG - 2014-08-24 18:03:54 --> Total execution time: 0.1193
DEBUG - 2014-08-24 18:05:45 --> Config Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:05:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:05:45 --> URI Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Router Class Initialized
DEBUG - 2014-08-24 18:05:45 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:05:45 --> Output Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Security Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Input Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:05:45 --> Language Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Language Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Config Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Loader Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:05:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:05:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:05:45 --> Session Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:05:45 --> Session routines successfully run
DEBUG - 2014-08-24 18:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Controller Class Initialized
DEBUG - 2014-08-24 18:05:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:05:45 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:05:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:05:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:05:45 --> Final output sent to browser
DEBUG - 2014-08-24 18:05:45 --> Total execution time: 0.1222
DEBUG - 2014-08-24 18:06:14 --> Config Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:06:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:06:14 --> URI Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Router Class Initialized
DEBUG - 2014-08-24 18:06:14 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:06:14 --> Output Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Security Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Input Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:06:14 --> Language Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Language Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Config Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Loader Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:06:14 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:06:14 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:06:14 --> Session Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:06:14 --> Session routines successfully run
DEBUG - 2014-08-24 18:06:14 --> Model Class Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:06:14 --> Model Class Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:06:14 --> Model Class Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:06:14 --> Model Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Model Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Controller Class Initialized
DEBUG - 2014-08-24 18:06:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:06:14 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:06:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:06:14 --> Model Class Initialized
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:06:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:06:14 --> Final output sent to browser
DEBUG - 2014-08-24 18:06:14 --> Total execution time: 0.1265
DEBUG - 2014-08-24 18:07:10 --> Config Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:07:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:07:10 --> URI Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Router Class Initialized
DEBUG - 2014-08-24 18:07:10 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:07:10 --> Output Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Security Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Input Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:07:10 --> Language Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Language Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Config Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Loader Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:07:10 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:07:10 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:07:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:07:10 --> Session Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:07:10 --> Session routines successfully run
DEBUG - 2014-08-24 18:07:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:07:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:07:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:07:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Controller Class Initialized
DEBUG - 2014-08-24 18:07:10 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:07:10 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:07:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:07:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:07:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:07:10 --> Final output sent to browser
DEBUG - 2014-08-24 18:07:10 --> Total execution time: 0.1177
DEBUG - 2014-08-24 18:11:27 --> Config Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:11:27 --> URI Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Router Class Initialized
DEBUG - 2014-08-24 18:11:27 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:11:27 --> Output Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Security Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Input Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:11:27 --> Language Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Language Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Config Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Loader Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:11:27 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:11:27 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:11:27 --> Session Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:11:27 --> Session routines successfully run
DEBUG - 2014-08-24 18:11:27 --> Model Class Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:11:27 --> Model Class Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:11:27 --> Model Class Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:11:27 --> Model Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Model Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Controller Class Initialized
DEBUG - 2014-08-24 18:11:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:11:27 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:11:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:11:27 --> Model Class Initialized
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:11:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:11:27 --> Final output sent to browser
DEBUG - 2014-08-24 18:11:27 --> Total execution time: 0.1178
DEBUG - 2014-08-24 18:12:00 --> Config Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:12:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:12:00 --> URI Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Router Class Initialized
DEBUG - 2014-08-24 18:12:00 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:12:00 --> Output Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Security Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Input Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:12:00 --> Language Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Language Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Config Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Loader Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:12:00 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:12:00 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:12:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:12:00 --> Session Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:12:00 --> Session routines successfully run
DEBUG - 2014-08-24 18:12:00 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:12:00 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:12:00 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:12:00 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Controller Class Initialized
DEBUG - 2014-08-24 18:12:00 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:12:00 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:12:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:12:00 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:12:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:12:00 --> Final output sent to browser
DEBUG - 2014-08-24 18:12:00 --> Total execution time: 0.1089
DEBUG - 2014-08-24 18:12:05 --> Config Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:12:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:12:05 --> URI Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Router Class Initialized
DEBUG - 2014-08-24 18:12:05 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:12:05 --> Output Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Security Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Input Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:12:05 --> Language Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Language Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Config Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Loader Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:12:05 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:12:05 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:12:05 --> Session Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:12:05 --> Session routines successfully run
DEBUG - 2014-08-24 18:12:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:12:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:12:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:12:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Controller Class Initialized
DEBUG - 2014-08-24 18:12:05 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:12:05 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:12:05 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:12:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:12:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:12:05 --> Final output sent to browser
DEBUG - 2014-08-24 18:12:05 --> Total execution time: 0.1238
DEBUG - 2014-08-24 18:13:18 --> Config Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:13:18 --> URI Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Router Class Initialized
DEBUG - 2014-08-24 18:13:18 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:13:18 --> Output Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Security Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Input Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:13:18 --> Language Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Language Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Config Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Loader Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:13:18 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:13:18 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:13:18 --> Session Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:13:18 --> Session routines successfully run
DEBUG - 2014-08-24 18:13:18 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:13:18 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:13:18 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:13:18 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Controller Class Initialized
DEBUG - 2014-08-24 18:13:18 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:13:18 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:13:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:13:18 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:13:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:13:18 --> Final output sent to browser
DEBUG - 2014-08-24 18:13:18 --> Total execution time: 0.1195
DEBUG - 2014-08-24 18:13:58 --> Config Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:13:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:13:58 --> URI Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Router Class Initialized
DEBUG - 2014-08-24 18:13:58 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:13:58 --> Output Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Security Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Input Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:13:58 --> Language Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Language Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Config Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Loader Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:13:58 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:13:58 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:13:58 --> Session Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:13:58 --> Session routines successfully run
DEBUG - 2014-08-24 18:13:58 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:13:58 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:13:58 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:13:58 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Controller Class Initialized
DEBUG - 2014-08-24 18:13:58 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:13:58 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:13:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:13:58 --> Model Class Initialized
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:13:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:13:58 --> Final output sent to browser
DEBUG - 2014-08-24 18:13:58 --> Total execution time: 0.1040
DEBUG - 2014-08-24 18:14:23 --> Config Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:14:23 --> URI Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Router Class Initialized
DEBUG - 2014-08-24 18:14:23 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:14:23 --> Output Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Security Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Input Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:14:23 --> Language Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Language Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Config Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Loader Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:14:23 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:14:23 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:14:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:14:23 --> Session Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:14:23 --> Session routines successfully run
DEBUG - 2014-08-24 18:14:23 --> Model Class Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:14:23 --> Model Class Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:14:23 --> Model Class Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:14:23 --> Model Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Model Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Controller Class Initialized
DEBUG - 2014-08-24 18:14:23 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:14:23 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:14:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:14:23 --> Model Class Initialized
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:14:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:14:23 --> Final output sent to browser
DEBUG - 2014-08-24 18:14:23 --> Total execution time: 0.1105
DEBUG - 2014-08-24 18:15:04 --> Config Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:15:04 --> URI Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Router Class Initialized
DEBUG - 2014-08-24 18:15:04 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:15:04 --> Output Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Security Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Input Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:15:04 --> Language Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Language Class Initialized
DEBUG - 2014-08-24 18:15:04 --> Config Class Initialized
DEBUG - 2014-08-24 18:15:05 --> Loader Class Initialized
DEBUG - 2014-08-24 18:15:05 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:15:05 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:15:05 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:15:05 --> Session Class Initialized
DEBUG - 2014-08-24 18:15:05 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:15:05 --> Session routines successfully run
DEBUG - 2014-08-24 18:15:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:15:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:15:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:15:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:05 --> Controller Class Initialized
DEBUG - 2014-08-24 18:15:05 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:15:05 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:15:05 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:15:05 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:15:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:15:05 --> Final output sent to browser
DEBUG - 2014-08-24 18:15:05 --> Total execution time: 0.1204
DEBUG - 2014-08-24 18:15:15 --> Config Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:15:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:15:15 --> URI Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Router Class Initialized
DEBUG - 2014-08-24 18:15:15 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:15:15 --> Output Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Security Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Input Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:15:15 --> Language Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Language Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Config Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Loader Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:15:15 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:15:15 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:15:15 --> Session Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:15:15 --> Session routines successfully run
DEBUG - 2014-08-24 18:15:15 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:15:15 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:15:15 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:15:15 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Controller Class Initialized
DEBUG - 2014-08-24 18:15:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:15:15 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:15:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:15:15 --> Model Class Initialized
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:15:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:15:15 --> Final output sent to browser
DEBUG - 2014-08-24 18:15:15 --> Total execution time: 0.1165
DEBUG - 2014-08-24 18:17:52 --> Config Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:17:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:17:52 --> URI Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Router Class Initialized
DEBUG - 2014-08-24 18:17:52 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:17:52 --> Output Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Security Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Input Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:17:52 --> Language Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Language Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Config Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Loader Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:17:52 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:17:52 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:17:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:17:52 --> Session Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:17:52 --> Session routines successfully run
DEBUG - 2014-08-24 18:17:52 --> Model Class Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:17:52 --> Model Class Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:17:52 --> Model Class Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:17:52 --> Model Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Model Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Controller Class Initialized
DEBUG - 2014-08-24 18:17:52 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:17:52 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:17:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:17:52 --> Model Class Initialized
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:17:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:17:52 --> Final output sent to browser
DEBUG - 2014-08-24 18:17:52 --> Total execution time: 0.1287
DEBUG - 2014-08-24 18:18:56 --> Config Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:18:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:18:56 --> URI Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Router Class Initialized
DEBUG - 2014-08-24 18:18:56 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:18:56 --> Output Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Security Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Input Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:18:56 --> Language Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Language Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Config Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Loader Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:18:56 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:18:56 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:18:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:18:56 --> Session Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:18:56 --> Session routines successfully run
DEBUG - 2014-08-24 18:18:56 --> Model Class Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:18:56 --> Model Class Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:18:56 --> Model Class Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:18:56 --> Model Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Model Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Controller Class Initialized
DEBUG - 2014-08-24 18:18:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:18:56 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:18:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:18:56 --> Model Class Initialized
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:18:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:18:56 --> Final output sent to browser
DEBUG - 2014-08-24 18:18:56 --> Total execution time: 0.1208
DEBUG - 2014-08-24 18:19:12 --> Config Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:19:12 --> URI Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Router Class Initialized
DEBUG - 2014-08-24 18:19:12 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:19:12 --> Output Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Security Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Input Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:19:12 --> Language Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Language Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Config Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Loader Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:19:12 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:19:12 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:19:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:19:12 --> Session Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:19:12 --> Session routines successfully run
DEBUG - 2014-08-24 18:19:12 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:19:12 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:19:12 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:19:12 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Controller Class Initialized
DEBUG - 2014-08-24 18:19:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:19:12 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:19:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:19:12 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:19:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:19:12 --> Final output sent to browser
DEBUG - 2014-08-24 18:19:12 --> Total execution time: 0.1000
DEBUG - 2014-08-24 18:19:21 --> Config Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:19:21 --> URI Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Router Class Initialized
DEBUG - 2014-08-24 18:19:21 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:19:21 --> Output Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Security Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Input Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:19:21 --> Language Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Language Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Config Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Loader Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:19:21 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:19:21 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:19:21 --> Session Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:19:21 --> Session routines successfully run
DEBUG - 2014-08-24 18:19:21 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:19:21 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:19:21 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:19:21 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Controller Class Initialized
DEBUG - 2014-08-24 18:19:21 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:19:21 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:19:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:19:21 --> Model Class Initialized
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:19:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:19:21 --> Final output sent to browser
DEBUG - 2014-08-24 18:19:21 --> Total execution time: 0.1038
DEBUG - 2014-08-24 18:20:24 --> Config Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:20:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:20:24 --> URI Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Router Class Initialized
DEBUG - 2014-08-24 18:20:24 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:20:24 --> Output Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Security Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Input Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:20:24 --> Language Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Language Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Config Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Loader Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:20:24 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:20:24 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:20:24 --> Session Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:20:24 --> Session routines successfully run
DEBUG - 2014-08-24 18:20:24 --> Model Class Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:20:24 --> Model Class Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:20:24 --> Model Class Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:20:24 --> Model Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Model Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Controller Class Initialized
DEBUG - 2014-08-24 18:20:24 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:20:24 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:20:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:20:24 --> Model Class Initialized
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:20:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:20:24 --> Final output sent to browser
DEBUG - 2014-08-24 18:20:24 --> Total execution time: 0.1132
DEBUG - 2014-08-24 18:21:43 --> Config Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:21:43 --> URI Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Router Class Initialized
DEBUG - 2014-08-24 18:21:43 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:21:43 --> Output Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Security Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Input Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:21:43 --> Language Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Language Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Config Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Loader Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:21:43 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:21:43 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:21:43 --> Session Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:21:43 --> Session routines successfully run
DEBUG - 2014-08-24 18:21:43 --> Model Class Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:21:43 --> Model Class Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:21:43 --> Model Class Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:21:43 --> Model Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Model Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Controller Class Initialized
DEBUG - 2014-08-24 18:21:43 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:21:43 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:21:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:21:43 --> Model Class Initialized
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:21:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:21:43 --> Final output sent to browser
DEBUG - 2014-08-24 18:21:43 --> Total execution time: 0.1050
DEBUG - 2014-08-24 18:23:08 --> Config Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:23:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:23:08 --> URI Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Router Class Initialized
DEBUG - 2014-08-24 18:23:08 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:23:08 --> Output Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Security Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Input Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:23:08 --> Language Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Language Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Config Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Loader Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:23:08 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:23:08 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:23:08 --> Session Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:23:08 --> Session routines successfully run
DEBUG - 2014-08-24 18:23:08 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:23:08 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:23:08 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:23:08 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Controller Class Initialized
DEBUG - 2014-08-24 18:23:08 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:23:08 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:23:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:23:08 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:23:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:23:08 --> Final output sent to browser
DEBUG - 2014-08-24 18:23:08 --> Total execution time: 0.1193
DEBUG - 2014-08-24 18:23:46 --> Config Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:23:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:23:46 --> URI Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Router Class Initialized
DEBUG - 2014-08-24 18:23:46 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:23:46 --> Output Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Security Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Input Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:23:46 --> Language Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Language Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Config Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Loader Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:23:46 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:23:46 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:23:46 --> Session Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:23:46 --> Session routines successfully run
DEBUG - 2014-08-24 18:23:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:23:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:23:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:23:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Controller Class Initialized
DEBUG - 2014-08-24 18:23:46 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:23:46 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:23:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:23:46 --> Model Class Initialized
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:23:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:23:46 --> Final output sent to browser
DEBUG - 2014-08-24 18:23:46 --> Total execution time: 0.1227
DEBUG - 2014-08-24 18:25:20 --> Config Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:25:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:25:20 --> URI Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Router Class Initialized
DEBUG - 2014-08-24 18:25:20 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:25:20 --> Output Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Security Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Input Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:25:20 --> Language Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Language Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Config Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Loader Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:25:20 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:25:20 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:25:20 --> Session Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:25:20 --> Session routines successfully run
DEBUG - 2014-08-24 18:25:20 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:25:20 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:25:20 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:25:20 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Controller Class Initialized
DEBUG - 2014-08-24 18:25:20 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:25:20 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:25:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:25:20 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:25:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:25:20 --> Final output sent to browser
DEBUG - 2014-08-24 18:25:20 --> Total execution time: 0.1185
DEBUG - 2014-08-24 18:25:38 --> Config Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:25:38 --> URI Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Router Class Initialized
DEBUG - 2014-08-24 18:25:38 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:25:38 --> Output Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Security Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Input Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:25:38 --> Language Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Language Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Config Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Loader Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:25:38 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:25:38 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:25:38 --> Session Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:25:38 --> Session routines successfully run
DEBUG - 2014-08-24 18:25:38 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:25:38 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:25:38 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:25:38 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Controller Class Initialized
DEBUG - 2014-08-24 18:25:38 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:25:38 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:25:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:25:38 --> Model Class Initialized
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:25:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:25:38 --> Final output sent to browser
DEBUG - 2014-08-24 18:25:38 --> Total execution time: 0.1053
DEBUG - 2014-08-24 18:26:10 --> Config Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:26:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:26:10 --> URI Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Router Class Initialized
DEBUG - 2014-08-24 18:26:10 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:26:10 --> Output Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Security Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Input Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:26:10 --> Language Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Language Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Config Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Loader Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:26:10 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:26:10 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:26:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:26:10 --> Session Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:26:10 --> Session routines successfully run
DEBUG - 2014-08-24 18:26:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:26:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:26:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:26:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Controller Class Initialized
DEBUG - 2014-08-24 18:26:10 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:26:10 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:26:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:26:10 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:26:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:26:10 --> Final output sent to browser
DEBUG - 2014-08-24 18:26:10 --> Total execution time: 0.1155
DEBUG - 2014-08-24 18:26:26 --> Config Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:26:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:26:26 --> URI Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Router Class Initialized
DEBUG - 2014-08-24 18:26:26 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:26:26 --> Output Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Security Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Input Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:26:26 --> Language Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Language Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Config Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Loader Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:26:26 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:26:26 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:26:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:26:26 --> Session Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:26:26 --> Session routines successfully run
DEBUG - 2014-08-24 18:26:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:26:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:26:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:26:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Controller Class Initialized
DEBUG - 2014-08-24 18:26:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:26:26 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:26:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:26:26 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:26:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:26:26 --> Final output sent to browser
DEBUG - 2014-08-24 18:26:26 --> Total execution time: 0.1264
DEBUG - 2014-08-24 18:26:49 --> Config Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:26:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:26:49 --> URI Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Router Class Initialized
DEBUG - 2014-08-24 18:26:49 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:26:49 --> Output Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Security Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Input Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:26:49 --> Language Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Language Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Config Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Loader Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:26:49 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:26:49 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:26:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:26:49 --> Session Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:26:49 --> Session routines successfully run
DEBUG - 2014-08-24 18:26:49 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:26:49 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:26:49 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:26:49 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Controller Class Initialized
DEBUG - 2014-08-24 18:26:49 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:26:49 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:26:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:26:49 --> Model Class Initialized
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:26:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:26:49 --> Final output sent to browser
DEBUG - 2014-08-24 18:26:49 --> Total execution time: 0.1258
DEBUG - 2014-08-24 18:28:02 --> Config Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:28:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:28:02 --> URI Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Router Class Initialized
DEBUG - 2014-08-24 18:28:02 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:28:02 --> Output Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Security Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Input Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:28:02 --> Language Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Language Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Config Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Loader Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:28:02 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:28:02 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:28:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:28:02 --> Session Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:28:02 --> Session routines successfully run
DEBUG - 2014-08-24 18:28:02 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:28:02 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:28:02 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:28:02 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Controller Class Initialized
DEBUG - 2014-08-24 18:28:02 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:28:02 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:28:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:28:02 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:28:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:28:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:28:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:28:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:28:03 --> Final output sent to browser
DEBUG - 2014-08-24 18:28:03 --> Total execution time: 0.1246
DEBUG - 2014-08-24 18:28:42 --> Config Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Hooks Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Utf8 Class Initialized
DEBUG - 2014-08-24 18:28:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 18:28:42 --> URI Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Router Class Initialized
DEBUG - 2014-08-24 18:28:42 --> No URI present. Default controller set.
DEBUG - 2014-08-24 18:28:42 --> Output Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Security Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Input Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 18:28:42 --> Language Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Language Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Config Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Loader Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Helper loaded: url_helper
DEBUG - 2014-08-24 18:28:42 --> Helper loaded: common_helper
DEBUG - 2014-08-24 18:28:42 --> Database Driver Class Initialized
ERROR - 2014-08-24 18:28:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 18:28:42 --> Session Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Helper loaded: string_helper
DEBUG - 2014-08-24 18:28:42 --> Session routines successfully run
DEBUG - 2014-08-24 18:28:42 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 18:28:42 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 18:28:42 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 18:28:42 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Controller Class Initialized
DEBUG - 2014-08-24 18:28:42 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 18:28:42 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 18:28:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 18:28:42 --> Model Class Initialized
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 18:28:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 18:28:42 --> Final output sent to browser
DEBUG - 2014-08-24 18:28:42 --> Total execution time: 0.1182
DEBUG - 2014-08-24 19:17:43 --> Config Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Hooks Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Utf8 Class Initialized
DEBUG - 2014-08-24 19:17:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 19:17:43 --> URI Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Router Class Initialized
DEBUG - 2014-08-24 19:17:43 --> No URI present. Default controller set.
DEBUG - 2014-08-24 19:17:43 --> Output Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Security Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Input Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 19:17:43 --> Language Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Language Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Config Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Loader Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Helper loaded: url_helper
DEBUG - 2014-08-24 19:17:43 --> Helper loaded: common_helper
DEBUG - 2014-08-24 19:17:43 --> Database Driver Class Initialized
ERROR - 2014-08-24 19:17:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 19:17:43 --> Session Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Helper loaded: string_helper
DEBUG - 2014-08-24 19:17:43 --> Session routines successfully run
DEBUG - 2014-08-24 19:17:43 --> Model Class Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 19:17:43 --> Model Class Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 19:17:43 --> Model Class Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 19:17:43 --> Model Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Model Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Controller Class Initialized
DEBUG - 2014-08-24 19:17:43 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 19:17:43 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 19:17:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 19:17:43 --> Model Class Initialized
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 19:17:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 19:17:43 --> Final output sent to browser
DEBUG - 2014-08-24 19:17:43 --> Total execution time: 0.1192
DEBUG - 2014-08-24 19:25:41 --> Config Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Hooks Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Utf8 Class Initialized
DEBUG - 2014-08-24 19:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 19:25:41 --> URI Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Router Class Initialized
DEBUG - 2014-08-24 19:25:41 --> No URI present. Default controller set.
DEBUG - 2014-08-24 19:25:41 --> Output Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Security Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Input Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 19:25:41 --> Language Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Language Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Config Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Loader Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Helper loaded: url_helper
DEBUG - 2014-08-24 19:25:41 --> Helper loaded: common_helper
DEBUG - 2014-08-24 19:25:41 --> Database Driver Class Initialized
ERROR - 2014-08-24 19:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 19:25:41 --> Session Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Helper loaded: string_helper
DEBUG - 2014-08-24 19:25:41 --> Session routines successfully run
DEBUG - 2014-08-24 19:25:41 --> Model Class Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 19:25:41 --> Model Class Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 19:25:41 --> Model Class Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 19:25:41 --> Model Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Model Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Controller Class Initialized
DEBUG - 2014-08-24 19:25:41 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 19:25:41 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 19:25:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 19:25:41 --> Model Class Initialized
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 19:25:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 19:25:41 --> Final output sent to browser
DEBUG - 2014-08-24 19:25:41 --> Total execution time: 0.1228
DEBUG - 2014-08-24 21:42:37 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:37 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:37 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:37 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:37 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:37 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:37 --> A session cookie was not found.
DEBUG - 2014-08-24 21:42:37 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 21:42:37 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:37 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:37 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:37 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:37 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:37 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:37 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:37 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:42:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:42:37 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:42:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:42:37 --> Final output sent to browser
DEBUG - 2014-08-24 21:42:37 --> Total execution time: 0.0779
DEBUG - 2014-08-24 21:42:39 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:39 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:39 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:39 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:39 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:39 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:39 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:42:39 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:39 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:39 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:42:39 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:39 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:39 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:39 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:39 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:39 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:42:39 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:42:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:42:39 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:42:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:42:39 --> Final output sent to browser
DEBUG - 2014-08-24 21:42:39 --> Total execution time: 0.1031
DEBUG - 2014-08-24 21:42:42 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:42 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:42 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:42 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:42 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:42 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:42 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:42 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:42 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:42 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:42 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:42 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:42:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:42:42 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:42:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:42:42 --> Final output sent to browser
DEBUG - 2014-08-24 21:42:42 --> Total execution time: 0.0992
DEBUG - 2014-08-24 21:42:43 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:43 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:43 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:43 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:43 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:43 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:43 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:43 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:43 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:43 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:43 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:43 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:44 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 21:42:44 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:42:44 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:42:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:42:44 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:44 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:42:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:42:44 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:42:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:42:44 --> Final output sent to browser
DEBUG - 2014-08-24 21:42:44 --> Total execution time: 0.2701
DEBUG - 2014-08-24 21:42:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:42:48 --> URI Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Router Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Output Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Security Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Input Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:42:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Loader Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:42:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:42:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:42:48 --> Session Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:42:48 --> Session routines successfully run
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Controller Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:42:48 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:42:48 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:42:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:42:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:42:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:42:48 --> Final output sent to browser
DEBUG - 2014-08-24 21:42:48 --> Total execution time: 0.2485
DEBUG - 2014-08-24 21:43:20 --> Config Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:43:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:43:20 --> URI Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Router Class Initialized
DEBUG - 2014-08-24 21:43:20 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:43:20 --> Output Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Security Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Input Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:43:20 --> Language Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Language Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Config Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Loader Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:43:20 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:43:20 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:43:20 --> Session Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:43:20 --> Session routines successfully run
DEBUG - 2014-08-24 21:43:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:43:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:43:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:43:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Controller Class Initialized
DEBUG - 2014-08-24 21:43:20 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:43:20 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:43:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:43:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:43:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:43:20 --> Final output sent to browser
DEBUG - 2014-08-24 21:43:20 --> Total execution time: 0.0985
DEBUG - 2014-08-24 21:47:52 --> Config Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:47:52 --> URI Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Router Class Initialized
DEBUG - 2014-08-24 21:47:52 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:47:52 --> Output Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Security Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Input Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:47:52 --> Language Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Language Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Config Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Loader Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:47:52 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:47:52 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:47:52 --> Session Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:47:52 --> Session routines successfully run
DEBUG - 2014-08-24 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Controller Class Initialized
DEBUG - 2014-08-24 21:47:52 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:47:52 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:47:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:47:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:47:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:47:52 --> Final output sent to browser
DEBUG - 2014-08-24 21:47:52 --> Total execution time: 0.1191
DEBUG - 2014-08-24 21:48:31 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:31 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:31 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:48:31 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:31 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:31 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:31 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:31 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:31 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:31 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:48:31 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:48:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:48:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:48:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:48:31 --> Final output sent to browser
DEBUG - 2014-08-24 21:48:31 --> Total execution time: 0.1151
DEBUG - 2014-08-24 21:48:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:48 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:48 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:48 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:48:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:48 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:48 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:48:48 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:48 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:48 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:48:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:48 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:48 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:48 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:48:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:48:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:48:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:48:48 --> Final output sent to browser
DEBUG - 2014-08-24 21:48:48 --> Total execution time: 0.0947
DEBUG - 2014-08-24 21:48:52 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:52 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:52 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:52 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:52 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:52 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:52 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:48:52 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:52 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:52 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:48:52 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:52 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:52 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:52 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:52 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:52 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:52 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:48:52 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:48:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:48:52 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:48:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:48:52 --> Final output sent to browser
DEBUG - 2014-08-24 21:48:52 --> Total execution time: 0.1134
DEBUG - 2014-08-24 21:48:58 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:48:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:48:58 --> URI Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Router Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Output Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Security Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Input Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:48:58 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Language Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Config Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Loader Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:48:58 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:48:58 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:48:58 --> Session Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:48:58 --> Session routines successfully run
DEBUG - 2014-08-24 21:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Controller Class Initialized
DEBUG - 2014-08-24 21:48:58 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:48:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:48:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:48:58 --> Final output sent to browser
DEBUG - 2014-08-24 21:48:58 --> Total execution time: 0.1009
DEBUG - 2014-08-24 21:49:00 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:49:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:49:00 --> URI Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Router Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Output Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Security Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Input Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:49:00 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Loader Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:49:00 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:49:00 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:49:00 --> Session Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:49:00 --> Session routines successfully run
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Controller Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 21:49:00 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:49:00 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:49:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:49:00 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:00 --> Final output sent to browser
DEBUG - 2014-08-24 21:49:00 --> Total execution time: 0.1900
DEBUG - 2014-08-24 21:49:02 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:49:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:49:02 --> URI Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Router Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Output Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Security Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Input Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:49:02 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Loader Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:49:02 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:49:02 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:49:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:49:02 --> Session Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:49:02 --> Session routines successfully run
DEBUG - 2014-08-24 21:49:02 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:49:02 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:49:02 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:49:02 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Controller Class Initialized
DEBUG - 2014-08-24 21:49:02 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:49:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:49:02 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:02 --> Final output sent to browser
DEBUG - 2014-08-24 21:49:02 --> Total execution time: 0.1044
DEBUG - 2014-08-24 21:49:14 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:49:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:49:14 --> URI Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Router Class Initialized
DEBUG - 2014-08-24 21:49:14 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:49:14 --> Output Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Security Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Input Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:49:14 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Loader Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:49:14 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:49:14 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:49:14 --> Session Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:49:14 --> Session routines successfully run
DEBUG - 2014-08-24 21:49:14 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:49:14 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:49:14 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:49:14 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Controller Class Initialized
DEBUG - 2014-08-24 21:49:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:49:14 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:49:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:49:14 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:14 --> Final output sent to browser
DEBUG - 2014-08-24 21:49:14 --> Total execution time: 0.1223
DEBUG - 2014-08-24 21:49:31 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:49:31 --> URI Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Router Class Initialized
DEBUG - 2014-08-24 21:49:31 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:49:31 --> Output Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Security Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Input Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:49:31 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Loader Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:49:31 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:49:31 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:49:31 --> Session Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:49:31 --> Session routines successfully run
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Controller Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:49:31 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:49:31 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:49:31 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 21:49:31 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:49:31 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:49:31 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:31 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:49:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:49:32 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/report/views/warehouseman_dashboard.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:32 --> Final output sent to browser
DEBUG - 2014-08-24 21:49:32 --> Total execution time: 0.2525
DEBUG - 2014-08-24 21:49:58 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:49:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:49:58 --> URI Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Router Class Initialized
DEBUG - 2014-08-24 21:49:58 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:49:58 --> Output Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Security Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Input Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:49:58 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Language Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Config Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Loader Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:49:58 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:49:58 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:49:58 --> Session Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:49:58 --> Session routines successfully run
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Controller Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:49:58 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 21:49:58 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:49:58 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:49:58 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:49:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:49:58 --> Model Class Initialized
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/report/views/warehouseman_dashboard.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:49:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:49:58 --> Final output sent to browser
DEBUG - 2014-08-24 21:49:58 --> Total execution time: 0.2411
DEBUG - 2014-08-24 21:51:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:51:48 --> URI Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Router Class Initialized
DEBUG - 2014-08-24 21:51:48 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:51:48 --> Output Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Security Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Input Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:51:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Language Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Config Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Loader Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:51:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:51:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:51:48 --> Session Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:51:48 --> Session routines successfully run
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Controller Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:51:48 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 21:51:48 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:51:48 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:51:48 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:51:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:51:48 --> Model Class Initialized
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:51:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:51:48 --> Final output sent to browser
DEBUG - 2014-08-24 21:51:48 --> Total execution time: 0.1971
DEBUG - 2014-08-24 21:52:55 --> Config Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:52:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:52:55 --> URI Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Router Class Initialized
DEBUG - 2014-08-24 21:52:55 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:52:55 --> Output Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Security Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Input Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:52:55 --> Language Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Language Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Config Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Loader Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:52:55 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:52:55 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:52:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:52:55 --> Session Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:52:55 --> Session routines successfully run
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Controller Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:52:55 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 21:52:55 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:52:55 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:52:55 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:52:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:52:55 --> Model Class Initialized
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:52:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:52:55 --> Final output sent to browser
DEBUG - 2014-08-24 21:52:55 --> Total execution time: 0.2070
DEBUG - 2014-08-24 21:56:11 --> Config Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:56:11 --> URI Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Router Class Initialized
DEBUG - 2014-08-24 21:56:11 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:56:11 --> Output Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Security Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Input Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:56:11 --> Language Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Language Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Config Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Loader Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:56:11 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:56:11 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:56:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:56:11 --> Session Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:56:11 --> Session routines successfully run
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Controller Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:56:11 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 21:56:11 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:56:11 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:56:11 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:56:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:56:11 --> Model Class Initialized
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:56:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:56:11 --> Final output sent to browser
DEBUG - 2014-08-24 21:56:11 --> Total execution time: 0.2138
DEBUG - 2014-08-24 21:58:20 --> Config Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Hooks Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Utf8 Class Initialized
DEBUG - 2014-08-24 21:58:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 21:58:20 --> URI Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Router Class Initialized
DEBUG - 2014-08-24 21:58:20 --> No URI present. Default controller set.
DEBUG - 2014-08-24 21:58:20 --> Output Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Security Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Input Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 21:58:20 --> Language Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Language Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Config Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Loader Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Helper loaded: url_helper
DEBUG - 2014-08-24 21:58:20 --> Helper loaded: common_helper
DEBUG - 2014-08-24 21:58:20 --> Database Driver Class Initialized
ERROR - 2014-08-24 21:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 21:58:20 --> Session Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Helper loaded: string_helper
DEBUG - 2014-08-24 21:58:20 --> Session routines successfully run
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Controller Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 21:58:20 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 21:58:20 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 21:58:20 --> Helper loaded: form_helper
DEBUG - 2014-08-24 21:58:20 --> Form Validation Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 21:58:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 21:58:20 --> Model Class Initialized
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 21:58:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 21:58:20 --> Final output sent to browser
DEBUG - 2014-08-24 21:58:20 --> Total execution time: 0.2463
DEBUG - 2014-08-24 22:00:39 --> Config Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:00:39 --> URI Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Router Class Initialized
DEBUG - 2014-08-24 22:00:39 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:00:39 --> Output Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Security Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Input Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:00:39 --> Language Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Language Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Config Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Loader Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:00:39 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:00:39 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:00:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:00:39 --> Session Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:00:39 --> Session routines successfully run
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Controller Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:00:39 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:00:39 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:00:39 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:00:39 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:00:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:00:39 --> Model Class Initialized
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:00:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:00:39 --> Final output sent to browser
DEBUG - 2014-08-24 22:00:39 --> Total execution time: 0.2112
DEBUG - 2014-08-24 22:01:23 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:23 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:23 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:23 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:23 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:23 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:23 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:23 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:23 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:23 --> Total execution time: 0.1206
DEBUG - 2014-08-24 22:01:25 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:25 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:25 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:25 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:25 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:25 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:25 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:01:25 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:25 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:25 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:25 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:25 --> Total execution time: 0.1815
DEBUG - 2014-08-24 22:01:27 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:27 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:27 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:01:27 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:27 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:27 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:27 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:27 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:27 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:01:27 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:01:27 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:01:27 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:27 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:27 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:27 --> Total execution time: 0.2022
DEBUG - 2014-08-24 22:01:30 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:30 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:30 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:30 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:30 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:30 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:30 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:30 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:30 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:30 --> Total execution time: 0.1021
DEBUG - 2014-08-24 22:01:31 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:31 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:31 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:31 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:31 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:31 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:31 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:01:31 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:31 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:31 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:31 --> Total execution time: 0.1871
DEBUG - 2014-08-24 22:01:33 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:33 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:33 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:33 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:33 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:33 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:33 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-24 22:01:33 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:33 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:33 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:33 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:33 --> Total execution time: 0.1849
DEBUG - 2014-08-24 22:01:41 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:41 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:41 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:41 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:41 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:41 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:41 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-24 22:01:41 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:41 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:41 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:41 --> Total execution time: 0.1844
DEBUG - 2014-08-24 22:01:45 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:45 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:45 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:45 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:45 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-24 22:01:45 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:45 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:45 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:45 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:45 --> Total execution time: 0.1665
DEBUG - 2014-08-24 22:01:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:48 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:48 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:48 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:01:48 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:48 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:48 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:48 --> Total execution time: 0.1949
DEBUG - 2014-08-24 22:01:50 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:50 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:50 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:50 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:50 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:50 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:50 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:01:50 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:50 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:50 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:50 --> Total execution time: 0.1905
DEBUG - 2014-08-24 22:01:53 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:53 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:53 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:53 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:53 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:53 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:53 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-24 22:01:53 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:53 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:53 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:53 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:53 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:53 --> Total execution time: 0.1614
DEBUG - 2014-08-24 22:01:55 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:01:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:01:55 --> URI Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Router Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Output Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Security Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Input Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:01:55 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Language Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Config Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Loader Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:01:55 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:01:55 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:01:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:01:55 --> Session Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:01:55 --> Session routines successfully run
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Controller Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:01:55 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:01:55 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:01:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:01:55 --> Model Class Initialized
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:01:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:01:55 --> Final output sent to browser
DEBUG - 2014-08-24 22:01:55 --> Total execution time: 0.1918
DEBUG - 2014-08-24 22:02:14 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:14 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:14 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:14 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:14 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:14 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:14 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:14 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:14 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:14 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:14 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:14 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:14 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:14 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:17 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:17 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:17 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:17 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:17 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:17 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:17 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:17 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:17 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:17 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:17 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:17 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:17 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:17 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:43 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:43 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:43 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:43 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:43 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:43 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:43 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:43 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:02:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:02:43 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:02:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:02:43 --> Final output sent to browser
DEBUG - 2014-08-24 22:02:43 --> Total execution time: 0.2010
DEBUG - 2014-08-24 22:02:43 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:43 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:44 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:44 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:44 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:44 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:44 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:44 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:44 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:02:44 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:44 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:02:50 --> URI Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Router Class Initialized
DEBUG - 2014-08-24 22:02:50 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:02:50 --> Output Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Security Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Input Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:02:50 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Language Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Config Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Loader Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:02:50 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:02:50 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:02:50 --> Session Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:02:50 --> Session routines successfully run
DEBUG - 2014-08-24 22:02:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:02:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:02:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:02:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Controller Class Initialized
DEBUG - 2014-08-24 22:02:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:02:51 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:02:51 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:02:51 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:02:51 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:02:51 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:02:51 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:51 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:02:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:02:51 --> Model Class Initialized
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:02:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:02:51 --> Final output sent to browser
DEBUG - 2014-08-24 22:02:51 --> Total execution time: 0.2211
DEBUG - 2014-08-24 22:32:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:32:44 --> URI Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Router Class Initialized
DEBUG - 2014-08-24 22:32:44 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:32:44 --> Output Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Security Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Input Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:32:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Loader Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:32:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:32:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:32:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:32:44 --> Session Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:32:44 --> Session routines successfully run
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Controller Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:32:44 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:32:44 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:32:44 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:32:44 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:32:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:32:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:32:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:32:44 --> Final output sent to browser
DEBUG - 2014-08-24 22:32:44 --> Total execution time: 0.2081
DEBUG - 2014-08-24 22:34:18 --> Config Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:34:18 --> URI Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Router Class Initialized
DEBUG - 2014-08-24 22:34:18 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:34:18 --> Output Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Security Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Input Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:34:18 --> Language Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Language Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Config Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Loader Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:34:18 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:34:18 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:34:18 --> Session Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:34:18 --> Session routines successfully run
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Controller Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:34:18 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:34:18 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:34:18 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:34:18 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:34:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:34:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:34:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:34:18 --> Final output sent to browser
DEBUG - 2014-08-24 22:34:18 --> Total execution time: 0.2738
DEBUG - 2014-08-24 22:34:22 --> Config Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:34:22 --> URI Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Router Class Initialized
DEBUG - 2014-08-24 22:34:22 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:34:22 --> Output Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Security Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Input Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:34:22 --> Language Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Language Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Config Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Loader Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:34:22 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:34:22 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:34:22 --> Session Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:34:22 --> Session routines successfully run
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Controller Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:34:22 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:34:22 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:34:22 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:34:22 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:34:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:34:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:34:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:34:22 --> Final output sent to browser
DEBUG - 2014-08-24 22:34:22 --> Total execution time: 0.2010
DEBUG - 2014-08-24 22:34:59 --> Config Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:34:59 --> URI Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Router Class Initialized
DEBUG - 2014-08-24 22:34:59 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:34:59 --> Output Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Security Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Input Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:34:59 --> Language Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Language Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Config Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Loader Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:34:59 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:34:59 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:34:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:34:59 --> Session Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:34:59 --> Session routines successfully run
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Controller Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:34:59 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:34:59 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:34:59 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:34:59 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:34:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:34:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:34:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:34:59 --> Final output sent to browser
DEBUG - 2014-08-24 22:34:59 --> Total execution time: 0.2072
DEBUG - 2014-08-24 22:35:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:35:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:35:48 --> URI Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Router Class Initialized
DEBUG - 2014-08-24 22:35:48 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:35:48 --> Output Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Security Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Input Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:35:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Loader Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:35:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:35:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:35:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:35:48 --> Session Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:35:48 --> Session routines successfully run
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Controller Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:35:48 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:35:48 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:35:48 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:35:48 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:35:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:35:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:35:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:35:48 --> Final output sent to browser
DEBUG - 2014-08-24 22:35:48 --> Total execution time: 0.2042
DEBUG - 2014-08-24 22:37:12 --> Config Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:37:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:37:12 --> URI Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Router Class Initialized
DEBUG - 2014-08-24 22:37:12 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:37:12 --> Output Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Security Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Input Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:37:12 --> Language Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Language Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Config Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Loader Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:37:12 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:37:12 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:37:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:37:12 --> Session Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:37:12 --> Session routines successfully run
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Controller Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:37:12 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:37:12 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:37:12 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:37:12 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:37:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:37:12 --> Model Class Initialized
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:37:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:37:12 --> Final output sent to browser
DEBUG - 2014-08-24 22:37:12 --> Total execution time: 0.2143
DEBUG - 2014-08-24 22:40:16 --> Config Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:40:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:40:16 --> URI Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Router Class Initialized
DEBUG - 2014-08-24 22:40:16 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:40:16 --> Output Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Security Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Input Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:40:16 --> Language Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Language Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Config Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Loader Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:40:16 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:40:16 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:40:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:40:16 --> Session Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:40:16 --> Session routines successfully run
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Controller Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:40:16 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:40:16 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:40:16 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:40:16 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:40:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:40:16 --> Model Class Initialized
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:40:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:40:16 --> Final output sent to browser
DEBUG - 2014-08-24 22:40:16 --> Total execution time: 0.2033
DEBUG - 2014-08-24 22:41:58 --> Config Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:41:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:41:58 --> URI Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Router Class Initialized
DEBUG - 2014-08-24 22:41:58 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:41:58 --> Output Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Security Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Input Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:41:58 --> Language Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Language Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Config Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Loader Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:41:58 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:41:58 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:41:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:41:58 --> Session Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:41:58 --> Session routines successfully run
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Controller Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:41:58 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:41:58 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:41:58 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:41:58 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:41:58 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:41:58 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:41:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:41:59 --> Model Class Initialized
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:41:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:41:59 --> Final output sent to browser
DEBUG - 2014-08-24 22:41:59 --> Total execution time: 0.2163
DEBUG - 2014-08-24 22:42:07 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:42:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:42:07 --> URI Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Router Class Initialized
DEBUG - 2014-08-24 22:42:07 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:42:07 --> Output Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Security Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Input Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:42:07 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Loader Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:42:07 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:42:07 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:42:07 --> Session Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:42:07 --> Session routines successfully run
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Controller Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:42:07 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:42:07 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:42:07 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:42:07 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:42:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:42:07 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:42:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:42:07 --> Final output sent to browser
DEBUG - 2014-08-24 22:42:07 --> Total execution time: 0.1989
DEBUG - 2014-08-24 22:42:09 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:42:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:42:09 --> URI Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Router Class Initialized
DEBUG - 2014-08-24 22:42:09 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:42:09 --> Output Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Security Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Input Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:42:09 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Loader Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:42:09 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:42:09 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:42:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:42:09 --> Session Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:42:09 --> Session routines successfully run
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Controller Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:42:09 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:42:09 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:42:09 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:42:09 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:42:09 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:42:09 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:42:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:42:10 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:42:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:42:10 --> Final output sent to browser
DEBUG - 2014-08-24 22:42:10 --> Total execution time: 0.1932
DEBUG - 2014-08-24 22:42:11 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:42:11 --> URI Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Router Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Output Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Security Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Input Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:42:11 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Loader Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:42:11 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:42:11 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:42:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:42:11 --> Session Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:42:11 --> Session routines successfully run
DEBUG - 2014-08-24 22:42:11 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:42:11 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:42:11 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:42:11 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Controller Class Initialized
DEBUG - 2014-08-24 22:42:11 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:42:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:42:11 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:42:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:42:11 --> Final output sent to browser
DEBUG - 2014-08-24 22:42:11 --> Total execution time: 0.0846
DEBUG - 2014-08-24 22:42:13 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:42:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:42:13 --> URI Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Router Class Initialized
DEBUG - 2014-08-24 22:42:13 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:42:13 --> Output Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Security Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Input Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:42:13 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Language Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Config Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Loader Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:42:13 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:42:13 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:42:13 --> Session Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:42:13 --> Session routines successfully run
DEBUG - 2014-08-24 22:42:13 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:42:13 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:42:13 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:42:13 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Controller Class Initialized
DEBUG - 2014-08-24 22:42:13 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:42:14 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:42:14 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:42:14 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:42:14 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:42:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:42:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:42:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:42:14 --> Model Class Initialized
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:42:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:42:14 --> Final output sent to browser
DEBUG - 2014-08-24 22:42:14 --> Total execution time: 0.2194
DEBUG - 2014-08-24 22:44:20 --> Config Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:44:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:44:20 --> URI Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Router Class Initialized
DEBUG - 2014-08-24 22:44:20 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:44:20 --> Output Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Security Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Input Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:44:20 --> Language Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Language Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Config Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Loader Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:44:20 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:44:20 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:44:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:44:20 --> Session Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:44:20 --> Session routines successfully run
DEBUG - 2014-08-24 22:44:20 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:44:20 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:44:20 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:44:20 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Controller Class Initialized
DEBUG - 2014-08-24 22:44:20 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:44:54 --> Config Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:44:54 --> URI Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Router Class Initialized
DEBUG - 2014-08-24 22:44:54 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:44:54 --> Output Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Security Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Input Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:44:54 --> Language Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Language Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Config Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Loader Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:44:54 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:44:54 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:44:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:44:54 --> Session Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:44:54 --> Session routines successfully run
DEBUG - 2014-08-24 22:44:54 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:44:54 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:44:54 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:44:54 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Controller Class Initialized
DEBUG - 2014-08-24 22:44:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:44:54 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:44:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:44:54 --> Model Class Initialized
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:44:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:44:54 --> Final output sent to browser
DEBUG - 2014-08-24 22:44:54 --> Total execution time: 0.1035
DEBUG - 2014-08-24 22:45:47 --> Config Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:45:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:45:47 --> URI Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Router Class Initialized
DEBUG - 2014-08-24 22:45:47 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:45:47 --> Output Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Security Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Input Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:45:47 --> Language Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Language Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Config Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Loader Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:45:47 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:45:47 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:45:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:45:47 --> Session Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:45:47 --> Session routines successfully run
DEBUG - 2014-08-24 22:45:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:45:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:45:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:45:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Controller Class Initialized
DEBUG - 2014-08-24 22:45:47 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:45:47 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:45:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:45:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:45:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:45:47 --> Final output sent to browser
DEBUG - 2014-08-24 22:45:47 --> Total execution time: 0.1258
DEBUG - 2014-08-24 22:46:23 --> Config Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:46:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:46:23 --> URI Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Router Class Initialized
DEBUG - 2014-08-24 22:46:23 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:46:23 --> Output Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Security Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Input Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:46:23 --> Language Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Language Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Config Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Loader Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:46:23 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:46:23 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:46:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:46:23 --> Session Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:46:23 --> Session routines successfully run
DEBUG - 2014-08-24 22:46:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:46:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:46:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:46:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Controller Class Initialized
DEBUG - 2014-08-24 22:46:23 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:46:23 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:46:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:46:23 --> Model Class Initialized
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:46:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:46:23 --> Final output sent to browser
DEBUG - 2014-08-24 22:46:23 --> Total execution time: 0.1065
DEBUG - 2014-08-24 22:47:18 --> Config Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:47:18 --> URI Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Router Class Initialized
DEBUG - 2014-08-24 22:47:18 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:47:18 --> Output Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Security Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Input Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:47:18 --> Language Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Language Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Config Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Loader Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:47:18 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:47:18 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:47:18 --> Session Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:47:18 --> Session routines successfully run
DEBUG - 2014-08-24 22:47:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:47:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:47:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:47:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Controller Class Initialized
DEBUG - 2014-08-24 22:47:18 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:47:18 --> Report MX_Controller Initialized
ERROR - 2014-08-24 22:47:18 --> Module controller failed to run: report/dashboard
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:47:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:47:18 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:47:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:47:18 --> Final output sent to browser
DEBUG - 2014-08-24 22:47:18 --> Total execution time: 0.1216
DEBUG - 2014-08-24 22:47:30 --> Config Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:47:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:47:30 --> URI Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Router Class Initialized
DEBUG - 2014-08-24 22:47:30 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:47:30 --> Output Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Security Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Input Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:47:30 --> Language Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Language Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Config Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Loader Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:47:30 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:47:30 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:47:30 --> Session Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:47:30 --> Session routines successfully run
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Controller Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:47:30 --> File loaded: application/controllers/../modules/report/controllers/report.php
DEBUG - 2014-08-24 22:47:30 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:47:30 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 22:47:30 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 22:47:30 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:47:30 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:30 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/modules/site/views/dashboard/dashboard.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:47:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:47:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:47:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:47:31 --> Final output sent to browser
DEBUG - 2014-08-24 22:47:31 --> Total execution time: 0.2243
DEBUG - 2014-08-24 22:48:57 --> Config Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:48:57 --> URI Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Router Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Output Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Security Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Input Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:48:57 --> Language Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Language Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Config Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Loader Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:48:57 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:48:57 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:48:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:48:57 --> Session Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:48:57 --> Session routines successfully run
DEBUG - 2014-08-24 22:48:57 --> Model Class Initialized
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:48:57 --> Model Class Initialized
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:48:57 --> Model Class Initialized
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:48:57 --> Model Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Model Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Controller Class Initialized
DEBUG - 2014-08-24 22:48:57 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:48:57 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:48:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:48:58 --> Model Class Initialized
DEBUG - 2014-08-24 22:48:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:48:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:48:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:48:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:48:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:48:58 --> Final output sent to browser
DEBUG - 2014-08-24 22:48:58 --> Total execution time: 0.1140
DEBUG - 2014-08-24 22:59:22 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:22 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:22 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:59:22 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:22 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:22 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:22 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:22 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:22 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:22 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:22 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:22 --> Total execution time: 0.1375
DEBUG - 2014-08-24 22:59:27 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:27 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:27 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:59:27 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:27 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:27 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:27 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:27 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:27 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:27 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:27 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:27 --> Total execution time: 0.1038
DEBUG - 2014-08-24 22:59:29 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:29 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:29 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:29 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:29 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:29 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:29 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:29 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:29 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:29 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:29 --> Total execution time: 0.1007
DEBUG - 2014-08-24 22:59:31 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:31 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:31 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:31 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:31 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:31 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:31 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:31 --> Report MX_Controller Initialized
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:31 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:31 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:31 --> Total execution time: 0.1047
DEBUG - 2014-08-24 22:59:32 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:32 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:32 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:59:32 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:32 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:32 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:32 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:32 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:32 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:32 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:32 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:32 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:32 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:32 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:32 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:32 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:32 --> Total execution time: 0.0939
DEBUG - 2014-08-24 22:59:41 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:41 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:41 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:59:41 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:41 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:41 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:41 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:41 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:41 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:41 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:41 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:41 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:41 --> Total execution time: 0.1203
DEBUG - 2014-08-24 22:59:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:44 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:44 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:44 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:44 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:44 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:44 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:44 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:44 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:44 --> Total execution time: 0.1181
DEBUG - 2014-08-24 22:59:46 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:46 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:46 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:46 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:46 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:46 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:46 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:59:46 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:59:46 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:46 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:46 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:46 --> Total execution time: 0.1804
DEBUG - 2014-08-24 22:59:47 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:47 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:47 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:47 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:47 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:47 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:47 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:59:47 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:59:47 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:47 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:48 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:48 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:48 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Item MX_Controller Initialized
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: form_helper
DEBUG - 2014-08-24 22:59:48 --> Form Validation Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 22:59:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 22:59:48 --> URI Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Router Class Initialized
DEBUG - 2014-08-24 22:59:48 --> No URI present. Default controller set.
DEBUG - 2014-08-24 22:59:48 --> Output Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Security Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Input Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 22:59:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Language Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Config Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Loader Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 22:59:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 22:59:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 22:59:48 --> Session Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 22:59:48 --> Session routines successfully run
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Controller Class Initialized
DEBUG - 2014-08-24 22:59:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 22:59:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 22:59:48 --> Model Class Initialized
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 22:59:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 22:59:48 --> Final output sent to browser
DEBUG - 2014-08-24 22:59:48 --> Total execution time: 0.1169
DEBUG - 2014-08-24 23:00:54 --> Config Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:00:54 --> URI Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Router Class Initialized
DEBUG - 2014-08-24 23:00:54 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:00:54 --> Output Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Security Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Input Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:00:54 --> Language Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Language Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Config Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Loader Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:00:54 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:00:54 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:00:54 --> Session Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:00:54 --> Session routines successfully run
DEBUG - 2014-08-24 23:00:54 --> Model Class Initialized
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:00:54 --> Model Class Initialized
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:00:54 --> Model Class Initialized
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:00:54 --> Model Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Model Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Controller Class Initialized
DEBUG - 2014-08-24 23:00:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:00:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:00:54 --> Model Class Initialized
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:00:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:00:54 --> Final output sent to browser
DEBUG - 2014-08-24 23:00:54 --> Total execution time: 0.1168
DEBUG - 2014-08-24 23:05:37 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:37 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:37 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:05:37 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:37 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:37 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:37 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:37 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:37 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:37 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:05:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:05:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:05:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:05:37 --> Final output sent to browser
DEBUG - 2014-08-24 23:05:37 --> Total execution time: 0.1162
DEBUG - 2014-08-24 23:05:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:40 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:40 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:40 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:40 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:40 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:40 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:05:40 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:40 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:40 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:40 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:40 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:40 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:40 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:40 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:05:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:05:41 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:05:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:05:41 --> Final output sent to browser
DEBUG - 2014-08-24 23:05:41 --> Total execution time: 0.0828
DEBUG - 2014-08-24 23:05:44 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:44 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:44 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:44 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:45 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:45 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:45 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:45 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:45 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:05:45 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:45 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:45 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:45 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:45 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:45 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:05:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:05:45 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:05:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:05:45 --> Final output sent to browser
DEBUG - 2014-08-24 23:05:45 --> Total execution time: 0.1101
DEBUG - 2014-08-24 23:05:47 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:05:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:05:47 --> URI Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Router Class Initialized
DEBUG - 2014-08-24 23:05:47 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:05:47 --> Output Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Security Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Input Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:05:47 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Language Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Config Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Loader Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:05:47 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:05:47 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:05:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:05:47 --> Session Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:05:47 --> Session routines successfully run
DEBUG - 2014-08-24 23:05:47 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:05:47 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:05:47 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:05:47 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Controller Class Initialized
DEBUG - 2014-08-24 23:05:47 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:05:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:05:47 --> Model Class Initialized
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:05:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:05:47 --> Final output sent to browser
DEBUG - 2014-08-24 23:05:47 --> Total execution time: 0.1013
DEBUG - 2014-08-24 23:26:37 --> Config Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:26:37 --> URI Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Router Class Initialized
DEBUG - 2014-08-24 23:26:37 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:26:37 --> Output Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Security Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Input Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:26:37 --> Language Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Language Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Config Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Loader Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:26:37 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:26:37 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:26:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:26:37 --> Session Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:26:37 --> Session routines successfully run
DEBUG - 2014-08-24 23:26:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:26:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:26:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:26:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Controller Class Initialized
DEBUG - 2014-08-24 23:26:37 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:26:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:26:37 --> Model Class Initialized
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:26:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:26:37 --> Final output sent to browser
DEBUG - 2014-08-24 23:26:37 --> Total execution time: 0.0950
DEBUG - 2014-08-24 23:39:38 --> Config Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:39:38 --> URI Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Router Class Initialized
DEBUG - 2014-08-24 23:39:38 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:39:38 --> Output Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Security Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Input Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:39:38 --> Language Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Language Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Config Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Loader Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:39:38 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:39:38 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:39:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:39:38 --> Session Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:39:38 --> Session routines successfully run
DEBUG - 2014-08-24 23:39:38 --> Model Class Initialized
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:39:38 --> Model Class Initialized
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:39:38 --> Model Class Initialized
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:39:38 --> Model Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Model Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Controller Class Initialized
DEBUG - 2014-08-24 23:39:38 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:39:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:39:38 --> Model Class Initialized
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:39:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:39:38 --> Final output sent to browser
DEBUG - 2014-08-24 23:39:38 --> Total execution time: 0.1201
DEBUG - 2014-08-24 23:50:33 --> Config Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:50:33 --> URI Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Router Class Initialized
DEBUG - 2014-08-24 23:50:33 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:50:33 --> Output Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Security Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Input Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:50:33 --> Language Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Language Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Config Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Loader Class Initialized
DEBUG - 2014-08-24 23:50:33 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:50:33 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:50:34 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:50:34 --> Session Class Initialized
DEBUG - 2014-08-24 23:50:34 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:50:34 --> Session routines successfully run
DEBUG - 2014-08-24 23:50:34 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:50:34 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:50:34 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:50:34 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:34 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:34 --> Controller Class Initialized
DEBUG - 2014-08-24 23:50:34 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:50:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:50:34 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:50:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:50:34 --> Final output sent to browser
DEBUG - 2014-08-24 23:50:34 --> Total execution time: 0.1095
DEBUG - 2014-08-24 23:50:49 --> Config Class Initialized
DEBUG - 2014-08-24 23:50:49 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:50:49 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:50:49 --> URI Class Initialized
DEBUG - 2014-08-24 23:50:49 --> Router Class Initialized
DEBUG - 2014-08-24 23:50:49 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:50:49 --> Output Class Initialized
DEBUG - 2014-08-24 23:50:49 --> Security Class Initialized
DEBUG - 2014-08-24 23:50:49 --> Input Class Initialized
DEBUG - 2014-08-24 23:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:50:49 --> Language Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Language Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Config Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Loader Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:50:50 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:50:50 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:50:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:50:50 --> Session Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:50:50 --> Session routines successfully run
DEBUG - 2014-08-24 23:50:50 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:50:50 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:50:50 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:50:50 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Controller Class Initialized
DEBUG - 2014-08-24 23:50:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:50:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:50:50 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:50:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:50:50 --> Final output sent to browser
DEBUG - 2014-08-24 23:50:50 --> Total execution time: 0.1039
DEBUG - 2014-08-24 23:50:53 --> Config Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:50:53 --> URI Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Router Class Initialized
DEBUG - 2014-08-24 23:50:53 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:50:53 --> Output Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Security Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Input Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:50:53 --> Language Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Language Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Config Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Loader Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:50:53 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:50:53 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:50:53 --> Session Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:50:53 --> Session routines successfully run
DEBUG - 2014-08-24 23:50:53 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:50:53 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:50:53 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:50:53 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Controller Class Initialized
DEBUG - 2014-08-24 23:50:53 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:50:53 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:50:53 --> Model Class Initialized
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:50:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:50:53 --> Final output sent to browser
DEBUG - 2014-08-24 23:50:53 --> Total execution time: 0.1064
DEBUG - 2014-08-24 23:51:11 --> Config Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:51:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:51:11 --> URI Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Router Class Initialized
DEBUG - 2014-08-24 23:51:11 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:51:11 --> Output Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Security Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Input Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:51:11 --> Language Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Language Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Config Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Loader Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:51:11 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:51:11 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:51:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:51:11 --> Session Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:51:11 --> Session routines successfully run
DEBUG - 2014-08-24 23:51:11 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:51:11 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:51:11 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:51:11 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Controller Class Initialized
DEBUG - 2014-08-24 23:51:11 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:51:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:51:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:51:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:51:12 --> Final output sent to browser
DEBUG - 2014-08-24 23:51:12 --> Total execution time: 0.1201
DEBUG - 2014-08-24 23:51:31 --> Config Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:51:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:51:31 --> URI Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Router Class Initialized
DEBUG - 2014-08-24 23:51:31 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:51:31 --> Output Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Security Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Input Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:51:31 --> Language Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Language Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Config Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Loader Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:51:31 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:51:31 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:51:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:51:31 --> Session Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:51:31 --> Session routines successfully run
DEBUG - 2014-08-24 23:51:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:51:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:51:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:51:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Controller Class Initialized
DEBUG - 2014-08-24 23:51:31 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:51:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:51:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:51:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:51:31 --> Final output sent to browser
DEBUG - 2014-08-24 23:51:31 --> Total execution time: 0.1145
DEBUG - 2014-08-24 23:52:28 --> Config Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:52:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:52:28 --> URI Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Router Class Initialized
DEBUG - 2014-08-24 23:52:28 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:52:28 --> Output Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Security Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Input Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:52:28 --> Language Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Language Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Config Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Loader Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:52:28 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:52:28 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:52:28 --> Session Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:52:28 --> Session routines successfully run
DEBUG - 2014-08-24 23:52:28 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:52:28 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:52:28 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:52:28 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Controller Class Initialized
DEBUG - 2014-08-24 23:52:28 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:52:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:52:28 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:52:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:52:28 --> Final output sent to browser
DEBUG - 2014-08-24 23:52:28 --> Total execution time: 0.1174
DEBUG - 2014-08-24 23:52:31 --> Config Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:52:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:52:31 --> URI Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Router Class Initialized
DEBUG - 2014-08-24 23:52:31 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:52:31 --> Output Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Security Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Input Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:52:31 --> Language Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Language Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Config Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Loader Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:52:31 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:52:31 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:52:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:52:31 --> Session Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:52:31 --> Session routines successfully run
DEBUG - 2014-08-24 23:52:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:52:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:52:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:52:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Controller Class Initialized
DEBUG - 2014-08-24 23:52:31 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:52:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:52:31 --> Model Class Initialized
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:52:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:52:31 --> Final output sent to browser
DEBUG - 2014-08-24 23:52:31 --> Total execution time: 0.1254
DEBUG - 2014-08-24 23:53:08 --> Config Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:53:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:53:08 --> URI Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Router Class Initialized
DEBUG - 2014-08-24 23:53:08 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:53:08 --> Output Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Security Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Input Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:53:08 --> Language Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Language Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Config Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Loader Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:53:08 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:53:08 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:53:08 --> Session Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:53:08 --> Session routines successfully run
DEBUG - 2014-08-24 23:53:08 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:53:08 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:53:08 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:53:08 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Controller Class Initialized
DEBUG - 2014-08-24 23:53:08 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:53:08 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:53:08 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:53:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:53:08 --> Final output sent to browser
DEBUG - 2014-08-24 23:53:08 --> Total execution time: 0.1139
DEBUG - 2014-08-24 23:53:15 --> Config Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:53:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:53:15 --> URI Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Router Class Initialized
DEBUG - 2014-08-24 23:53:15 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:53:15 --> Output Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Security Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Input Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:53:15 --> Language Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Language Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Config Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Loader Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:53:15 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:53:15 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:53:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:53:15 --> Session Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:53:15 --> Session routines successfully run
DEBUG - 2014-08-24 23:53:15 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:53:15 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:53:15 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:53:15 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Controller Class Initialized
DEBUG - 2014-08-24 23:53:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:53:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:53:15 --> Model Class Initialized
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:53:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:53:15 --> Final output sent to browser
DEBUG - 2014-08-24 23:53:15 --> Total execution time: 0.1032
DEBUG - 2014-08-24 23:54:48 --> Config Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:54:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:54:48 --> URI Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Router Class Initialized
DEBUG - 2014-08-24 23:54:48 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:54:48 --> Output Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Security Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Input Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:54:48 --> Language Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Language Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Config Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Loader Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:54:48 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:54:48 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:54:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:54:48 --> Session Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:54:48 --> Session routines successfully run
DEBUG - 2014-08-24 23:54:48 --> Model Class Initialized
DEBUG - 2014-08-24 23:54:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:54:48 --> Model Class Initialized
DEBUG - 2014-08-24 23:54:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:54:48 --> Model Class Initialized
DEBUG - 2014-08-24 23:54:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:54:48 --> Model Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Model Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Controller Class Initialized
DEBUG - 2014-08-24 23:54:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:55:11 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:55:11 --> URI Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Router Class Initialized
DEBUG - 2014-08-24 23:55:11 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:55:11 --> Output Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Security Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Input Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:55:11 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:11 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Loader Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:55:12 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:55:12 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:55:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:55:12 --> Session Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:55:12 --> Session routines successfully run
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Controller Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 23:55:12 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 23:55:12 --> Helper loaded: form_helper
DEBUG - 2014-08-24 23:55:12 --> Form Validation Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:55:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:55:12 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:55:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:55:12 --> Final output sent to browser
DEBUG - 2014-08-24 23:55:12 --> Total execution time: 0.2991
DEBUG - 2014-08-24 23:55:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:55:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:55:40 --> URI Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Router Class Initialized
DEBUG - 2014-08-24 23:55:40 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:55:40 --> Output Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Security Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Input Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:55:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Loader Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:55:40 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:55:40 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:55:40 --> Session Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:55:40 --> Session routines successfully run
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Controller Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 23:55:40 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 23:55:40 --> Helper loaded: form_helper
DEBUG - 2014-08-24 23:55:40 --> Form Validation Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:55:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:55:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:55:41 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:55:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:55:41 --> Final output sent to browser
DEBUG - 2014-08-24 23:55:41 --> Total execution time: 0.2143
DEBUG - 2014-08-24 23:55:57 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:55:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:55:57 --> URI Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Router Class Initialized
DEBUG - 2014-08-24 23:55:57 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:55:57 --> Output Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Security Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Input Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:55:57 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Loader Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:55:57 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:55:57 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:55:57 --> Session Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:55:57 --> Session routines successfully run
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Controller Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 23:55:57 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 23:55:57 --> Helper loaded: form_helper
DEBUG - 2014-08-24 23:55:57 --> Form Validation Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:55:57 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:55:57 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:55:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:55:57 --> Final output sent to browser
DEBUG - 2014-08-24 23:55:57 --> Total execution time: 0.2186
DEBUG - 2014-08-24 23:55:59 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:55:59 --> URI Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Router Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Output Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Security Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Input Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:55:59 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Loader Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:55:59 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:55:59 --> Session Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:55:59 --> Session routines successfully run
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Controller Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:55:59 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:55:59 --> URI Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Router Class Initialized
DEBUG - 2014-08-24 23:55:59 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:55:59 --> Output Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Security Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Input Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:55:59 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Language Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Config Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Loader Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:55:59 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:55:59 --> Session Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:55:59 --> Session routines successfully run
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Controller Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 23:55:59 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 23:55:59 --> Helper loaded: form_helper
DEBUG - 2014-08-24 23:55:59 --> Form Validation Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:55:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:55:59 --> Model Class Initialized
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:55:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:55:59 --> Final output sent to browser
DEBUG - 2014-08-24 23:55:59 --> Total execution time: 0.1472
DEBUG - 2014-08-24 23:58:33 --> Config Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:58:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:58:33 --> URI Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Router Class Initialized
DEBUG - 2014-08-24 23:58:33 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:58:33 --> Output Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Security Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Input Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:58:33 --> Language Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Language Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Config Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Loader Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:58:33 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:58:33 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:58:33 --> Session Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:58:33 --> Session routines successfully run
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Controller Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 23:58:33 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 23:58:33 --> Helper loaded: form_helper
DEBUG - 2014-08-24 23:58:33 --> Form Validation Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:58:33 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:58:33 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:58:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:58:33 --> Final output sent to browser
DEBUG - 2014-08-24 23:58:33 --> Total execution time: 0.2405
DEBUG - 2014-08-24 23:58:35 --> Config Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:58:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:58:35 --> URI Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Router Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Output Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Security Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Input Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:58:35 --> Language Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Language Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Config Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Loader Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:58:35 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:58:35 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:58:35 --> Session Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:58:35 --> Session routines successfully run
DEBUG - 2014-08-24 23:58:35 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:58:35 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:58:35 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:58:35 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Controller Class Initialized
DEBUG - 2014-08-24 23:58:35 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:58:36 --> Config Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Hooks Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Utf8 Class Initialized
DEBUG - 2014-08-24 23:58:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-24 23:58:36 --> URI Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Router Class Initialized
DEBUG - 2014-08-24 23:58:36 --> No URI present. Default controller set.
DEBUG - 2014-08-24 23:58:36 --> Output Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Security Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Input Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-24 23:58:36 --> Language Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Language Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Config Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Loader Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Helper loaded: url_helper
DEBUG - 2014-08-24 23:58:36 --> Helper loaded: common_helper
DEBUG - 2014-08-24 23:58:36 --> Database Driver Class Initialized
ERROR - 2014-08-24 23:58:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-24 23:58:36 --> Session Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Helper loaded: string_helper
DEBUG - 2014-08-24 23:58:36 --> Session routines successfully run
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Controller Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Site MX_Controller Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-24 23:58:36 --> Batch MX_Controller Initialized
DEBUG - 2014-08-24 23:58:36 --> Helper loaded: form_helper
DEBUG - 2014-08-24 23:58:36 --> Form Validation Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-24 23:58:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-24 23:58:36 --> Model Class Initialized
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-24 23:58:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-24 23:58:36 --> Final output sent to browser
DEBUG - 2014-08-24 23:58:36 --> Total execution time: 0.2216
