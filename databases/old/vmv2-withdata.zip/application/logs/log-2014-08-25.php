<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-25 00:06:50 --> Config Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:06:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:06:50 --> URI Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Router Class Initialized
DEBUG - 2014-08-25 00:06:50 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:06:50 --> Output Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Security Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Input Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:06:50 --> Language Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Language Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Config Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Loader Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:06:50 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:06:50 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:06:50 --> Session Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:06:50 --> Session routines successfully run
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Controller Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:06:50 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:06:50 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:06:50 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:06:50 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:06:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:06:50 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:06:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:06:50 --> Final output sent to browser
DEBUG - 2014-08-25 00:06:50 --> Total execution time: 0.3129
DEBUG - 2014-08-25 00:06:52 --> Config Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:06:52 --> URI Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Router Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Output Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Security Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Input Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:06:52 --> Language Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Language Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Config Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Loader Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:06:52 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:06:52 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:06:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:06:52 --> Session Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:06:52 --> Session routines successfully run
DEBUG - 2014-08-25 00:06:52 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:06:52 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:06:52 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:06:52 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Controller Class Initialized
DEBUG - 2014-08-25 00:06:52 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:06:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:06:52 --> Model Class Initialized
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:06:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:06:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:06:52 --> Final output sent to browser
DEBUG - 2014-08-25 00:06:52 --> Total execution time: 0.0824
DEBUG - 2014-08-25 00:07:27 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:07:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:07:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:07:27 --> URI Class Initialized
DEBUG - 2014-08-25 00:07:27 --> Router Class Initialized
DEBUG - 2014-08-25 00:07:27 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:07:27 --> Output Class Initialized
DEBUG - 2014-08-25 00:07:27 --> Security Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Input Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:07:28 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Loader Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:07:28 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:07:28 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:07:28 --> Session Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:07:28 --> Session routines successfully run
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Controller Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:07:28 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:07:28 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:07:28 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:07:28 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:07:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:07:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:07:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:07:28 --> Final output sent to browser
DEBUG - 2014-08-25 00:07:28 --> Total execution time: 0.2988
DEBUG - 2014-08-25 00:07:30 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:07:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:07:30 --> URI Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Router Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Output Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Security Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Input Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:07:30 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Loader Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:07:30 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:07:30 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:07:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:07:30 --> Session Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:07:30 --> Session routines successfully run
DEBUG - 2014-08-25 00:07:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:07:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:07:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:07:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Controller Class Initialized
DEBUG - 2014-08-25 00:07:30 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:07:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:07:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:07:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:07:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:07:30 --> Final output sent to browser
DEBUG - 2014-08-25 00:07:30 --> Total execution time: 0.0861
DEBUG - 2014-08-25 00:07:56 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:07:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:07:56 --> URI Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Router Class Initialized
DEBUG - 2014-08-25 00:07:56 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:07:56 --> Output Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Security Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Input Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:07:56 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Loader Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:07:56 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:07:56 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:07:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:07:56 --> Session Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:07:56 --> Session routines successfully run
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Controller Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:07:56 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:07:56 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:07:56 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:07:56 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:07:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:07:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:07:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:07:56 --> Final output sent to browser
DEBUG - 2014-08-25 00:07:56 --> Total execution time: 0.2570
DEBUG - 2014-08-25 00:07:58 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:07:58 --> URI Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Router Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Output Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Security Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Input Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:07:58 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Language Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Config Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Loader Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:07:58 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:07:58 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:07:58 --> Session Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:07:58 --> Session routines successfully run
DEBUG - 2014-08-25 00:07:58 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:07:58 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:07:58 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:07:58 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Controller Class Initialized
DEBUG - 2014-08-25 00:07:58 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:07:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:07:58 --> Model Class Initialized
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:07:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:07:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:07:58 --> Final output sent to browser
DEBUG - 2014-08-25 00:07:58 --> Total execution time: 0.0821
DEBUG - 2014-08-25 00:08:21 --> Config Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:08:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:08:21 --> URI Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Router Class Initialized
DEBUG - 2014-08-25 00:08:21 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:08:21 --> Output Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Security Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Input Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:08:21 --> Language Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Language Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Config Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Loader Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:08:21 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:08:21 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:08:21 --> Session Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:08:21 --> Session routines successfully run
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Controller Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:08:21 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:08:21 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:08:21 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:08:21 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:08:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:08:21 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:08:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:08:21 --> Final output sent to browser
DEBUG - 2014-08-25 00:08:21 --> Total execution time: 0.2730
DEBUG - 2014-08-25 00:08:23 --> Config Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:08:23 --> URI Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Router Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Output Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Security Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Input Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:08:23 --> Language Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Language Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Config Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Loader Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:08:23 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:08:23 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:08:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:08:23 --> Session Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:08:23 --> Session routines successfully run
DEBUG - 2014-08-25 00:08:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:08:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:08:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:08:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Controller Class Initialized
DEBUG - 2014-08-25 00:08:23 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:08:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:08:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:08:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:08:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:08:23 --> Final output sent to browser
DEBUG - 2014-08-25 00:08:23 --> Total execution time: 0.0921
DEBUG - 2014-08-25 00:10:22 --> Config Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:10:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:10:22 --> URI Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Router Class Initialized
DEBUG - 2014-08-25 00:10:22 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:10:22 --> Output Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Security Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Input Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:10:22 --> Language Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Language Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Config Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Loader Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:10:22 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:10:22 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:10:22 --> Session Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:10:22 --> Session routines successfully run
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Controller Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:10:22 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:10:22 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:10:22 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:10:22 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:22 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:10:22 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Config Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:10:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:10:23 --> URI Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Router Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Output Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Security Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Input Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:10:23 --> Language Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Language Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Config Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Loader Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:10:23 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:10:23 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:10:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:10:23 --> Session Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:10:23 --> Session routines successfully run
DEBUG - 2014-08-25 00:10:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:10:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:10:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:10:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Controller Class Initialized
DEBUG - 2014-08-25 00:10:23 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:10:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:10:23 --> Model Class Initialized
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:10:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:10:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:10:23 --> Final output sent to browser
DEBUG - 2014-08-25 00:10:23 --> Total execution time: 0.0751
DEBUG - 2014-08-25 00:11:33 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:11:33 --> URI Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Router Class Initialized
DEBUG - 2014-08-25 00:11:33 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:11:33 --> Output Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Security Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Input Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:11:33 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Loader Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:11:33 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:11:33 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:11:33 --> Session Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:11:33 --> Session routines successfully run
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Controller Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:11:33 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:11:33 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:11:33 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:11:33 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:33 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:11:33 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:11:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:11:34 --> URI Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Router Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Output Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Security Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Input Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:11:34 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Loader Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:11:34 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:11:34 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:11:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:11:34 --> Session Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:11:34 --> Session routines successfully run
DEBUG - 2014-08-25 00:11:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:11:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:11:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:11:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Controller Class Initialized
DEBUG - 2014-08-25 00:11:34 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:11:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:11:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:11:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:11:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:11:34 --> Final output sent to browser
DEBUG - 2014-08-25 00:11:34 --> Total execution time: 0.0699
DEBUG - 2014-08-25 00:11:55 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:11:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:11:55 --> URI Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Router Class Initialized
DEBUG - 2014-08-25 00:11:55 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:11:55 --> Output Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Security Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Input Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:11:55 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Loader Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:11:55 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:11:55 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:11:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:11:55 --> Session Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:11:55 --> Session routines successfully run
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Controller Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:11:55 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:11:55 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:11:55 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:11:55 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:55 --> DB Transaction Failure
ERROR - 2014-08-25 00:11:55 --> Query error: Unknown column 'datetime' in 'order clause'
DEBUG - 2014-08-25 00:11:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-08-25 00:11:56 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:11:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:11:56 --> URI Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Router Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Output Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Security Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Input Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:11:56 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Language Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Config Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Loader Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:11:56 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:11:56 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:11:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:11:56 --> Session Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:11:56 --> Session routines successfully run
DEBUG - 2014-08-25 00:11:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:11:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:11:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:11:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Controller Class Initialized
DEBUG - 2014-08-25 00:11:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:11:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:11:56 --> Model Class Initialized
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:11:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:11:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:11:56 --> Final output sent to browser
DEBUG - 2014-08-25 00:11:56 --> Total execution time: 0.0812
DEBUG - 2014-08-25 00:12:28 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:12:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:12:28 --> URI Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Router Class Initialized
DEBUG - 2014-08-25 00:12:28 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:12:28 --> Output Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Security Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Input Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:12:28 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Loader Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:12:28 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:12:28 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:12:28 --> Session Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:12:28 --> Session routines successfully run
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Controller Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:12:28 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:12:28 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:12:28 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:12:28 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:12:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:12:28 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:12:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:12:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:12:28 --> Final output sent to browser
DEBUG - 2014-08-25 00:12:28 --> Total execution time: 0.3476
DEBUG - 2014-08-25 00:12:30 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:12:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:12:30 --> URI Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Router Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Output Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Security Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Input Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:12:30 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Loader Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:12:30 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:12:30 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:12:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:12:30 --> Session Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:12:30 --> Session routines successfully run
DEBUG - 2014-08-25 00:12:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:12:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:12:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:12:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Controller Class Initialized
DEBUG - 2014-08-25 00:12:30 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:12:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:12:30 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:12:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:12:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:12:30 --> Final output sent to browser
DEBUG - 2014-08-25 00:12:30 --> Total execution time: 0.1295
DEBUG - 2014-08-25 00:12:32 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:12:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:12:32 --> URI Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Router Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Output Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Security Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Input Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:12:32 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Loader Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:12:32 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:12:32 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:12:32 --> Session Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:12:32 --> Session routines successfully run
DEBUG - 2014-08-25 00:12:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:12:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:12:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:12:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Controller Class Initialized
DEBUG - 2014-08-25 00:12:32 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:12:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:12:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:12:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:12:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:12:32 --> Final output sent to browser
DEBUG - 2014-08-25 00:12:32 --> Total execution time: 0.0889
DEBUG - 2014-08-25 00:12:53 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:12:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:12:53 --> URI Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Router Class Initialized
DEBUG - 2014-08-25 00:12:53 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:12:53 --> Output Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Security Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Input Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:12:53 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Loader Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:12:53 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:12:53 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:12:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:12:53 --> Session Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:12:53 --> Session routines successfully run
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Controller Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:12:53 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:12:53 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:12:53 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:12:53 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:12:53 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:12:53 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:12:53 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:12:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:12:53 --> Final output sent to browser
DEBUG - 2014-08-25 00:12:53 --> Total execution time: 0.3348
DEBUG - 2014-08-25 00:12:55 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:12:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:12:55 --> URI Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Router Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Output Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Security Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Input Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:12:55 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Language Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Config Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Loader Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:12:55 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:12:55 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:12:55 --> Session Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:12:55 --> Session routines successfully run
DEBUG - 2014-08-25 00:12:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:12:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:12:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:12:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Controller Class Initialized
DEBUG - 2014-08-25 00:12:55 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:12:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:12:55 --> Model Class Initialized
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:12:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:12:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:12:55 --> Final output sent to browser
DEBUG - 2014-08-25 00:12:55 --> Total execution time: 0.0907
DEBUG - 2014-08-25 00:13:15 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:13:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:13:15 --> URI Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Router Class Initialized
DEBUG - 2014-08-25 00:13:15 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:13:15 --> Output Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Security Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Input Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:13:15 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Loader Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:13:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:13:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:13:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:13:15 --> Session Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:13:15 --> Session routines successfully run
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Controller Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:13:15 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:13:15 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:13:15 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:13:15 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:15 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:13:15 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:16 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:13:16 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:13:16 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:13:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:13:16 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:13:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:13:16 --> Final output sent to browser
DEBUG - 2014-08-25 00:13:16 --> Total execution time: 0.3238
DEBUG - 2014-08-25 00:13:18 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:13:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:13:18 --> URI Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Router Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Output Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Security Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Input Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:13:18 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Loader Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:13:18 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:13:18 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:13:18 --> Session Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:13:18 --> Session routines successfully run
DEBUG - 2014-08-25 00:13:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:13:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:13:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:13:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Controller Class Initialized
DEBUG - 2014-08-25 00:13:18 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:13:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:13:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:13:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:13:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:13:18 --> Final output sent to browser
DEBUG - 2014-08-25 00:13:18 --> Total execution time: 0.0943
DEBUG - 2014-08-25 00:13:42 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:13:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:13:42 --> URI Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Router Class Initialized
DEBUG - 2014-08-25 00:13:42 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:13:42 --> Output Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Security Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Input Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:13:42 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Loader Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:13:42 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:13:42 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:13:42 --> Session Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:13:42 --> Session routines successfully run
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Controller Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:13:42 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:13:42 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:13:42 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:13:42 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:13:42 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:13:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:13:42 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:13:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:13:42 --> Final output sent to browser
DEBUG - 2014-08-25 00:13:42 --> Total execution time: 0.3693
DEBUG - 2014-08-25 00:13:44 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:13:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:13:44 --> URI Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Router Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Output Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Security Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Input Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:13:44 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Language Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Config Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Loader Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:13:44 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:13:44 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:13:44 --> Session Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:13:44 --> Session routines successfully run
DEBUG - 2014-08-25 00:13:44 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:13:44 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:13:44 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:13:44 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Controller Class Initialized
DEBUG - 2014-08-25 00:13:44 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:13:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:13:44 --> Model Class Initialized
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:13:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:13:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:13:44 --> Final output sent to browser
DEBUG - 2014-08-25 00:13:44 --> Total execution time: 0.0916
DEBUG - 2014-08-25 00:47:54 --> Config Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:47:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:47:54 --> URI Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Router Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Output Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Security Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Input Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:47:54 --> Language Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Language Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Config Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Loader Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:47:54 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:47:54 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:47:54 --> Session Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:47:54 --> Session routines successfully run
DEBUG - 2014-08-25 00:47:54 --> Model Class Initialized
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:47:54 --> Model Class Initialized
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:47:54 --> Model Class Initialized
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:47:54 --> Model Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Model Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Controller Class Initialized
DEBUG - 2014-08-25 00:47:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:47:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:47:54 --> Model Class Initialized
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:47:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:47:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:47:54 --> Final output sent to browser
DEBUG - 2014-08-25 00:47:54 --> Total execution time: 0.0820
DEBUG - 2014-08-25 00:48:27 --> Config Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:48:27 --> URI Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Router Class Initialized
DEBUG - 2014-08-25 00:48:27 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:48:27 --> Output Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Security Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Input Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:48:27 --> Language Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Language Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Config Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Loader Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:48:27 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:48:27 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:48:27 --> Session Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:48:27 --> Session routines successfully run
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Controller Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:48:27 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:48:27 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:48:27 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:48:27 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:48:27 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:48:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:48:27 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:48:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:48:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:48:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:48:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:48:28 --> Final output sent to browser
DEBUG - 2014-08-25 00:48:28 --> Total execution time: 0.3708
DEBUG - 2014-08-25 00:48:51 --> Config Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:48:51 --> URI Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Router Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Output Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Security Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Input Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:48:51 --> Language Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Language Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Config Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Loader Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:48:51 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:48:51 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:48:51 --> Session Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:48:51 --> Session routines successfully run
DEBUG - 2014-08-25 00:48:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:48:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:48:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:48:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Controller Class Initialized
DEBUG - 2014-08-25 00:48:51 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:48:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:48:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:48:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:48:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:48:51 --> Final output sent to browser
DEBUG - 2014-08-25 00:48:51 --> Total execution time: 0.1103
DEBUG - 2014-08-25 00:49:08 --> Config Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:49:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:49:08 --> URI Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Router Class Initialized
DEBUG - 2014-08-25 00:49:08 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:49:08 --> Output Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Security Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Input Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:49:08 --> Language Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Language Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Config Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Loader Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:49:08 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:49:08 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:49:08 --> Session Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:49:08 --> Session routines successfully run
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Controller Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:49:08 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:49:08 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:49:08 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:49:08 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:08 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:49:09 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:49:09 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:49:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:49:09 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:49:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:49:09 --> Final output sent to browser
DEBUG - 2014-08-25 00:49:09 --> Total execution time: 0.3543
DEBUG - 2014-08-25 00:49:32 --> Config Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:49:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:49:32 --> URI Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Router Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Output Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Security Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Input Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:49:32 --> Language Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Language Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Config Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Loader Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:49:32 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:49:32 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:49:32 --> Session Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:49:32 --> Session routines successfully run
DEBUG - 2014-08-25 00:49:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:49:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:49:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:49:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Controller Class Initialized
DEBUG - 2014-08-25 00:49:32 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:49:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:49:32 --> Model Class Initialized
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:49:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:49:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:49:32 --> Final output sent to browser
DEBUG - 2014-08-25 00:49:32 --> Total execution time: 0.1893
DEBUG - 2014-08-25 00:50:34 --> Config Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:50:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:50:34 --> URI Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Router Class Initialized
DEBUG - 2014-08-25 00:50:34 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:50:34 --> Output Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Security Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Input Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:50:34 --> Language Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Language Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Config Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Loader Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:50:34 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:50:34 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:50:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:50:34 --> Session Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:50:34 --> Session routines successfully run
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Controller Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:50:34 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:50:34 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:50:34 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:50:34 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:34 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:50:35 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:50:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:50:35 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:50:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:50:35 --> Final output sent to browser
DEBUG - 2014-08-25 00:50:35 --> Total execution time: 0.3686
DEBUG - 2014-08-25 00:50:37 --> Config Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:50:37 --> URI Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Router Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Output Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Security Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Input Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:50:37 --> Language Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Language Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Config Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Loader Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:50:37 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:50:37 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:50:37 --> Session Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:50:37 --> Session routines successfully run
DEBUG - 2014-08-25 00:50:37 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:50:37 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:50:37 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:50:37 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Controller Class Initialized
DEBUG - 2014-08-25 00:50:37 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:50:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:50:37 --> Model Class Initialized
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:50:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:50:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:50:37 --> Final output sent to browser
DEBUG - 2014-08-25 00:50:37 --> Total execution time: 0.1384
DEBUG - 2014-08-25 00:52:25 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:25 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:52:25 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:52:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:52:25 --> URI Class Initialized
DEBUG - 2014-08-25 00:52:25 --> Router Class Initialized
DEBUG - 2014-08-25 00:52:26 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:52:26 --> Output Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Security Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Input Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:52:26 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Loader Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:52:26 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:52:26 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:52:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:52:26 --> Session Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:52:26 --> Session routines successfully run
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Controller Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:52:26 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:52:26 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:52:26 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:52:26 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:52:26 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:52:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:52:26 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:52:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:52:26 --> Final output sent to browser
DEBUG - 2014-08-25 00:52:26 --> Total execution time: 0.3464
DEBUG - 2014-08-25 00:52:28 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:52:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:52:28 --> URI Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Router Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Output Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Security Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Input Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:52:28 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Loader Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:52:28 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:52:28 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:52:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:52:28 --> Session Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:52:28 --> Session routines successfully run
DEBUG - 2014-08-25 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Controller Class Initialized
DEBUG - 2014-08-25 00:52:28 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:52:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:52:28 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:52:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:52:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:52:28 --> Final output sent to browser
DEBUG - 2014-08-25 00:52:28 --> Total execution time: 0.0793
DEBUG - 2014-08-25 00:52:48 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:52:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:52:48 --> URI Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Router Class Initialized
DEBUG - 2014-08-25 00:52:48 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:52:48 --> Output Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Security Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Input Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:52:48 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Loader Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:52:48 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:52:48 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:52:48 --> Session Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:52:48 --> Session routines successfully run
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Controller Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:52:48 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:52:48 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:52:48 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:52:48 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:48 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:52:49 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:52:49 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:52:49 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:49 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:52:49 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:52:49 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:52:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:52:49 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:52:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:52:49 --> Final output sent to browser
DEBUG - 2014-08-25 00:52:49 --> Total execution time: 0.3328
DEBUG - 2014-08-25 00:52:51 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:52:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:52:51 --> URI Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Router Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Output Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Security Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Input Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:52:51 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Language Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Config Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Loader Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:52:51 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:52:51 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:52:51 --> Session Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:52:51 --> Session routines successfully run
DEBUG - 2014-08-25 00:52:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:52:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:52:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:52:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Controller Class Initialized
DEBUG - 2014-08-25 00:52:51 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:52:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:52:51 --> Model Class Initialized
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:52:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:52:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:52:51 --> Final output sent to browser
DEBUG - 2014-08-25 00:52:51 --> Total execution time: 0.1608
DEBUG - 2014-08-25 00:55:06 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:55:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:55:06 --> URI Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Router Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Output Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Security Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Input Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:55:06 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Loader Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:55:06 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:55:06 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:55:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:55:06 --> Session Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:55:06 --> Session routines successfully run
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Controller Class Initialized
DEBUG - 2014-08-25 00:55:06 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:55:06 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:55:06 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:55:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:55:06 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:55:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:55:06 --> Final output sent to browser
DEBUG - 2014-08-25 00:55:06 --> Total execution time: 0.1300
DEBUG - 2014-08-25 00:55:10 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:55:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:55:10 --> URI Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Router Class Initialized
DEBUG - 2014-08-25 00:55:10 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:55:10 --> Output Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Security Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Input Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:55:10 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Loader Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:55:10 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:55:10 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:55:10 --> Session Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:55:10 --> Session routines successfully run
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Controller Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:55:10 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:55:10 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:55:10 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:55:10 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:55:10 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:55:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:55:10 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:55:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:55:10 --> Final output sent to browser
DEBUG - 2014-08-25 00:55:10 --> Total execution time: 0.3160
DEBUG - 2014-08-25 00:55:12 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:55:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:55:12 --> URI Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Router Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Output Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Security Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Input Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:55:12 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Loader Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:55:12 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:55:12 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:55:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:55:12 --> Session Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:55:12 --> Session routines successfully run
DEBUG - 2014-08-25 00:55:12 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:55:12 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:55:12 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:55:12 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Controller Class Initialized
DEBUG - 2014-08-25 00:55:12 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:55:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:55:12 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:55:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:55:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:55:12 --> Final output sent to browser
DEBUG - 2014-08-25 00:55:12 --> Total execution time: 0.0702
DEBUG - 2014-08-25 00:55:13 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:55:13 --> URI Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Router Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Output Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Security Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Input Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:55:13 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Loader Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:55:13 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:55:13 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:55:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:55:13 --> Session Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:55:13 --> Session routines successfully run
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Controller Class Initialized
DEBUG - 2014-08-25 00:55:13 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:55:13 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:55:13 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:55:13 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:55:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:55:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:55:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:55:14 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:55:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:55:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:55:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:55:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:55:14 --> Final output sent to browser
DEBUG - 2014-08-25 00:55:14 --> Total execution time: 0.1305
DEBUG - 2014-08-25 00:55:18 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:55:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:55:18 --> URI Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Router Class Initialized
DEBUG - 2014-08-25 00:55:18 --> No URI present. Default controller set.
DEBUG - 2014-08-25 00:55:18 --> Output Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Security Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Input Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:55:18 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Loader Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:55:18 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:55:18 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:55:18 --> Session Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:55:18 --> Session routines successfully run
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Controller Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 00:55:18 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 00:55:18 --> Helper loaded: form_helper
DEBUG - 2014-08-25 00:55:18 --> Form Validation Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 00:55:18 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 00:55:18 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:55:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:55:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:55:18 --> Final output sent to browser
DEBUG - 2014-08-25 00:55:18 --> Total execution time: 0.3272
DEBUG - 2014-08-25 00:55:20 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Hooks Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Utf8 Class Initialized
DEBUG - 2014-08-25 00:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 00:55:20 --> URI Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Router Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Output Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Security Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Input Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 00:55:20 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Language Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Config Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Loader Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Helper loaded: url_helper
DEBUG - 2014-08-25 00:55:20 --> Helper loaded: common_helper
DEBUG - 2014-08-25 00:55:20 --> Database Driver Class Initialized
ERROR - 2014-08-25 00:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 00:55:20 --> Session Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Helper loaded: string_helper
DEBUG - 2014-08-25 00:55:20 --> Session routines successfully run
DEBUG - 2014-08-25 00:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 00:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 00:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 00:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Controller Class Initialized
DEBUG - 2014-08-25 00:55:20 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 00:55:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 00:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 00:55:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 00:55:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 00:55:20 --> Final output sent to browser
DEBUG - 2014-08-25 00:55:20 --> Total execution time: 0.0821
DEBUG - 2014-08-25 02:41:53 --> Config Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:41:53 --> URI Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Router Class Initialized
DEBUG - 2014-08-25 02:41:53 --> No URI present. Default controller set.
DEBUG - 2014-08-25 02:41:53 --> Output Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Security Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Input Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:41:53 --> Language Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Language Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Config Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Loader Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:41:53 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:41:53 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:41:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:41:53 --> Session Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:41:53 --> Session routines successfully run
DEBUG - 2014-08-25 02:41:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:41:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:41:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:41:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Controller Class Initialized
DEBUG - 2014-08-25 02:41:53 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:41:53 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 02:41:53 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 02:41:54 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:41:54 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:41:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 02:41:54 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 02:41:54 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:41:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:41:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:41:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:41:54 --> Final output sent to browser
DEBUG - 2014-08-25 02:41:54 --> Total execution time: 0.3491
DEBUG - 2014-08-25 02:41:56 --> Config Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:41:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:41:56 --> URI Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Router Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Output Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Security Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Input Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:41:56 --> Language Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Language Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Config Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Loader Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:41:56 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:41:56 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:41:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:41:56 --> Session Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:41:56 --> Session routines successfully run
DEBUG - 2014-08-25 02:41:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:41:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:41:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:41:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Controller Class Initialized
DEBUG - 2014-08-25 02:41:56 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:41:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:41:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:41:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:41:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:41:56 --> Final output sent to browser
DEBUG - 2014-08-25 02:41:56 --> Total execution time: 0.0837
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.0757
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.1125
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.0717
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.1571
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.0935
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.0812
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.2642
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Input Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.0995
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:42:15 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:42:15 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:42:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:42:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:42:15 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:42:15 --> Final output sent to browser
DEBUG - 2014-08-25 02:42:15 --> Total execution time: 0.0993
DEBUG - 2014-08-25 02:43:00 --> Config Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:43:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:43:00 --> URI Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Router Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Output Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Security Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Input Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:43:00 --> Language Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Language Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Config Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Loader Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:43:00 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:43:00 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:43:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:43:00 --> Session Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:43:00 --> Session routines successfully run
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Controller Class Initialized
DEBUG - 2014-08-25 02:43:00 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:43:00 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:43:00 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:43:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:43:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:43:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:43:00 --> Final output sent to browser
DEBUG - 2014-08-25 02:43:00 --> Total execution time: 0.1456
DEBUG - 2014-08-25 02:44:21 --> Config Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:44:21 --> URI Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Router Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Output Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Security Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Input Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:44:21 --> Language Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Language Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Config Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Loader Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:44:21 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:44:21 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:44:21 --> Session Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:44:21 --> Session routines successfully run
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Controller Class Initialized
DEBUG - 2014-08-25 02:44:21 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:44:21 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:44:21 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:44:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:21 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:44:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Config Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:44:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:44:46 --> URI Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Router Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Output Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Security Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Input Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:44:46 --> Language Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Language Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Config Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Loader Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:44:46 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:44:46 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:44:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:44:46 --> Session Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:44:46 --> Session routines successfully run
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Controller Class Initialized
DEBUG - 2014-08-25 02:44:46 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:44:46 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:44:46 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:44:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:44:46 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:44:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:15 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:15 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:15 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:15 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:15 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:20 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:20 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:20 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:20 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:20 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:20 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:20 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:20 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:20 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:20 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:23 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:23 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:23 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:23 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:23 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:23 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:23 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:23 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:23 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:23 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:23 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:26 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:26 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:26 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:26 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:26 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:26 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:26 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:26 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:26 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:35 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:35 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:35 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:35 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:35 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:35 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:35 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:35 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:35 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:35 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:38 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:38 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:38 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:38 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:38 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:38 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:38 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:38 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:38 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:38 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:38 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:54 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:54 --> No URI present. Default controller set.
DEBUG - 2014-08-25 02:45:54 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:54 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:54 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:54 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:54 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:54 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 02:45:54 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 02:45:54 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:54 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 02:45:54 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 02:45:54 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:45:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:45:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:45:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:45:54 --> Final output sent to browser
DEBUG - 2014-08-25 02:45:54 --> Total execution time: 0.3809
DEBUG - 2014-08-25 02:45:58 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:45:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:45:58 --> URI Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Router Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Output Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Security Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Input Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:45:58 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Language Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Config Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Loader Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:45:58 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:45:58 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:45:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:45:58 --> Session Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:45:58 --> Session routines successfully run
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Controller Class Initialized
DEBUG - 2014-08-25 02:45:58 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:45:58 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:45:58 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:45:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:45:58 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:45:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:46:02 --> URI Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Router Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Output Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Security Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Input Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:46:02 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Loader Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:46:02 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:46:02 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:46:02 --> Session Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:46:02 --> Session routines successfully run
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Controller Class Initialized
DEBUG - 2014-08-25 02:46:02 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:46:02 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:46:02 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:46:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:02 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:46:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:46:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:46:27 --> URI Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Router Class Initialized
DEBUG - 2014-08-25 02:46:27 --> No URI present. Default controller set.
DEBUG - 2014-08-25 02:46:27 --> Output Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Security Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Input Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:46:27 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Loader Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:46:27 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:46:27 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:46:27 --> Session Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:46:27 --> Session routines successfully run
DEBUG - 2014-08-25 02:46:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:46:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:46:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:46:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Controller Class Initialized
DEBUG - 2014-08-25 02:46:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:46:27 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 02:46:27 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 02:46:28 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:46:28 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:46:28 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/controllers/../modules/order/controllers/order.php
DEBUG - 2014-08-25 02:46:28 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/controllers/../modules/payment/controllers/payment.php
DEBUG - 2014-08-25 02:46:28 --> Payment MX_Controller Initialized
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:46:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:46:28 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:46:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:46:28 --> Final output sent to browser
DEBUG - 2014-08-25 02:46:28 --> Total execution time: 0.3497
DEBUG - 2014-08-25 02:46:30 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:46:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:46:30 --> URI Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Router Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Output Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Security Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Input Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:46:30 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Loader Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:46:30 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:46:30 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:46:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:46:30 --> Session Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:46:30 --> Session routines successfully run
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Controller Class Initialized
DEBUG - 2014-08-25 02:46:30 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:46:30 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:46:30 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:46:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:30 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:46:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:46:33 --> URI Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Router Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Output Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Security Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Input Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:46:33 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Language Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Config Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Loader Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:46:33 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:46:33 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:46:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:46:33 --> Session Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:46:33 --> Session routines successfully run
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Controller Class Initialized
DEBUG - 2014-08-25 02:46:33 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:46:33 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:46:33 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:46:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:46:33 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:46:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:47:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:47:04 --> URI Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Router Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Output Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Security Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Input Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:47:04 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Loader Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:47:04 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:47:04 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:47:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:47:04 --> Session Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:47:04 --> Session routines successfully run
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Controller Class Initialized
DEBUG - 2014-08-25 02:47:04 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:47:04 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:47:04 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:47:04 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:47:04 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:47:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:47:04 --> Final output sent to browser
DEBUG - 2014-08-25 02:47:04 --> Total execution time: 0.1465
DEBUG - 2014-08-25 02:47:26 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:47:26 --> URI Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Router Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Output Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Security Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Input Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:47:26 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Loader Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:47:26 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:47:26 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:47:26 --> Session Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:47:26 --> Session routines successfully run
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Controller Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:47:26 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:47:26 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:47:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:47:26 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:47:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:47:26 --> Final output sent to browser
DEBUG - 2014-08-25 02:47:26 --> Total execution time: 0.1877
DEBUG - 2014-08-25 02:47:45 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:47:45 --> URI Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Router Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Output Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Security Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Input Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:47:45 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Loader Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:47:45 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:47:45 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:47:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:47:45 --> Session Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:47:45 --> Session routines successfully run
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Controller Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:47:45 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:47:45 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:47:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:47:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:47:45 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:47:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:47:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:47:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:47:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:47:46 --> Final output sent to browser
DEBUG - 2014-08-25 02:47:46 --> Total execution time: 0.2138
DEBUG - 2014-08-25 02:47:52 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:47:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:47:52 --> URI Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Router Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Output Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Security Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Input Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:47:52 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Loader Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:47:52 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:47:52 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:47:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:47:52 --> Session Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:47:52 --> Session routines successfully run
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Controller Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:47:52 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:47:52 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:47:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:47:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:47:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:47:52 --> Final output sent to browser
DEBUG - 2014-08-25 02:47:52 --> Total execution time: 0.1960
DEBUG - 2014-08-25 02:47:55 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:47:55 --> URI Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Router Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Output Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Security Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Input Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:47:55 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Language Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Config Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Loader Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:47:55 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:47:55 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:47:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:47:55 --> Session Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:47:55 --> Session routines successfully run
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Controller Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:47:55 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:47:55 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:47:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:47:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:47:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:47:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:47:55 --> Final output sent to browser
DEBUG - 2014-08-25 02:47:55 --> Total execution time: 0.2136
DEBUG - 2014-08-25 02:49:43 --> Config Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:49:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:49:43 --> URI Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Router Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Output Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Security Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Input Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:49:43 --> Language Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Language Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Config Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Loader Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:49:43 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:49:43 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:49:43 --> Session Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:49:43 --> Session routines successfully run
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Controller Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Order MX_Controller Initialized
DEBUG - 2014-08-25 02:49:43 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:49:43 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/order/models/order_model.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/order/views/index.php
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:49:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:49:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/views/default/includes/notification.php
ERROR - 2014-08-25 02:49:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:49:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:49:43 --> Final output sent to browser
DEBUG - 2014-08-25 02:49:43 --> Total execution time: 0.2163
DEBUG - 2014-08-25 02:49:46 --> Config Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:49:46 --> URI Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Router Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Output Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Security Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Input Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:49:46 --> Language Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Language Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Config Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Loader Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:49:46 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:49:46 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:49:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:49:46 --> Session Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:49:46 --> Session routines successfully run
DEBUG - 2014-08-25 02:49:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:49:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:49:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:49:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Controller Class Initialized
DEBUG - 2014-08-25 02:49:46 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:49:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:49:46 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:49:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:49:46 --> Final output sent to browser
DEBUG - 2014-08-25 02:49:46 --> Total execution time: 0.1027
DEBUG - 2014-08-25 02:49:50 --> Config Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:49:50 --> URI Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Router Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Output Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Security Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Input Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:49:50 --> Language Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Language Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Config Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Loader Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:49:50 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:49:50 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:49:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:49:50 --> Session Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:49:50 --> Session routines successfully run
DEBUG - 2014-08-25 02:49:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:49:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:49:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:49:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Controller Class Initialized
DEBUG - 2014-08-25 02:49:50 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:49:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:49:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:49:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:49:50 --> Final output sent to browser
DEBUG - 2014-08-25 02:49:50 --> Total execution time: 0.1160
DEBUG - 2014-08-25 02:52:16 --> Config Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:52:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:52:16 --> URI Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Router Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Output Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Security Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Input Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:52:16 --> Language Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Language Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Config Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Loader Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:52:16 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:52:16 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:52:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:52:16 --> Session Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:52:16 --> Session routines successfully run
DEBUG - 2014-08-25 02:52:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:52:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:52:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:52:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Controller Class Initialized
DEBUG - 2014-08-25 02:52:16 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:52:16 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:52:16 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:52:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:52:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Config Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:52:40 --> URI Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Router Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Output Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Security Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Input Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:52:40 --> Language Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Language Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Config Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Loader Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:52:40 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:52:40 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:52:40 --> Session Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:52:40 --> Session routines successfully run
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Controller Class Initialized
DEBUG - 2014-08-25 02:52:40 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:52:40 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:52:40 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
ERROR - 2014-08-25 02:52:40 --> Module controller failed to run: order/dashboard
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:52:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:52:40 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:52:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:52:40 --> Final output sent to browser
DEBUG - 2014-08-25 02:52:40 --> Total execution time: 0.1163
DEBUG - 2014-08-25 02:52:42 --> Config Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:52:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:52:42 --> URI Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Router Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Output Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Security Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Input Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:52:42 --> Language Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Language Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Config Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Loader Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:52:42 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:52:42 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:52:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:52:42 --> Session Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:52:42 --> Session routines successfully run
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Controller Class Initialized
DEBUG - 2014-08-25 02:52:42 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:52:42 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:52:42 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:52:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:52:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:52:42 --> Model Class Initialized
ERROR - 2014-08-25 02:52:42 --> Severity: Notice  --> Undefined property: CI::$order_model C:\xampp\htdocs\vmv2\application\third_party\MX\Controller.php 58
DEBUG - 2014-08-25 02:53:12 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:12 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:12 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:12 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:12 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:12 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:12 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:12 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:12 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:12 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:12 --> Total execution time: 0.2062
DEBUG - 2014-08-25 02:53:16 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:16 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:16 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:16 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:16 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:16 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:16 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:16 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:16 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:16 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:16 --> Total execution time: 0.1947
DEBUG - 2014-08-25 02:53:18 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:18 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:18 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:18 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:18 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:18 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:18 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:18 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:18 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:18 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:18 --> Total execution time: 0.2058
DEBUG - 2014-08-25 02:53:25 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:25 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:25 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:25 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:25 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:25 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:25 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:25 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:25 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:25 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:25 --> Total execution time: 0.1914
DEBUG - 2014-08-25 02:53:27 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:27 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:27 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:27 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:27 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:27 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:27 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:27 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:27 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:27 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:27 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:27 --> Total execution time: 0.2147
DEBUG - 2014-08-25 02:53:30 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:30 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:30 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:30 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:30 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:30 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:30 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:30 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:30 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:30 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:30 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:30 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:30 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:30 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:30 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:30 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:30 --> Total execution time: 0.2081
DEBUG - 2014-08-25 02:53:39 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:39 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:39 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:39 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:39 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:39 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:39 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:39 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:39 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:39 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/sales/views/order_return_form.php
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:39 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:39 --> Total execution time: 0.1318
DEBUG - 2014-08-25 02:53:47 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:47 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:47 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:47 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:47 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:47 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:47 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:53:47 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:53:47 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:47 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:47 --> Total execution time: 0.1985
DEBUG - 2014-08-25 02:53:49 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:53:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:53:49 --> URI Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Router Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Output Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Security Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Input Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:53:49 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Language Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Config Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Loader Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:53:49 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:53:49 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:53:49 --> Session Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:53:49 --> Session routines successfully run
DEBUG - 2014-08-25 02:53:49 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:53:49 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:53:49 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:53:49 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Controller Class Initialized
DEBUG - 2014-08-25 02:53:49 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/site/views/custom_404.php
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:53:49 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:53:49 --> Model Class Initialized
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:53:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:53:49 --> Final output sent to browser
DEBUG - 2014-08-25 02:53:49 --> Total execution time: 0.0966
DEBUG - 2014-08-25 02:54:50 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:54:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:54:50 --> URI Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Router Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Output Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Security Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Input Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:54:50 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Loader Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:54:50 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:54:50 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:54:50 --> Session Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:54:50 --> Session routines successfully run
DEBUG - 2014-08-25 02:54:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:54:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:54:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:54:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Controller Class Initialized
DEBUG - 2014-08-25 02:54:50 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:54:50 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:54:50 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:54:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:54:50 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:54:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:54:50 --> Final output sent to browser
DEBUG - 2014-08-25 02:54:50 --> Total execution time: 0.1147
DEBUG - 2014-08-25 02:54:52 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:54:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:54:52 --> URI Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Router Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Output Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Security Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Input Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:54:52 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Loader Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:54:52 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:54:52 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:54:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:54:52 --> Session Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:54:52 --> Session routines successfully run
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Controller Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:54:52 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:54:52 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:54:52 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:54:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:54:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:54:52 --> Final output sent to browser
DEBUG - 2014-08-25 02:54:52 --> Total execution time: 0.1876
DEBUG - 2014-08-25 02:54:56 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:54:56 --> URI Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Router Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Output Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Security Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Input Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:54:56 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Loader Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:54:56 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:54:56 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:54:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:54:56 --> Session Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:54:56 --> Session routines successfully run
DEBUG - 2014-08-25 02:54:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:54:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:54:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:54:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Controller Class Initialized
DEBUG - 2014-08-25 02:54:56 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:54:56 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:54:56 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/collection/views/manage_paid_items.php
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:54:56 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:54:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:54:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:54:56 --> Final output sent to browser
DEBUG - 2014-08-25 02:54:56 --> Total execution time: 0.1375
DEBUG - 2014-08-25 02:54:59 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:54:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:54:59 --> URI Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Router Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Output Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Security Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Input Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:54:59 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Language Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Config Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Loader Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:54:59 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:54:59 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:54:59 --> Session Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:54:59 --> Session routines successfully run
DEBUG - 2014-08-25 02:54:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:54:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:54:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:54:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Controller Class Initialized
DEBUG - 2014-08-25 02:54:59 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:54:59 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:54:59 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:54:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:54:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:54:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:54:59 --> Final output sent to browser
DEBUG - 2014-08-25 02:54:59 --> Total execution time: 0.1259
DEBUG - 2014-08-25 02:55:09 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:09 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:09 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:09 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:09 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:09 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:09 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:09 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:09 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:09 --> Total execution time: 0.1001
DEBUG - 2014-08-25 02:55:11 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:11 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:11 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:11 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:11 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:11 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:11 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:11 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:11 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:11 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:11 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:11 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:55:11 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:11 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:11 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:11 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:11 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:11 --> Total execution time: 0.1162
DEBUG - 2014-08-25 02:55:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:15 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:15 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:15 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:15 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:15 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:15 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:15 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:15 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:15 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:55:16 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:16 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:55:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:55:16 --> Model Class Initialized
ERROR - 2014-08-25 02:55:16 --> Module controller failed to run: order/dashboard
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:16 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:16 --> Total execution time: 0.1213
DEBUG - 2014-08-25 02:55:18 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:18 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:18 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:18 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:18 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:18 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:18 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:55:18 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:18 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:18 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:18 --> Total execution time: 0.1974
DEBUG - 2014-08-25 02:55:20 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:20 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:20 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:20 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:20 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:20 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:20 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:20 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:55:20 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:20 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:20 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:20 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:20 --> Total execution time: 0.1266
DEBUG - 2014-08-25 02:55:21 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:21 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:21 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:21 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:21 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:21 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:21 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:55:21 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:21 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:21 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:21 --> Total execution time: 0.1858
DEBUG - 2014-08-25 02:55:23 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:23 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:23 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:23 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:23 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:23 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:24 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:24 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:24 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:24 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:24 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:24 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:24 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:24 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:24 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:24 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:24 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:24 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:24 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:24 --> Total execution time: 0.0971
DEBUG - 2014-08-25 02:55:32 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:32 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:32 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:32 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:32 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:32 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:32 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Item MX_Controller Initialized
DEBUG - 2014-08-25 02:55:32 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:32 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:32 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:32 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:32 --> Total execution time: 0.1821
DEBUG - 2014-08-25 02:55:33 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:33 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:33 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:33 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:33 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:33 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Item MX_Controller Initialized
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:33 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:33 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:33 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:33 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:33 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:33 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Item MX_Controller Initialized
DEBUG - 2014-08-25 02:55:33 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:33 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:33 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:34 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:34 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:34 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:34 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:34 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:34 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Supplier MX_Controller Initialized
DEBUG - 2014-08-25 02:55:34 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:34 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:34 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:34 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:34 --> Total execution time: 0.1590
DEBUG - 2014-08-25 02:55:35 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:35 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:35 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:35 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:35 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:35 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:35 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 02:55:35 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:35 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:35 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:35 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:35 --> Total execution time: 0.1933
DEBUG - 2014-08-25 02:55:37 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:37 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:37 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:37 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:37 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:37 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:37 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:37 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:37 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:37 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:37 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:37 --> Employee MX_Controller Initialized
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:37 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:37 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:37 --> Total execution time: 0.0978
DEBUG - 2014-08-25 02:55:39 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:39 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:39 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:39 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:39 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:39 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:39 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:39 --> User MX_Controller Initialized
DEBUG - 2014-08-25 02:55:39 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:39 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:39 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:39 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:39 --> Total execution time: 0.1941
DEBUG - 2014-08-25 02:55:41 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:41 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:41 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:41 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:41 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:41 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:41 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:41 --> District MX_Controller Initialized
DEBUG - 2014-08-25 02:55:41 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:41 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:41 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:41 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:41 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:41 --> Total execution time: 0.1760
DEBUG - 2014-08-25 02:55:42 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:42 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:42 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:42 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:42 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:42 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:42 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:42 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-25 02:55:43 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:43 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:43 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:43 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:43 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:43 --> Total execution time: 0.2373
DEBUG - 2014-08-25 02:55:45 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:45 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:45 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:45 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:45 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:45 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:45 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:45 --> Client MX_Controller Initialized
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:45 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:45 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:45 --> Total execution time: 0.0965
DEBUG - 2014-08-25 02:55:47 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:47 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:47 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:47 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:47 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:47 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:47 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:47 --> User MX_Controller Initialized
DEBUG - 2014-08-25 02:55:47 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:47 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:47 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:47 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:47 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:47 --> Total execution time: 0.1955
DEBUG - 2014-08-25 02:55:51 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:51 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:51 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:51 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:51 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:51 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:51 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:51 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:51 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:51 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:51 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:51 --> Report MX_Controller Initialized
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:51 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:51 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:51 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:51 --> Total execution time: 0.0963
DEBUG - 2014-08-25 02:55:52 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:52 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:52 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:52 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:52 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:52 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:52 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:52 --> Report MX_Controller Initialized
DEBUG - 2014-08-25 02:55:53 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:53 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:53 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:53 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:53 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:53 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:53 --> Total execution time: 0.1822
DEBUG - 2014-08-25 02:55:54 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:54 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:54 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:54 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:54 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:54 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:54 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:54 --> Report MX_Controller Initialized
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/report/views/generate_report_form.php
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:54 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:54 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:54 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:54 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:54 --> Total execution time: 0.1044
DEBUG - 2014-08-25 02:55:55 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:55 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:55 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:55 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:55 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:55 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:55 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:55 --> Report MX_Controller Initialized
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/report/views/view_report.php
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:55 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:55 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:55 --> Total execution time: 0.1150
DEBUG - 2014-08-25 02:55:56 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:56 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:56 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:56 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:56 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:56 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:56 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:56 --> Setting MX_Controller Initialized
DEBUG - 2014-08-25 02:55:57 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:57 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:57 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:57 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:57 --> Total execution time: 0.1631
DEBUG - 2014-08-25 02:55:57 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:57 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:57 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:57 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:57 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:57 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:57 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:57 --> Setting MX_Controller Initialized
DEBUG - 2014-08-25 02:55:57 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:57 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:55:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:58 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:58 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:58 --> Total execution time: 0.1874
DEBUG - 2014-08-25 02:55:59 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:55:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:55:59 --> URI Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Router Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Output Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Security Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Input Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:55:59 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Language Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Config Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Loader Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:55:59 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:55:59 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:55:59 --> Session Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:55:59 --> Session routines successfully run
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Controller Class Initialized
DEBUG - 2014-08-25 02:55:59 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:55:59 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:55:59 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
ERROR - 2014-08-25 02:55:59 --> Module controller failed to run: order/dashboard
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:55:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:55:59 --> Model Class Initialized
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:55:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:55:59 --> Final output sent to browser
DEBUG - 2014-08-25 02:55:59 --> Total execution time: 0.1196
DEBUG - 2014-08-25 02:56:00 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:00 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:00 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:00 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:00 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:00 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:00 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:56:00 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:00 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:00 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:01 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:01 --> Total execution time: 0.2130
DEBUG - 2014-08-25 02:56:02 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:02 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:02 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:02 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:02 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:02 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:02 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:56:02 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:02 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:02 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:02 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:02 --> Total execution time: 0.1890
DEBUG - 2014-08-25 02:56:07 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:07 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:07 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:07 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:07 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:07 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:07 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:07 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:07 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:07 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:07 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:07 --> Client MX_Controller Initialized
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:07 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:07 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:07 --> Total execution time: 0.0950
DEBUG - 2014-08-25 02:56:09 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:09 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:09 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:09 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:09 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:09 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:09 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Setting MX_Controller Initialized
DEBUG - 2014-08-25 02:56:09 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:09 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:09 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:09 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:09 --> Total execution time: 0.1584
DEBUG - 2014-08-25 02:56:12 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:12 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:12 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:12 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:12 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:12 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:12 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:12 --> Employee MX_Controller Initialized
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:12 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:12 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:12 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:12 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:12 --> Total execution time: 0.0974
DEBUG - 2014-08-25 02:56:14 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:14 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:14 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:14 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:14 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:14 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:14 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-25 02:56:14 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:14 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:14 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:14 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:14 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:14 --> Total execution time: 0.1948
DEBUG - 2014-08-25 02:56:16 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:16 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:16 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:16 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:16 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:16 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:16 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:16 --> District MX_Controller Initialized
DEBUG - 2014-08-25 02:56:16 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:16 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:16 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:16 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:16 --> Total execution time: 0.1607
DEBUG - 2014-08-25 02:56:18 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:18 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:18 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:18 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:18 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:18 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:18 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:18 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:18 --> District MX_Controller Initialized
DEBUG - 2014-08-25 02:56:18 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:18 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/district/views/list_user_per_district.php
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:18 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:18 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:18 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:18 --> Total execution time: 0.1425
DEBUG - 2014-08-25 02:56:21 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:21 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:21 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:21 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:21 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:21 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:21 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Msr_client MX_Controller Initialized
DEBUG - 2014-08-25 02:56:21 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:21 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:21 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:21 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:21 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:21 --> Total execution time: 0.1784
DEBUG - 2014-08-25 02:56:25 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:56:25 --> URI Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Router Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Output Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Security Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Input Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:56:25 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Language Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Config Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Loader Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:56:25 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:56:25 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:56:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:56:25 --> Session Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:56:25 --> Session routines successfully run
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Controller Class Initialized
DEBUG - 2014-08-25 02:56:25 --> District MX_Controller Initialized
DEBUG - 2014-08-25 02:56:25 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:56:25 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:56:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:56:25 --> Model Class Initialized
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:56:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:56:25 --> Final output sent to browser
DEBUG - 2014-08-25 02:56:25 --> Total execution time: 0.1518
DEBUG - 2014-08-25 02:57:06 --> Config Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:57:06 --> URI Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Router Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Output Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Security Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Input Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:57:06 --> Language Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Language Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Config Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Loader Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:57:06 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:57:06 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:57:06 --> Session Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:57:06 --> Session routines successfully run
DEBUG - 2014-08-25 02:57:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:57:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:57:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:57:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:06 --> Controller Class Initialized
DEBUG - 2014-08-25 02:57:06 --> District MX_Controller Initialized
DEBUG - 2014-08-25 02:57:06 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:57:06 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/district/views/list_user_per_district.php
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:57:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:57:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:57:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:57:06 --> Final output sent to browser
DEBUG - 2014-08-25 02:57:06 --> Total execution time: 0.1236
DEBUG - 2014-08-25 02:57:17 --> Config Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:57:17 --> URI Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Router Class Initialized
DEBUG - 2014-08-25 02:57:17 --> No URI present. Default controller set.
DEBUG - 2014-08-25 02:57:17 --> Output Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Security Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Input Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:57:17 --> Language Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Language Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Config Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Loader Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:57:17 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:57:17 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:57:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:57:17 --> Session Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:57:17 --> Session routines successfully run
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Controller Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 02:57:17 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 02:57:17 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:57:17 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/views/grocery_crud.php
ERROR - 2014-08-25 02:57:17 --> Module controller failed to run: order/dashboard
ERROR - 2014-08-25 02:57:17 --> Module controller failed to run: payment/dashboard
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:57:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:57:17 --> Model Class Initialized
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:57:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:57:17 --> Final output sent to browser
DEBUG - 2014-08-25 02:57:17 --> Total execution time: 0.1906
DEBUG - 2014-08-25 02:58:06 --> Config Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Hooks Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Utf8 Class Initialized
DEBUG - 2014-08-25 02:58:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 02:58:06 --> URI Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Router Class Initialized
DEBUG - 2014-08-25 02:58:06 --> No URI present. Default controller set.
DEBUG - 2014-08-25 02:58:06 --> Output Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Security Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Input Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 02:58:06 --> Language Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Language Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Config Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Loader Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Helper loaded: url_helper
DEBUG - 2014-08-25 02:58:06 --> Helper loaded: common_helper
DEBUG - 2014-08-25 02:58:06 --> Database Driver Class Initialized
ERROR - 2014-08-25 02:58:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 02:58:06 --> Session Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Helper loaded: string_helper
DEBUG - 2014-08-25 02:58:06 --> Session routines successfully run
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Controller Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 02:58:06 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 02:58:06 --> Helper loaded: form_helper
DEBUG - 2014-08-25 02:58:06 --> Form Validation Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 02:58:06 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 02:58:06 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 02:58:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 02:58:06 --> Model Class Initialized
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 02:58:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 02:58:06 --> Final output sent to browser
DEBUG - 2014-08-25 02:58:06 --> Total execution time: 0.3553
DEBUG - 2014-08-25 03:03:10 --> Config Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:03:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:03:10 --> URI Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Router Class Initialized
DEBUG - 2014-08-25 03:03:10 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:03:10 --> Output Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Security Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Input Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:03:10 --> Language Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Language Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Config Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Loader Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:03:10 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:03:10 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:03:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:03:10 --> Session Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:03:10 --> Session routines successfully run
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Controller Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:03:10 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:03:10 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:03:10 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:03:10 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:03:10 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:03:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:03:10 --> Model Class Initialized
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:03:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:03:10 --> Final output sent to browser
DEBUG - 2014-08-25 03:03:10 --> Total execution time: 0.3638
DEBUG - 2014-08-25 03:04:40 --> Config Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:04:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:04:40 --> URI Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Router Class Initialized
DEBUG - 2014-08-25 03:04:40 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:04:40 --> Output Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Security Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Input Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:04:40 --> Language Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Language Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Config Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Loader Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:04:40 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:04:40 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:04:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:04:40 --> Session Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:04:40 --> Session routines successfully run
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Controller Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:04:40 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:04:40 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:04:40 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:04:40 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:04:40 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:04:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:04:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:04:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:04:40 --> Final output sent to browser
DEBUG - 2014-08-25 03:04:40 --> Total execution time: 0.3402
DEBUG - 2014-08-25 03:05:47 --> Config Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:05:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:05:47 --> URI Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Router Class Initialized
DEBUG - 2014-08-25 03:05:47 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:05:47 --> Output Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Security Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Input Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:05:47 --> Language Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Language Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Config Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Loader Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:05:47 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:05:47 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:05:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:05:47 --> Session Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:05:47 --> Session routines successfully run
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Controller Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:05:47 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:05:47 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:05:47 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:05:47 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:47 --> Model Class Initialized
DEBUG - 2014-08-25 03:05:48 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:06:09 --> Config Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:06:09 --> URI Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Router Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Output Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Security Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Input Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:06:09 --> Language Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Language Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Config Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Loader Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:06:09 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:06:09 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:06:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:06:09 --> Session Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:06:09 --> Session routines successfully run
DEBUG - 2014-08-25 03:06:09 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:06:09 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:06:09 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:06:09 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:09 --> Controller Class Initialized
DEBUG - 2014-08-25 03:06:09 --> District MX_Controller Initialized
DEBUG - 2014-08-25 03:06:09 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:06:09 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/district/views/list_user_per_district.php
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:06:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:06:09 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:06:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:06:09 --> Final output sent to browser
DEBUG - 2014-08-25 03:06:09 --> Total execution time: 0.1394
DEBUG - 2014-08-25 03:06:14 --> Config Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:06:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:06:14 --> URI Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Router Class Initialized
DEBUG - 2014-08-25 03:06:14 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:06:14 --> Output Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Security Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Input Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:06:14 --> Language Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Language Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Config Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Loader Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:06:14 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:06:14 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:06:14 --> Session Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:06:14 --> Session routines successfully run
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Controller Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:06:14 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:06:14 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:06:14 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:06:14 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:06:22 --> Config Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:06:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:06:22 --> URI Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Router Class Initialized
DEBUG - 2014-08-25 03:06:22 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:06:22 --> Output Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Security Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Input Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:06:22 --> Language Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Language Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Config Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Loader Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:06:22 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:06:22 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:06:22 --> Session Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:06:22 --> Session routines successfully run
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Controller Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:06:22 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:06:22 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:06:22 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:06:22 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:06:23 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:06:23 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:06:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:06:23 --> Model Class Initialized
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:06:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:06:23 --> Final output sent to browser
DEBUG - 2014-08-25 03:06:23 --> Total execution time: 0.3635
DEBUG - 2014-08-25 03:07:14 --> Config Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:07:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:07:14 --> URI Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Router Class Initialized
DEBUG - 2014-08-25 03:07:14 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:07:14 --> Output Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Security Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Input Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:07:14 --> Language Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Language Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Config Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Loader Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:07:14 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:07:14 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:07:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:07:14 --> Session Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:07:14 --> Session routines successfully run
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Controller Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:07:14 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:07:14 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:07:14 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:07:14 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:14 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:24 --> Config Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:07:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:07:24 --> URI Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Router Class Initialized
DEBUG - 2014-08-25 03:07:24 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:07:24 --> Output Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Security Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Input Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:07:24 --> Language Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Language Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Config Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Loader Class Initialized
DEBUG - 2014-08-25 03:07:24 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:07:24 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:07:24 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:07:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:07:25 --> Session Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:07:25 --> Session routines successfully run
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Controller Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:07:25 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:07:25 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:07:25 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:07:25 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:07:25 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:07:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:07:25 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:07:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:07:25 --> Final output sent to browser
DEBUG - 2014-08-25 03:07:25 --> Total execution time: 0.3508
DEBUG - 2014-08-25 03:07:29 --> Config Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:07:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:07:29 --> URI Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Router Class Initialized
DEBUG - 2014-08-25 03:07:29 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:07:29 --> Output Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Security Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Input Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:07:29 --> Language Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Language Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Config Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Loader Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:07:29 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:07:29 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:07:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:07:29 --> Session Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:07:29 --> Session routines successfully run
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Controller Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:07:29 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:07:29 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:07:29 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:07:29 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:07:29 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:07:29 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:07:29 --> Model Class Initialized
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:07:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:07:29 --> Final output sent to browser
DEBUG - 2014-08-25 03:07:29 --> Total execution time: 0.3643
DEBUG - 2014-08-25 03:08:45 --> Config Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:08:45 --> URI Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Router Class Initialized
DEBUG - 2014-08-25 03:08:45 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:08:45 --> Output Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Security Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Input Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:08:45 --> Language Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Language Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Config Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Loader Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:08:45 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:08:45 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:08:45 --> Session Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:08:45 --> Session routines successfully run
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Controller Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:08:45 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:08:45 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:08:45 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:08:45 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:08:45 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:08:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:08:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:08:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:08:45 --> Final output sent to browser
DEBUG - 2014-08-25 03:08:45 --> Total execution time: 0.3488
DEBUG - 2014-08-25 03:09:16 --> Config Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:09:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:09:16 --> URI Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Router Class Initialized
DEBUG - 2014-08-25 03:09:16 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:09:16 --> Output Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Security Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Input Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:09:16 --> Language Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Language Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Config Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Loader Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:09:16 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:09:16 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:09:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:09:16 --> Session Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:09:16 --> Session routines successfully run
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Controller Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:09:16 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:09:16 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:09:16 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:09:16 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:16 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:09:16 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:09:16 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:09:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:09:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:09:17 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:09:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:09:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:09:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:09:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:09:17 --> Final output sent to browser
DEBUG - 2014-08-25 03:09:17 --> Total execution time: 0.3469
DEBUG - 2014-08-25 03:10:00 --> Config Class Initialized
DEBUG - 2014-08-25 03:10:00 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:10:00 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:10:00 --> URI Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Router Class Initialized
DEBUG - 2014-08-25 03:10:01 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:10:01 --> Output Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Security Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Input Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:10:01 --> Language Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Language Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Config Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Loader Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:10:01 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:10:01 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:10:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:10:01 --> Session Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:10:01 --> Session routines successfully run
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Controller Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:10:01 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:10:01 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:10:01 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:10:01 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:10:01 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:10:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:10:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:10:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:10:01 --> Final output sent to browser
DEBUG - 2014-08-25 03:10:01 --> Total execution time: 0.3788
DEBUG - 2014-08-25 03:10:27 --> Config Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:10:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:10:27 --> URI Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Router Class Initialized
DEBUG - 2014-08-25 03:10:27 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:10:27 --> Output Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Security Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Input Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:10:27 --> Language Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Language Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Config Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Loader Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:10:27 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:10:27 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:10:27 --> Session Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:10:27 --> Session routines successfully run
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Controller Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:10:27 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:10:27 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:10:27 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:10:27 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:10:27 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:10:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:10:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:10:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:10:27 --> Final output sent to browser
DEBUG - 2014-08-25 03:10:27 --> Total execution time: 0.3678
DEBUG - 2014-08-25 03:10:39 --> Config Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:10:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:10:39 --> URI Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Router Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Output Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Security Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Input Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:10:39 --> Language Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Language Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Config Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Loader Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:10:39 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:10:39 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:10:39 --> Session Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:10:39 --> Session routines successfully run
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Controller Class Initialized
DEBUG - 2014-08-25 03:10:39 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:10:39 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:10:39 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
ERROR - 2014-08-25 03:10:39 --> Module controller failed to run: order/dashboard
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:10:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:10:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:10:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:10:39 --> Final output sent to browser
DEBUG - 2014-08-25 03:10:39 --> Total execution time: 0.1464
DEBUG - 2014-08-25 03:11:01 --> Config Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:11:01 --> URI Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Router Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Output Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Security Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Input Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:11:01 --> Language Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Language Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Config Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Loader Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:11:01 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:11:01 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:11:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:11:01 --> Session Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:11:01 --> Session routines successfully run
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Controller Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:11:01 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:11:01 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:11:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:11:01 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:11:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:11:01 --> Final output sent to browser
DEBUG - 2014-08-25 03:11:01 --> Total execution time: 0.2116
DEBUG - 2014-08-25 03:11:06 --> Config Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:11:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:11:06 --> URI Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Router Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Output Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Security Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Input Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:11:06 --> Language Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Language Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Config Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Loader Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:11:06 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:11:06 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:11:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:11:06 --> Session Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:11:06 --> Session routines successfully run
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Controller Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:11:06 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:11:06 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:11:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:11:06 --> Model Class Initialized
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:11:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:11:06 --> Final output sent to browser
DEBUG - 2014-08-25 03:11:06 --> Total execution time: 0.2237
DEBUG - 2014-08-25 03:13:55 --> Config Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:13:55 --> URI Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Router Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Output Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Security Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Input Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:13:55 --> Language Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Language Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Config Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Loader Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:13:55 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:13:55 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:13:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:13:55 --> Session Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:13:55 --> Session routines successfully run
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Controller Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:13:55 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:13:55 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:13:55 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:13:55 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:13:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:13:55 --> Final output sent to browser
DEBUG - 2014-08-25 03:13:55 --> Total execution time: 0.2450
DEBUG - 2014-08-25 03:13:58 --> Config Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:13:58 --> URI Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Router Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Output Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Security Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Input Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:13:58 --> Language Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Language Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Config Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Loader Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:13:58 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:13:58 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:13:58 --> Session Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:13:58 --> Session routines successfully run
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Controller Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:13:58 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:13:58 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:13:58 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:13:58 --> Model Class Initialized
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:13:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:13:58 --> Final output sent to browser
DEBUG - 2014-08-25 03:13:58 --> Total execution time: 0.1874
DEBUG - 2014-08-25 03:14:00 --> Config Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:14:00 --> URI Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Router Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Output Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Security Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Input Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:14:00 --> Language Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Language Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Config Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Loader Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:14:00 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:14:00 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:14:00 --> Session Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:14:00 --> Session routines successfully run
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Controller Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:14:00 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:14:00 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:14:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:14:00 --> Model Class Initialized
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:14:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:14:00 --> Final output sent to browser
DEBUG - 2014-08-25 03:14:00 --> Total execution time: 0.2159
DEBUG - 2014-08-25 03:18:27 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:18:27 --> URI Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Router Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Output Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Security Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Input Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:18:27 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Loader Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:18:27 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:18:27 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:18:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:18:27 --> Session Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:18:27 --> Session routines successfully run
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Controller Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:18:27 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:18:27 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:18:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:18:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:18:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:18:27 --> Final output sent to browser
DEBUG - 2014-08-25 03:18:27 --> Total execution time: 0.2428
DEBUG - 2014-08-25 03:18:30 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:18:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:18:30 --> URI Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Router Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Output Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Security Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Input Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:18:30 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Loader Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:18:30 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:18:30 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:18:30 --> Session Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:18:30 --> Session routines successfully run
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Controller Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:18:30 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:18:30 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:18:30 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:18:30 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:18:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:18:30 --> Final output sent to browser
DEBUG - 2014-08-25 03:18:30 --> Total execution time: 0.2167
DEBUG - 2014-08-25 03:18:34 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:18:34 --> URI Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Router Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Output Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Security Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Input Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:18:34 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Loader Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:18:34 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:18:34 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:18:34 --> Session Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:18:34 --> Session routines successfully run
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Controller Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:18:34 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:18:34 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:18:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:18:34 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:18:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:18:34 --> Final output sent to browser
DEBUG - 2014-08-25 03:18:34 --> Total execution time: 0.2159
DEBUG - 2014-08-25 03:18:38 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:18:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:18:38 --> URI Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Router Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Output Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Security Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Input Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:18:38 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Language Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Config Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Loader Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:18:38 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:18:38 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:18:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:18:38 --> Session Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:18:38 --> Session routines successfully run
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Controller Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:18:38 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:18:38 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:18:38 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:18:38 --> Model Class Initialized
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:18:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:18:38 --> Final output sent to browser
DEBUG - 2014-08-25 03:18:38 --> Total execution time: 0.2031
DEBUG - 2014-08-25 03:19:17 --> Config Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:19:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:19:17 --> URI Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Router Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Output Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Security Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Input Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:19:17 --> Language Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Language Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Config Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Loader Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:19:17 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:19:17 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:19:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:19:17 --> Session Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:19:17 --> Session routines successfully run
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Controller Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:19:17 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:19:17 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:19:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:19:17 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:19:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:19:17 --> Final output sent to browser
DEBUG - 2014-08-25 03:19:17 --> Total execution time: 0.2428
DEBUG - 2014-08-25 03:19:21 --> Config Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:19:21 --> URI Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Router Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Output Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Security Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Input Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:19:21 --> Language Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Language Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Config Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Loader Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:19:21 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:19:21 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:19:21 --> Session Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:19:21 --> Session routines successfully run
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Controller Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:19:21 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:19:21 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:19:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:21 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:19:22 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:19:22 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:19:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:19:22 --> Final output sent to browser
DEBUG - 2014-08-25 03:19:22 --> Total execution time: 0.1644
DEBUG - 2014-08-25 03:19:36 --> Config Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:19:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:19:36 --> URI Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Router Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Output Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Security Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Input Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:19:36 --> Language Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Language Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Config Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Loader Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:19:36 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:19:36 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:19:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:19:36 --> Session Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:19:36 --> Session routines successfully run
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Controller Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:19:36 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:19:36 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:19:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:19:36 --> Model Class Initialized
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:19:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:19:36 --> Final output sent to browser
DEBUG - 2014-08-25 03:19:36 --> Total execution time: 0.2359
DEBUG - 2014-08-25 03:28:39 --> Config Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:28:39 --> URI Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Router Class Initialized
DEBUG - 2014-08-25 03:28:39 --> No URI present. Default controller set.
DEBUG - 2014-08-25 03:28:39 --> Output Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Security Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Input Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:28:39 --> Language Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Language Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Config Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Loader Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:28:39 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:28:39 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:28:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:28:39 --> Session Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:28:39 --> Session routines successfully run
DEBUG - 2014-08-25 03:28:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:28:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:28:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:28:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Controller Class Initialized
DEBUG - 2014-08-25 03:28:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-25 03:28:39 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-25 03:28:39 --> Batch MX_Controller Initialized
DEBUG - 2014-08-25 03:28:40 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:28:40 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:28:40 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-25 03:28:40 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-25 03:28:40 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:28:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:28:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:28:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:28:40 --> Final output sent to browser
DEBUG - 2014-08-25 03:28:40 --> Total execution time: 0.3590
DEBUG - 2014-08-25 03:29:35 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:29:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:29:35 --> URI Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Router Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Output Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Security Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Input Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:29:35 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Loader Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:29:35 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:29:35 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:29:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:29:35 --> Session Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:29:35 --> Session routines successfully run
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Controller Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:29:35 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:29:35 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:29:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:29:35 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:29:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:29:35 --> Final output sent to browser
DEBUG - 2014-08-25 03:29:35 --> Total execution time: 0.2221
DEBUG - 2014-08-25 03:29:37 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:29:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:29:37 --> URI Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Router Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Output Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Security Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Input Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:29:37 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Loader Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:29:37 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:29:37 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:29:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:29:37 --> Session Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:29:37 --> Session routines successfully run
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Controller Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:29:37 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:29:37 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:29:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:29:37 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:29:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:29:37 --> Final output sent to browser
DEBUG - 2014-08-25 03:29:37 --> Total execution time: 0.2603
DEBUG - 2014-08-25 03:29:39 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:29:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:29:39 --> URI Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Router Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Output Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Security Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Input Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:29:39 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Loader Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:29:39 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:29:39 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:29:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:29:39 --> Session Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:29:39 --> Session routines successfully run
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Controller Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Sales MX_Controller Initialized
DEBUG - 2014-08-25 03:29:39 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:29:39 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:29:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:29:40 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:29:40 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:29:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:29:40 --> Final output sent to browser
DEBUG - 2014-08-25 03:29:40 --> Total execution time: 0.2144
DEBUG - 2014-08-25 03:29:41 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:29:41 --> URI Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Router Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Output Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Security Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Input Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:29:41 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Loader Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:29:41 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:29:41 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:29:41 --> Session Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:29:41 --> Session routines successfully run
DEBUG - 2014-08-25 03:29:41 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:29:41 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:29:41 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:29:41 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Controller Class Initialized
DEBUG - 2014-08-25 03:29:41 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:29:42 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:29:42 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:29:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:29:42 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:29:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:29:42 --> Final output sent to browser
DEBUG - 2014-08-25 03:29:42 --> Total execution time: 0.1321
DEBUG - 2014-08-25 03:29:45 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:29:45 --> URI Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Router Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Output Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Security Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Input Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:29:45 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Loader Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:29:45 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:29:45 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:29:45 --> Session Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:29:45 --> Session routines successfully run
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Controller Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:29:45 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:29:45 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:29:45 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:29:45 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:29:45 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:29:45 --> Final output sent to browser
DEBUG - 2014-08-25 03:29:45 --> Total execution time: 0.2198
DEBUG - 2014-08-25 03:29:48 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:29:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:29:48 --> URI Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Router Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Output Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Security Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Input Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:29:48 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Language Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Config Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Loader Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:29:48 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:29:48 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:29:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:29:48 --> Session Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:29:48 --> Session routines successfully run
DEBUG - 2014-08-25 03:29:48 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:29:48 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:29:48 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:29:48 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Controller Class Initialized
DEBUG - 2014-08-25 03:29:48 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:29:48 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:29:48 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:29:48 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:29:48 --> Model Class Initialized
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:29:48 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:29:48 --> Final output sent to browser
DEBUG - 2014-08-25 03:29:48 --> Total execution time: 0.1308
DEBUG - 2014-08-25 03:30:27 --> Config Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Hooks Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Utf8 Class Initialized
DEBUG - 2014-08-25 03:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-25 03:30:27 --> URI Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Router Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Output Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Security Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Input Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-25 03:30:27 --> Language Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Language Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Config Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Loader Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Helper loaded: url_helper
DEBUG - 2014-08-25 03:30:27 --> Helper loaded: common_helper
DEBUG - 2014-08-25 03:30:27 --> Database Driver Class Initialized
ERROR - 2014-08-25 03:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-25 03:30:27 --> Session Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Helper loaded: string_helper
DEBUG - 2014-08-25 03:30:27 --> Session routines successfully run
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Controller Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Collection MX_Controller Initialized
DEBUG - 2014-08-25 03:30:27 --> Helper loaded: form_helper
DEBUG - 2014-08-25 03:30:27 --> Form Validation Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-25 03:30:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-25 03:30:27 --> Model Class Initialized
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-25 03:30:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-25 03:30:27 --> Final output sent to browser
DEBUG - 2014-08-25 03:30:27 --> Total execution time: 0.2185
