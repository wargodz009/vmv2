<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-30 22:08:31 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:08:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:08:31 --> URI Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Router Class Initialized
DEBUG - 2014-08-30 22:08:31 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:08:31 --> Output Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Security Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Input Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:08:31 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Loader Class Initialized
DEBUG - 2014-08-30 22:08:31 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:08:31 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:08:31 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:08:32 --> Session Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:08:32 --> A session cookie was not found.
DEBUG - 2014-08-30 22:08:32 --> Session routines successfully run
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Controller Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:08:32 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:08:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:08:32 --> URI Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Router Class Initialized
DEBUG - 2014-08-30 22:08:32 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:08:32 --> Output Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Security Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Input Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:08:32 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Loader Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:08:32 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:08:32 --> Session Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:08:32 --> A session cookie was not found.
DEBUG - 2014-08-30 22:08:32 --> Session routines successfully run
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Controller Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:08:32 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:08:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:08:32 --> URI Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Router Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Output Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Security Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Input Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:08:32 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Loader Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:08:32 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:08:32 --> Session Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:08:32 --> Session routines successfully run
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Controller Class Initialized
DEBUG - 2014-08-30 22:08:32 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:08:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:08:32 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:08:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:08:32 --> Final output sent to browser
DEBUG - 2014-08-30 22:08:32 --> Total execution time: 0.1293
DEBUG - 2014-08-30 22:08:35 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:08:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:08:35 --> URI Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Router Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Output Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Security Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Input Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:08:35 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Loader Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:08:35 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:08:35 --> Session Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:08:35 --> Session routines successfully run
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Controller Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:08:35 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:08:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:08:35 --> URI Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Router Class Initialized
DEBUG - 2014-08-30 22:08:35 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:08:35 --> Output Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Security Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Input Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:08:35 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Language Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Config Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Loader Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:08:35 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:08:35 --> Session Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:08:35 --> Session routines successfully run
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Controller Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-30 22:08:35 --> Batch MX_Controller Initialized
DEBUG - 2014-08-30 22:08:35 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:08:35 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-30 22:08:35 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:08:35 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-30 22:08:35 --> Collection MX_Controller Initialized
DEBUG - 2014-08-30 22:08:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:08:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:08:36 --> Model Class Initialized
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:08:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:08:36 --> Final output sent to browser
DEBUG - 2014-08-30 22:08:36 --> Total execution time: 0.8290
DEBUG - 2014-08-30 22:13:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:13:13 --> URI Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Router Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Output Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Security Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Input Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:13:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Loader Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:13:13 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:13:13 --> Session Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:13:13 --> Session routines successfully run
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Controller Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:13:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:13:13 --> URI Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Router Class Initialized
DEBUG - 2014-08-30 22:13:13 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:13:13 --> Output Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Security Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Input Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:13:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Loader Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:13:13 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:13:13 --> Session Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:13:13 --> Session routines successfully run
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Controller Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:13:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:13:13 --> URI Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Router Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Output Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Security Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Input Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:13:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Loader Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:13:13 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:13:13 --> Session Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:13:13 --> Session routines successfully run
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Controller Class Initialized
DEBUG - 2014-08-30 22:13:13 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:13:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:13:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:13:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:13:13 --> Final output sent to browser
DEBUG - 2014-08-30 22:13:13 --> Total execution time: 0.0922
DEBUG - 2014-08-30 22:13:17 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:13:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:13:17 --> URI Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Router Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Output Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Security Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Input Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:13:17 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Loader Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:13:17 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:13:17 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:13:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:13:17 --> Session Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:13:17 --> Session routines successfully run
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Controller Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:13:17 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:13:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:13:17 --> URI Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Router Class Initialized
DEBUG - 2014-08-30 22:13:17 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:13:17 --> Output Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Security Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Input Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:13:17 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Language Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Config Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Loader Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:13:17 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:13:17 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:13:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:13:17 --> Session Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:13:17 --> Session routines successfully run
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Controller Class Initialized
DEBUG - 2014-08-30 22:13:17 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:13:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:13:17 --> Model Class Initialized
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:13:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:13:17 --> Final output sent to browser
DEBUG - 2014-08-30 22:13:17 --> Total execution time: 0.1179
DEBUG - 2014-08-30 22:14:09 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:09 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:09 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:14:09 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:09 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:09 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:09 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:09 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:09 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:09 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:10 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-30 22:14:10 --> Batch MX_Controller Initialized
DEBUG - 2014-08-30 22:14:10 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:14:10 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:14:10 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:14:10 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:10 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/modules/site/views/dashboard/dashboard_3.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:14:10 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:14:10 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:14:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:14:10 --> Final output sent to browser
DEBUG - 2014-08-30 22:14:10 --> Total execution time: 0.2140
DEBUG - 2014-08-30 22:14:16 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:16 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:16 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:16 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:16 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:16 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:16 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:16 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:16 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:16 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:16 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:16 --> Inventory MX_Controller Initialized
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:14:16 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:14:16 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:14:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:14:16 --> Final output sent to browser
DEBUG - 2014-08-30 22:14:16 --> Total execution time: 0.1075
DEBUG - 2014-08-30 22:14:24 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:24 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:24 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:24 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:24 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:25 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:25 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:25 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:25 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:25 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Item MX_Controller Initialized
DEBUG - 2014-08-30 22:14:25 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:14:25 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:14:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:14:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:14:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:14:25 --> Final output sent to browser
DEBUG - 2014-08-30 22:14:25 --> Total execution time: 0.2492
DEBUG - 2014-08-30 22:14:34 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:34 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:34 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:34 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:34 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:34 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:34 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:34 --> Report MX_Controller Initialized
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:14:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:14:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:14:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:14:34 --> Final output sent to browser
DEBUG - 2014-08-30 22:14:34 --> Total execution time: 0.1283
DEBUG - 2014-08-30 22:14:39 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:39 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:39 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:39 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:39 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:39 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:14:39 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:39 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:39 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:14:39 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:39 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:39 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:39 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:39 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:14:39 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:39 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:39 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:39 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:39 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:39 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:39 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:14:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:14:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:14:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:14:39 --> Final output sent to browser
DEBUG - 2014-08-30 22:14:39 --> Total execution time: 0.1061
DEBUG - 2014-08-30 22:14:43 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:43 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:43 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:43 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:43 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:43 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:43 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:14:43 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:14:43 --> URI Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Router Class Initialized
DEBUG - 2014-08-30 22:14:43 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:14:43 --> Output Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Security Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Input Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:14:43 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Language Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Config Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Loader Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:14:43 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:14:43 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:14:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:14:43 --> Session Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:14:43 --> Session routines successfully run
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Controller Class Initialized
DEBUG - 2014-08-30 22:14:43 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/site/views/dashboard/dashboard_2.php
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:14:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:14:43 --> Model Class Initialized
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:14:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:14:43 --> Final output sent to browser
DEBUG - 2014-08-30 22:14:43 --> Total execution time: 0.1117
DEBUG - 2014-08-30 22:15:00 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:00 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:00 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:15:00 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:00 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:00 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:00 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:00 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:00 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-30 22:15:00 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:15:00 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:15:00 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-30 22:15:00 --> Collection MX_Controller Initialized
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/site/views/dashboard/dashboard_2.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:00 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:00 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:00 --> Total execution time: 0.2635
DEBUG - 2014-08-30 22:15:25 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:25 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:25 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:26 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:26 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:26 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:26 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:26 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:15:26 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:26 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:26 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:15:26 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:26 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:26 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:26 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:26 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:15:26 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:26 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:26 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:26 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:26 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:26 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:26 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:26 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:26 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:26 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:26 --> Total execution time: 0.0938
DEBUG - 2014-08-30 22:15:30 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:30 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:30 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:30 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:30 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:30 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:15:30 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:30 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:30 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:15:30 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:30 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:30 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:30 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:30 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:15:30 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-30 22:15:30 --> Batch MX_Controller Initialized
DEBUG - 2014-08-30 22:15:30 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:15:30 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:30 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-30 22:15:31 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:15:31 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:15:31 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:31 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-30 22:15:31 --> Collection MX_Controller Initialized
DEBUG - 2014-08-30 22:15:31 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:31 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:31 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:31 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:31 --> Total execution time: 0.3483
DEBUG - 2014-08-30 22:15:35 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:35 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:35 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:35 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:35 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:35 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:35 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:35 --> Client MX_Controller Initialized
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:35 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:35 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:35 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:35 --> Total execution time: 0.0827
DEBUG - 2014-08-30 22:15:37 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:37 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:37 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:37 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:37 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:37 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:37 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:37 --> User MX_Controller Initialized
DEBUG - 2014-08-30 22:15:37 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:15:37 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:37 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:37 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:37 --> Total execution time: 0.2162
DEBUG - 2014-08-30 22:15:50 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:50 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:50 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:50 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:50 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:50 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:50 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:50 --> User MX_Controller Initialized
DEBUG - 2014-08-30 22:15:50 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:15:50 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:50 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:50 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:50 --> Total execution time: 0.2275
DEBUG - 2014-08-30 22:15:59 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:15:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:15:59 --> URI Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Router Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Output Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Security Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Input Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:15:59 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Language Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Config Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Loader Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:15:59 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:15:59 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:15:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:15:59 --> Session Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:15:59 --> Session routines successfully run
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Controller Class Initialized
DEBUG - 2014-08-30 22:15:59 --> User MX_Controller Initialized
DEBUG - 2014-08-30 22:15:59 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:15:59 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:15:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:15:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:15:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:15:59 --> Final output sent to browser
DEBUG - 2014-08-30 22:15:59 --> Total execution time: 0.2235
DEBUG - 2014-08-30 22:18:59 --> Config Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:18:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:18:59 --> URI Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Router Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Output Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Security Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Input Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:18:59 --> Language Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Language Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Config Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Loader Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:18:59 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:18:59 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:18:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:18:59 --> Session Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:18:59 --> Session routines successfully run
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Controller Class Initialized
DEBUG - 2014-08-30 22:18:59 --> User MX_Controller Initialized
DEBUG - 2014-08-30 22:18:59 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:18:59 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:18:59 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:18:59 --> Model Class Initialized
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:18:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:18:59 --> Final output sent to browser
DEBUG - 2014-08-30 22:18:59 --> Total execution time: 0.2046
DEBUG - 2014-08-30 22:19:34 --> Config Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:19:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:19:34 --> URI Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Router Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Output Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Security Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Input Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:19:34 --> Language Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Language Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Config Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Loader Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:19:34 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:19:34 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:19:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:19:34 --> Session Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:19:34 --> Session routines successfully run
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Controller Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Setting MX_Controller Initialized
DEBUG - 2014-08-30 22:19:34 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:19:34 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:19:34 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:19:34 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:19:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:19:34 --> Final output sent to browser
DEBUG - 2014-08-30 22:19:34 --> Total execution time: 0.2582
DEBUG - 2014-08-30 22:19:38 --> Config Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:19:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:19:38 --> URI Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Router Class Initialized
DEBUG - 2014-08-30 22:19:38 --> No URI present. Default controller set.
DEBUG - 2014-08-30 22:19:38 --> Output Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Security Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Input Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:19:38 --> Language Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Language Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Config Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Loader Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:19:38 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:19:38 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:19:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:19:38 --> Session Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:19:38 --> Session routines successfully run
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Controller Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Site MX_Controller Initialized
DEBUG - 2014-08-30 22:19:38 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-08-30 22:19:38 --> Batch MX_Controller Initialized
DEBUG - 2014-08-30 22:19:38 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:19:38 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:38 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-08-30 22:19:39 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:19:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:19:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-08-30 22:19:39 --> Collection MX_Controller Initialized
DEBUG - 2014-08-30 22:19:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:19:39 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:19:39 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:19:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:19:39 --> Final output sent to browser
DEBUG - 2014-08-30 22:19:39 --> Total execution time: 0.3306
DEBUG - 2014-08-30 22:19:41 --> Config Class Initialized
DEBUG - 2014-08-30 22:19:41 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:19:41 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:19:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:19:41 --> URI Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Router Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Output Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Security Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Input Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:19:42 --> Language Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Language Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Config Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Loader Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:19:42 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:19:42 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:19:42 --> Session Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:19:42 --> Session routines successfully run
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Controller Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:19:42 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:19:42 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:19:42 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:19:42 --> Model Class Initialized
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:19:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:19:42 --> Final output sent to browser
DEBUG - 2014-08-30 22:19:42 --> Total execution time: 0.1958
DEBUG - 2014-08-30 22:21:53 --> Config Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:21:53 --> URI Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Router Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Output Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Security Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Input Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:21:53 --> Language Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Language Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Config Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Loader Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:21:53 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:21:53 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:21:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:21:53 --> Session Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:21:53 --> Session routines successfully run
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Controller Class Initialized
DEBUG - 2014-08-30 22:21:53 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:21:53 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:21:53 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:21:53 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:21:53 --> Model Class Initialized
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:21:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:21:53 --> Final output sent to browser
DEBUG - 2014-08-30 22:21:53 --> Total execution time: 0.1343
DEBUG - 2014-08-30 22:37:20 --> Config Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:37:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:37:20 --> URI Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Router Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Output Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Security Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Input Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:37:20 --> Language Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Language Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Config Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Loader Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:37:20 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:37:20 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:37:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:37:20 --> Session Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:37:20 --> Session routines successfully run
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Controller Class Initialized
DEBUG - 2014-08-30 22:37:20 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:37:20 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:37:20 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:37:20 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:37:20 --> Model Class Initialized
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:37:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:37:20 --> Final output sent to browser
DEBUG - 2014-08-30 22:37:20 --> Total execution time: 0.1320
DEBUG - 2014-08-30 22:40:44 --> Config Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:40:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:40:44 --> URI Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Router Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Output Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Security Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Input Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:40:44 --> Language Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Language Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Config Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Loader Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:40:44 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:40:44 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:40:44 --> Session Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:40:44 --> Session routines successfully run
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Controller Class Initialized
DEBUG - 2014-08-30 22:40:44 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:40:44 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:40:44 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:40:44 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:40:44 --> Model Class Initialized
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:40:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:40:44 --> Final output sent to browser
DEBUG - 2014-08-30 22:40:44 --> Total execution time: 0.1403
DEBUG - 2014-08-30 22:41:07 --> Config Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:41:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:41:07 --> URI Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Router Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Output Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Security Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Input Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:41:07 --> Language Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Language Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Config Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Loader Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:41:07 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:41:07 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:41:07 --> Session Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:41:07 --> Session routines successfully run
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Controller Class Initialized
DEBUG - 2014-08-30 22:41:07 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:41:07 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:41:07 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:41:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:41:07 --> Model Class Initialized
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:41:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:41:07 --> Final output sent to browser
DEBUG - 2014-08-30 22:41:07 --> Total execution time: 0.1299
DEBUG - 2014-08-30 22:42:02 --> Config Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:42:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:42:02 --> URI Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Router Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Output Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Security Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Input Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:42:02 --> Language Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Language Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Config Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Loader Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:42:02 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:42:02 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:42:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:42:02 --> Session Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:42:02 --> Session routines successfully run
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Controller Class Initialized
DEBUG - 2014-08-30 22:42:02 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:42:02 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:42:02 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:42:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:42:02 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:42:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:42:02 --> Final output sent to browser
DEBUG - 2014-08-30 22:42:02 --> Total execution time: 0.1288
DEBUG - 2014-08-30 22:42:09 --> Config Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:42:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:42:09 --> URI Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Router Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Output Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Security Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Input Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:42:09 --> Language Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Language Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Config Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Loader Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:42:09 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:42:09 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:42:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:42:09 --> Session Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:42:09 --> Session routines successfully run
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Controller Class Initialized
DEBUG - 2014-08-30 22:42:09 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:42:09 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:42:09 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:42:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:42:09 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:42:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:42:09 --> Final output sent to browser
DEBUG - 2014-08-30 22:42:09 --> Total execution time: 0.1254
DEBUG - 2014-08-30 22:42:19 --> Config Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:42:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:42:19 --> URI Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Router Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Output Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Security Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Input Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:42:19 --> Language Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Language Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Config Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Loader Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:42:19 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:42:19 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:42:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:42:19 --> Session Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:42:19 --> Session routines successfully run
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Controller Class Initialized
DEBUG - 2014-08-30 22:42:19 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:42:19 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:42:19 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:42:19 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:42:19 --> Model Class Initialized
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:42:19 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:42:19 --> Final output sent to browser
DEBUG - 2014-08-30 22:42:19 --> Total execution time: 0.1437
DEBUG - 2014-08-30 22:59:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:59:13 --> URI Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Router Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Output Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Security Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Input Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:59:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Language Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Config Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Loader Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:59:13 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:59:13 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:59:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:59:13 --> Session Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:59:13 --> Session routines successfully run
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Controller Class Initialized
DEBUG - 2014-08-30 22:59:13 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:59:13 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:59:13 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:59:13 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:59:13 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:59:13 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:59:13 --> Final output sent to browser
DEBUG - 2014-08-30 22:59:13 --> Total execution time: 0.1288
DEBUG - 2014-08-30 22:59:25 --> Config Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Hooks Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Utf8 Class Initialized
DEBUG - 2014-08-30 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 22:59:25 --> URI Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Router Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Output Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Security Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Input Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 22:59:25 --> Language Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Language Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Config Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Loader Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Helper loaded: url_helper
DEBUG - 2014-08-30 22:59:25 --> Helper loaded: common_helper
DEBUG - 2014-08-30 22:59:25 --> Database Driver Class Initialized
ERROR - 2014-08-30 22:59:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 22:59:25 --> Session Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Helper loaded: string_helper
DEBUG - 2014-08-30 22:59:25 --> Session routines successfully run
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Controller Class Initialized
DEBUG - 2014-08-30 22:59:25 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 22:59:25 --> Helper loaded: form_helper
DEBUG - 2014-08-30 22:59:25 --> Form Validation Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 22:59:25 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 22:59:25 --> Model Class Initialized
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 22:59:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 22:59:25 --> Final output sent to browser
DEBUG - 2014-08-30 22:59:25 --> Total execution time: 0.1429
DEBUG - 2014-08-30 23:07:43 --> Config Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:07:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:07:43 --> URI Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Router Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Output Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Security Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Input Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:07:43 --> Language Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Language Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Config Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Loader Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:07:43 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:07:43 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:07:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:07:43 --> Session Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:07:43 --> Session routines successfully run
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Controller Class Initialized
DEBUG - 2014-08-30 23:07:43 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:07:43 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:07:43 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:07:43 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:07:43 --> Model Class Initialized
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:07:43 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:07:43 --> Final output sent to browser
DEBUG - 2014-08-30 23:07:43 --> Total execution time: 0.1266
DEBUG - 2014-08-30 23:08:02 --> Config Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:08:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:08:02 --> URI Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Router Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Output Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Security Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Input Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:08:02 --> Language Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Language Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Config Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Loader Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:08:02 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:08:02 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:08:02 --> Session Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:08:02 --> Session routines successfully run
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Controller Class Initialized
DEBUG - 2014-08-30 23:08:02 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:08:02 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:08:02 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:08:02 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:08:02 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:08:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:08:02 --> Final output sent to browser
DEBUG - 2014-08-30 23:08:02 --> Total execution time: 0.1264
DEBUG - 2014-08-30 23:08:17 --> Config Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:08:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:08:17 --> URI Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Router Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Output Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Security Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Input Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:08:17 --> Language Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Language Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Config Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Loader Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:08:17 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:08:17 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:08:17 --> Session Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:08:17 --> Session routines successfully run
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Controller Class Initialized
DEBUG - 2014-08-30 23:08:17 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:08:17 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:08:17 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:08:17 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:08:17 --> Model Class Initialized
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:08:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:08:17 --> Final output sent to browser
DEBUG - 2014-08-30 23:08:17 --> Total execution time: 0.1296
DEBUG - 2014-08-30 23:10:36 --> Config Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:10:36 --> URI Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Router Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Output Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Security Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Input Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:10:36 --> Language Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Language Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Config Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Loader Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:10:36 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:10:36 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:10:36 --> Session Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:10:36 --> Session routines successfully run
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Controller Class Initialized
DEBUG - 2014-08-30 23:10:36 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:10:36 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:10:36 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:10:36 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:10:36 --> Model Class Initialized
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:10:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:10:36 --> Final output sent to browser
DEBUG - 2014-08-30 23:10:36 --> Total execution time: 0.1207
DEBUG - 2014-08-30 23:11:32 --> Config Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:11:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:11:32 --> URI Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Router Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Output Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Security Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Input Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:11:32 --> Language Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Language Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Config Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Loader Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:11:32 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:11:32 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:11:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:11:32 --> Session Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:11:32 --> Session routines successfully run
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Controller Class Initialized
DEBUG - 2014-08-30 23:11:32 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:11:32 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:11:32 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:11:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:11:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:11:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:11:32 --> Final output sent to browser
DEBUG - 2014-08-30 23:11:32 --> Total execution time: 0.1305
DEBUG - 2014-08-30 23:11:46 --> Config Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:11:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:11:46 --> URI Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Router Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Output Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Security Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Input Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:11:46 --> Language Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Language Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Config Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Loader Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:11:46 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:11:46 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:11:46 --> Session Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:11:46 --> Session routines successfully run
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Controller Class Initialized
DEBUG - 2014-08-30 23:11:46 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:11:46 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:11:46 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:11:46 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:11:46 --> Model Class Initialized
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:11:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:11:46 --> Final output sent to browser
DEBUG - 2014-08-30 23:11:46 --> Total execution time: 0.1431
DEBUG - 2014-08-30 23:13:06 --> Config Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:13:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:13:06 --> URI Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Router Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Output Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Security Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Input Class Initialized
DEBUG - 2014-08-30 23:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:13:07 --> Language Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Language Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Config Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Loader Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:13:07 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:13:07 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:13:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:13:07 --> Session Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:13:07 --> Session routines successfully run
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Controller Class Initialized
DEBUG - 2014-08-30 23:13:07 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:13:07 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:13:07 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:13:07 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:13:07 --> Model Class Initialized
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:13:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:13:07 --> Final output sent to browser
DEBUG - 2014-08-30 23:13:07 --> Total execution time: 0.1267
DEBUG - 2014-08-30 23:14:01 --> Config Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:14:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:14:01 --> URI Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Router Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Output Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Security Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Input Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:14:01 --> Language Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Language Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Config Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Loader Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:14:01 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:14:01 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:14:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:14:01 --> Session Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:14:01 --> Session routines successfully run
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Controller Class Initialized
DEBUG - 2014-08-30 23:14:01 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:14:01 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:14:01 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:14:01 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:14:01 --> Model Class Initialized
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:14:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:14:01 --> Final output sent to browser
DEBUG - 2014-08-30 23:14:01 --> Total execution time: 0.1493
DEBUG - 2014-08-30 23:15:28 --> Config Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:15:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:15:28 --> URI Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Router Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Output Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Security Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Input Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:15:28 --> Language Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Language Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Config Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Loader Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:15:28 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:15:28 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:15:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:15:28 --> Session Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:15:28 --> Session routines successfully run
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Controller Class Initialized
DEBUG - 2014-08-30 23:15:28 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:15:28 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:15:28 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:15:28 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:15:28 --> Model Class Initialized
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:15:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:15:28 --> Final output sent to browser
DEBUG - 2014-08-30 23:15:28 --> Total execution time: 0.1339
DEBUG - 2014-08-30 23:18:00 --> Config Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:18:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:18:00 --> URI Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Router Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Output Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Security Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Input Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:18:00 --> Language Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Language Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Config Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Loader Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:18:00 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:18:00 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:18:00 --> Session Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:18:00 --> Session routines successfully run
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Controller Class Initialized
DEBUG - 2014-08-30 23:18:00 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:18:00 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:18:00 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:18:00 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:18:00 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:18:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:18:00 --> Final output sent to browser
DEBUG - 2014-08-30 23:18:00 --> Total execution time: 0.1327
DEBUG - 2014-08-30 23:18:32 --> Config Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:18:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:18:32 --> URI Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Router Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Output Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Security Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Input Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:18:32 --> Language Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Language Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Config Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Loader Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:18:32 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:18:32 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:18:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:18:32 --> Session Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:18:32 --> Session routines successfully run
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Controller Class Initialized
DEBUG - 2014-08-30 23:18:32 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:18:32 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:18:32 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:18:32 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:18:32 --> Model Class Initialized
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:18:32 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:18:32 --> Final output sent to browser
DEBUG - 2014-08-30 23:18:32 --> Total execution time: 0.1352
DEBUG - 2014-08-30 23:21:16 --> Config Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:21:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:21:16 --> URI Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Router Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Output Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Security Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Input Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:21:16 --> Language Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Language Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Config Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Loader Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:21:16 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:21:16 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:21:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:21:16 --> Session Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:21:16 --> Session routines successfully run
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Controller Class Initialized
DEBUG - 2014-08-30 23:21:16 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:21:16 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:21:16 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:21:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:16 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:21:16 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Config Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:21:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:21:37 --> URI Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Router Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Output Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Security Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Input Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:21:37 --> Language Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Language Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Config Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Loader Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:21:37 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:21:37 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:21:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:21:37 --> Session Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:21:37 --> Session routines successfully run
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Controller Class Initialized
DEBUG - 2014-08-30 23:21:37 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:21:37 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:21:37 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:21:37 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:21:37 --> Model Class Initialized
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:21:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:21:37 --> Final output sent to browser
DEBUG - 2014-08-30 23:21:37 --> Total execution time: 0.1665
DEBUG - 2014-08-30 23:22:05 --> Config Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:22:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:22:05 --> URI Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Router Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Output Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Security Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Input Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:22:05 --> Language Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Language Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Config Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Loader Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:22:05 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:22:05 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:22:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:22:05 --> Session Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:22:05 --> Session routines successfully run
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Controller Class Initialized
DEBUG - 2014-08-30 23:22:05 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:22:05 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:22:05 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:22:05 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:22:05 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:22:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:22:05 --> Final output sent to browser
DEBUG - 2014-08-30 23:22:05 --> Total execution time: 0.1343
DEBUG - 2014-08-30 23:22:27 --> Config Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:22:27 --> URI Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Router Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Output Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Security Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Input Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:22:27 --> Language Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Language Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Config Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Loader Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:22:27 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:22:27 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:22:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:22:27 --> Session Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:22:27 --> Session routines successfully run
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Controller Class Initialized
DEBUG - 2014-08-30 23:22:27 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:22:27 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:22:27 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:22:27 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:22:27 --> Model Class Initialized
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:22:27 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:22:27 --> Final output sent to browser
DEBUG - 2014-08-30 23:22:27 --> Total execution time: 0.1307
DEBUG - 2014-08-30 23:23:09 --> Config Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:23:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:23:09 --> URI Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Router Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Output Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Security Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Input Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:23:09 --> Language Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Language Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Config Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Loader Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:23:09 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:23:09 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:23:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:23:09 --> Session Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:23:09 --> Session routines successfully run
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Controller Class Initialized
DEBUG - 2014-08-30 23:23:09 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:23:09 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:23:09 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:23:09 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:23:09 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:23:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:23:09 --> Final output sent to browser
DEBUG - 2014-08-30 23:23:09 --> Total execution time: 0.1479
DEBUG - 2014-08-30 23:23:50 --> Config Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:23:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:23:50 --> URI Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Router Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Output Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Security Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Input Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:23:50 --> Language Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Language Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Config Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Loader Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:23:50 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:23:50 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:23:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:23:50 --> Session Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:23:50 --> Session routines successfully run
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Controller Class Initialized
DEBUG - 2014-08-30 23:23:50 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:23:50 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:23:50 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:23:50 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:23:50 --> Model Class Initialized
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:23:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:23:50 --> Final output sent to browser
DEBUG - 2014-08-30 23:23:50 --> Total execution time: 0.2338
DEBUG - 2014-08-30 23:24:23 --> Config Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:24:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:24:23 --> URI Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Router Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Output Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Security Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Input Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:24:23 --> Language Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Language Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Config Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Loader Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:24:23 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:24:23 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:24:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:24:23 --> Session Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:24:23 --> Session routines successfully run
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Controller Class Initialized
DEBUG - 2014-08-30 23:24:23 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:24:23 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:24:23 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:24:23 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:24:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:24:23 --> Model Class Initialized
DEBUG - 2014-08-30 23:24:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:24:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:24:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:24:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:24:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:24:24 --> Final output sent to browser
DEBUG - 2014-08-30 23:24:24 --> Total execution time: 0.1312
DEBUG - 2014-08-30 23:25:06 --> Config Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Hooks Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Utf8 Class Initialized
DEBUG - 2014-08-30 23:25:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-30 23:25:06 --> URI Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Router Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Output Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Security Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Input Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-30 23:25:06 --> Language Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Language Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Config Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Loader Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Helper loaded: url_helper
DEBUG - 2014-08-30 23:25:06 --> Helper loaded: common_helper
DEBUG - 2014-08-30 23:25:06 --> Database Driver Class Initialized
ERROR - 2014-08-30 23:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-30 23:25:06 --> Session Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Helper loaded: string_helper
DEBUG - 2014-08-30 23:25:06 --> Session routines successfully run
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Controller Class Initialized
DEBUG - 2014-08-30 23:25:06 --> Sales MX_Controller Initialized
DEBUG - 2014-08-30 23:25:06 --> Helper loaded: form_helper
DEBUG - 2014-08-30 23:25:06 --> Form Validation Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-08-30 23:25:06 --> Menu MX_Controller Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-08-30 23:25:06 --> Model Class Initialized
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-08-30 23:25:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-08-30 23:25:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-08-30 23:25:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-08-30 23:25:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-08-30 23:25:07 --> Final output sent to browser
DEBUG - 2014-08-30 23:25:07 --> Total execution time: 0.1339
