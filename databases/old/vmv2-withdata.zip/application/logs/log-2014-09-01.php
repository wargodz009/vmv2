<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-09-01 19:36:33 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:36:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:36:33 --> URI Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Router Class Initialized
DEBUG - 2014-09-01 19:36:33 --> No URI present. Default controller set.
DEBUG - 2014-09-01 19:36:33 --> Output Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Security Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Input Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:36:33 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Loader Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:36:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:36:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:36:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:36:33 --> Session Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:36:33 --> A session cookie was not found.
DEBUG - 2014-09-01 19:36:33 --> Session routines successfully run
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Controller Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Site MX_Controller Initialized
DEBUG - 2014-09-01 19:36:33 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:36:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:36:33 --> URI Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Router Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Output Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Security Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Input Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:36:33 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Loader Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:36:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:36:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:36:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:36:33 --> Session Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:36:33 --> Session routines successfully run
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Controller Class Initialized
DEBUG - 2014-09-01 19:36:33 --> Site MX_Controller Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/site/views/signin.php
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:36:33 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:36:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:36:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:36:33 --> Final output sent to browser
DEBUG - 2014-09-01 19:36:33 --> Total execution time: 0.0690
DEBUG - 2014-09-01 19:36:35 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:36:35 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:36:35 --> URI Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Router Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Output Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Security Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Input Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:36:35 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Loader Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:36:35 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:36:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:36:35 --> Session Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:36:35 --> Session routines successfully run
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Controller Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Site MX_Controller Initialized
DEBUG - 2014-09-01 19:36:35 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:36:35 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:36:35 --> URI Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Router Class Initialized
DEBUG - 2014-09-01 19:36:35 --> No URI present. Default controller set.
DEBUG - 2014-09-01 19:36:35 --> Output Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Security Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Input Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:36:35 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Language Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Config Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Loader Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:36:35 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:36:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:36:35 --> Session Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:36:35 --> Session routines successfully run
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Controller Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Site MX_Controller Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-09-01 19:36:35 --> Batch MX_Controller Initialized
DEBUG - 2014-09-01 19:36:35 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:36:35 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-09-01 19:36:35 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-09-01 19:36:36 --> Collection MX_Controller Initialized
DEBUG - 2014-09-01 19:36:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:36:36 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:36:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:36:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:36:36 --> Final output sent to browser
DEBUG - 2014-09-01 19:36:36 --> Total execution time: 0.4827
DEBUG - 2014-09-01 19:37:08 --> Config Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:37:08 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:37:08 --> URI Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Router Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Output Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Security Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Input Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:37:08 --> Language Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Language Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Config Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Loader Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:37:08 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:37:08 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:37:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:37:08 --> Session Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:37:08 --> Session routines successfully run
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Controller Class Initialized
DEBUG - 2014-09-01 19:37:08 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 19:37:08 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:37:08 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:37:08 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:37:08 --> Model Class Initialized
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:37:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:37:08 --> Final output sent to browser
DEBUG - 2014-09-01 19:37:08 --> Total execution time: 0.1516
DEBUG - 2014-09-01 19:48:01 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:01 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:01 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:01 --> No URI present. Default controller set.
DEBUG - 2014-09-01 19:48:01 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:01 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:01 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:01 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:01 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:01 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Site MX_Controller Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-09-01 19:48:01 --> Batch MX_Controller Initialized
DEBUG - 2014-09-01 19:48:01 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:48:01 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-09-01 19:48:01 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-09-01 19:48:01 --> Collection MX_Controller Initialized
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:01 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:01 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:01 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:01 --> Total execution time: 0.6020
DEBUG - 2014-09-01 19:48:15 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:15 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:15 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:15 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:15 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:15 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:15 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:15 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:15 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:16 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 19:48:16 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:48:16 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:16 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:16 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:16 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:16 --> Total execution time: 0.1708
DEBUG - 2014-09-01 19:48:17 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:17 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:17 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:17 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:17 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:17 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:17 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:17 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Collection MX_Controller Initialized
DEBUG - 2014-09-01 19:48:17 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:48:17 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/modules/collection/views/index.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:18 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:18 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:18 --> Total execution time: 0.2817
DEBUG - 2014-09-01 19:48:23 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:23 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:23 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:23 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:23 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:23 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:23 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:23 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:23 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:23 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:23 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:23 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:23 --> Inventory MX_Controller Initialized
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/inventory/views/index.php
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:23 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:23 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:23 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:23 --> Total execution time: 0.1140
DEBUG - 2014-09-01 19:48:30 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:30 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:30 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:30 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:30 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:30 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:30 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:30 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:30 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:30 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:30 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:30 --> Employee MX_Controller Initialized
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/employee/views/index.php
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:30 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:30 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:30 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:30 --> Total execution time: 0.1458
DEBUG - 2014-09-01 19:48:33 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:33 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:33 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:33 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:33 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:33 --> Client MX_Controller Initialized
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/client/views/index.php
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:33 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:33 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:33 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:33 --> Total execution time: 0.1141
DEBUG - 2014-09-01 19:48:36 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:36 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:36 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:36 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:36 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:36 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:36 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:36 --> Report MX_Controller Initialized
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/report/views/index.php
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:36 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:36 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:36 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:36 --> Total execution time: 0.1568
DEBUG - 2014-09-01 19:48:38 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:48:38 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:48:38 --> URI Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Router Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Output Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Security Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Input Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:48:38 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Language Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Config Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Loader Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:48:38 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:48:38 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:48:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:48:38 --> Session Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:48:38 --> Session routines successfully run
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Controller Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Setting MX_Controller Initialized
DEBUG - 2014-09-01 19:48:38 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:48:38 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:48:38 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:48:38 --> Model Class Initialized
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:48:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:48:38 --> Final output sent to browser
DEBUG - 2014-09-01 19:48:38 --> Total execution time: 0.2116
DEBUG - 2014-09-01 19:49:17 --> Config Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:49:17 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:49:17 --> URI Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Router Class Initialized
DEBUG - 2014-09-01 19:49:17 --> No URI present. Default controller set.
DEBUG - 2014-09-01 19:49:17 --> Output Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Security Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Input Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:49:17 --> Language Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Language Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Config Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Loader Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:49:17 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:49:17 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:49:17 --> Session Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:49:17 --> Session routines successfully run
DEBUG - 2014-09-01 19:49:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:49:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:49:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:49:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Controller Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Site MX_Controller Initialized
DEBUG - 2014-09-01 19:49:17 --> File loaded: application/controllers/../modules/batch/controllers/batch.php
DEBUG - 2014-09-01 19:49:17 --> Batch MX_Controller Initialized
DEBUG - 2014-09-01 19:49:17 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:49:17 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:49:17 --> Config file loaded: application/config/grocery_crud.php
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/controllers/../modules/sales/controllers/sales.php
DEBUG - 2014-09-01 19:49:18 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/controllers/../modules/collection/controllers/collection.php
DEBUG - 2014-09-01 19:49:18 --> Collection MX_Controller Initialized
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/grocery_crud.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/modules/site/views/dashboard/dashboard_1.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:49:18 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:49:18 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:49:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:49:18 --> Final output sent to browser
DEBUG - 2014-09-01 19:49:18 --> Total execution time: 0.3655
DEBUG - 2014-09-01 19:49:28 --> Config Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Hooks Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Utf8 Class Initialized
DEBUG - 2014-09-01 19:49:28 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 19:49:28 --> URI Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Router Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Output Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Security Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Input Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 19:49:28 --> Language Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Language Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Config Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Loader Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Helper loaded: url_helper
DEBUG - 2014-09-01 19:49:28 --> Helper loaded: common_helper
DEBUG - 2014-09-01 19:49:28 --> Database Driver Class Initialized
ERROR - 2014-09-01 19:49:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 19:49:28 --> Session Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Helper loaded: string_helper
DEBUG - 2014-09-01 19:49:28 --> Session routines successfully run
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Controller Class Initialized
DEBUG - 2014-09-01 19:49:28 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 19:49:28 --> Helper loaded: form_helper
DEBUG - 2014-09-01 19:49:28 --> Form Validation Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 19:49:28 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 19:49:28 --> Model Class Initialized
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 19:49:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 19:49:28 --> Final output sent to browser
DEBUG - 2014-09-01 19:49:28 --> Total execution time: 0.1441
DEBUG - 2014-09-01 20:09:18 --> Config Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:09:18 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:09:18 --> URI Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Router Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Output Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Security Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Input Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:09:18 --> Language Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Language Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Config Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Loader Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:09:18 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:09:18 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:09:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:09:18 --> Session Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:09:18 --> Session routines successfully run
DEBUG - 2014-09-01 20:09:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:09:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:09:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:09:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:09:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:09:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:09:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Controller Class Initialized
DEBUG - 2014-09-01 20:09:18 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:09:18 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:09:18 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:09:19 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:09:19 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Config Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:10:05 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:10:05 --> URI Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Router Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Output Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Security Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Input Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:10:05 --> Language Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Language Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Config Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Loader Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:10:05 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:10:05 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:10:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:10:05 --> Session Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:10:05 --> Session routines successfully run
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Controller Class Initialized
DEBUG - 2014-09-01 20:10:05 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:10:05 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:10:05 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:10:05 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:10:05 --> Model Class Initialized
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:10:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:10:05 --> Final output sent to browser
DEBUG - 2014-09-01 20:10:05 --> Total execution time: 0.1459
DEBUG - 2014-09-01 20:12:31 --> Config Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:12:31 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:12:31 --> URI Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Router Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Output Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Security Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Input Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:12:31 --> Language Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Language Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Config Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Loader Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:12:31 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:12:31 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:12:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:12:31 --> Session Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:12:31 --> Session routines successfully run
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Controller Class Initialized
DEBUG - 2014-09-01 20:12:31 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:12:31 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:12:31 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:12:31 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:12:31 --> Model Class Initialized
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:12:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:12:31 --> Final output sent to browser
DEBUG - 2014-09-01 20:12:31 --> Total execution time: 0.2180
DEBUG - 2014-09-01 20:13:14 --> Config Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:13:14 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:13:14 --> URI Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Router Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Output Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Security Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Input Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:13:14 --> Language Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Language Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Config Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Loader Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:13:14 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:13:14 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:13:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:13:14 --> Session Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:13:14 --> Session routines successfully run
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Controller Class Initialized
DEBUG - 2014-09-01 20:13:14 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:13:14 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:13:14 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:13:14 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:13:14 --> Model Class Initialized
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:13:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:13:14 --> Final output sent to browser
DEBUG - 2014-09-01 20:13:14 --> Total execution time: 0.1318
DEBUG - 2014-09-01 20:14:52 --> Config Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:14:52 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:14:52 --> URI Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Router Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Output Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Security Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Input Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:14:52 --> Language Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Language Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Config Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Loader Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:14:52 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:14:52 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:14:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:14:52 --> Session Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:14:52 --> Session routines successfully run
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Controller Class Initialized
DEBUG - 2014-09-01 20:14:52 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:14:52 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:14:52 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:14:52 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:14:52 --> Model Class Initialized
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:14:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:14:52 --> Final output sent to browser
DEBUG - 2014-09-01 20:14:52 --> Total execution time: 0.1534
DEBUG - 2014-09-01 20:18:46 --> Config Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:18:46 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:18:46 --> URI Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Router Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Output Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Security Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Input Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:18:46 --> Language Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Language Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Config Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Loader Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:18:46 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:18:46 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:18:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:18:46 --> Session Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:18:46 --> Session routines successfully run
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
DEBUG - 2014-09-01 20:18:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
DEBUG - 2014-09-01 20:18:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
DEBUG - 2014-09-01 20:18:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Controller Class Initialized
DEBUG - 2014-09-01 20:18:46 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:18:46 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:18:46 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:18:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
DEBUG - 2014-09-01 20:18:46 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:18:46 --> Model Class Initialized
ERROR - 2014-09-01 20:18:46 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\models\sales_model.php 32
ERROR - 2014-09-01 20:18:46 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\models\sales_model.php 32
DEBUG - 2014-09-01 20:18:46 --> DB Transaction Failure
ERROR - 2014-09-01 20:18:46 --> Query error: Unknown column 'datetime' in 'where clause'
DEBUG - 2014-09-01 20:18:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-09-01 20:19:10 --> Config Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:19:10 --> URI Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Router Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Output Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Security Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Input Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:19:10 --> Language Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Language Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Config Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Loader Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:19:10 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:19:10 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:19:10 --> Session Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:19:10 --> Session routines successfully run
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Controller Class Initialized
DEBUG - 2014-09-01 20:19:10 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:19:10 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:19:10 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
ERROR - 2014-09-01 20:19:10 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\models\sales_model.php 32
ERROR - 2014-09-01 20:19:10 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\models\sales_model.php 32
ERROR - 2014-09-01 20:19:10 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 3
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:19:10 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:19:10 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 20:19:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 20:19:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 20:19:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 20:19:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:19:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:19:10 --> Final output sent to browser
DEBUG - 2014-09-01 20:19:10 --> Total execution time: 0.1612
DEBUG - 2014-09-01 20:19:25 --> Config Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:19:25 --> URI Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Router Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Output Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Security Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Input Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:19:25 --> Language Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Language Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Config Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Loader Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:19:25 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:19:25 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:19:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:19:25 --> Session Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:19:25 --> Session routines successfully run
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Controller Class Initialized
DEBUG - 2014-09-01 20:19:25 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:19:25 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:19:25 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
ERROR - 2014-09-01 20:19:25 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 3
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:19:25 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:19:25 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:19:25 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:19:25 --> Final output sent to browser
DEBUG - 2014-09-01 20:19:25 --> Total execution time: 0.1274
DEBUG - 2014-09-01 20:19:42 --> Config Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:19:42 --> URI Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Router Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Output Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Security Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Input Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:19:42 --> Language Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Language Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Config Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Loader Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:19:42 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:19:42 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:19:42 --> Session Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:19:42 --> Session routines successfully run
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Controller Class Initialized
DEBUG - 2014-09-01 20:19:42 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:19:42 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:19:42 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:19:42 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:19:42 --> Model Class Initialized
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:19:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:19:42 --> Final output sent to browser
DEBUG - 2014-09-01 20:19:42 --> Total execution time: 0.1479
DEBUG - 2014-09-01 20:20:33 --> Config Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:20:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:20:33 --> URI Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Router Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Output Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Security Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Input Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:20:33 --> Language Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Language Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Config Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Loader Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:20:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:20:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:20:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:20:33 --> Session Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:20:33 --> Session routines successfully run
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Controller Class Initialized
DEBUG - 2014-09-01 20:20:33 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:20:33 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:20:33 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:20:33 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:20:33 --> Model Class Initialized
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:20:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:20:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:20:33 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:20:33 --> Final output sent to browser
DEBUG - 2014-09-01 20:20:33 --> Total execution time: 0.1496
DEBUG - 2014-09-01 20:21:17 --> Config Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:21:17 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:21:17 --> URI Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Router Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Output Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Security Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Input Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:21:17 --> Language Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Language Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Config Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Loader Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:21:17 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:21:17 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:21:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:21:17 --> Session Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:21:17 --> Session routines successfully run
DEBUG - 2014-09-01 20:21:17 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:17 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:21:17 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:17 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:21:17 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:17 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:21:17 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Controller Class Initialized
DEBUG - 2014-09-01 20:21:17 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:21:18 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:21:18 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:21:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:21:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:21:18 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:21:18 --> Model Class Initialized
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:21:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:21:18 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:21:18 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:21:18 --> Final output sent to browser
DEBUG - 2014-09-01 20:21:18 --> Total execution time: 0.1548
DEBUG - 2014-09-01 20:23:03 --> Config Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:23:03 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:23:03 --> URI Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Router Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Output Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Security Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Input Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:23:03 --> Language Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Language Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Config Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Loader Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:23:03 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:23:03 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:23:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:23:03 --> Session Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:23:03 --> Session routines successfully run
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Controller Class Initialized
DEBUG - 2014-09-01 20:23:03 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:23:03 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:23:03 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:23:03 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:23:03 --> Model Class Initialized
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:23:03 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:23:03 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:23:03 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:23:03 --> Final output sent to browser
DEBUG - 2014-09-01 20:23:03 --> Total execution time: 0.1480
DEBUG - 2014-09-01 20:24:00 --> Config Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:24:00 --> URI Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Router Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Output Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Security Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Input Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:24:00 --> Language Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Language Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Config Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Loader Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:24:00 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:24:00 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:24:00 --> Session Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:24:00 --> Session routines successfully run
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Controller Class Initialized
DEBUG - 2014-09-01 20:24:00 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:24:00 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:24:00 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:24:00 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:24:00 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:24:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:24:00 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:24:00 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:24:00 --> Final output sent to browser
DEBUG - 2014-09-01 20:24:00 --> Total execution time: 0.1337
DEBUG - 2014-09-01 20:24:35 --> Config Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:24:35 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:24:35 --> URI Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Router Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Output Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Security Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Input Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:24:35 --> Language Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Language Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Config Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Loader Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:24:35 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:24:35 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:24:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:24:35 --> Session Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:24:35 --> Session routines successfully run
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Controller Class Initialized
DEBUG - 2014-09-01 20:24:35 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:24:35 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:24:35 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:24:35 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:24:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:24:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:24:35 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:24:35 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:24:35 --> Final output sent to browser
DEBUG - 2014-09-01 20:24:35 --> Total execution time: 0.1423
DEBUG - 2014-09-01 20:39:35 --> Config Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:39:35 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:39:35 --> URI Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Router Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Output Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Security Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Input Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:39:35 --> Language Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Language Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Config Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Loader Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:39:35 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:39:35 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:39:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:39:35 --> Session Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:39:35 --> Session routines successfully run
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Controller Class Initialized
DEBUG - 2014-09-01 20:39:35 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:39:35 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:39:35 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:39:35 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:39:35 --> Model Class Initialized
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:39:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:39:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:39:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:39:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:39:36 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:39:36 --> Final output sent to browser
DEBUG - 2014-09-01 20:39:36 --> Total execution time: 0.1270
DEBUG - 2014-09-01 20:41:21 --> Config Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Hooks Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Utf8 Class Initialized
DEBUG - 2014-09-01 20:41:21 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 20:41:21 --> URI Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Router Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Output Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Security Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Input Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 20:41:21 --> Language Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Language Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Config Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Loader Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Helper loaded: url_helper
DEBUG - 2014-09-01 20:41:21 --> Helper loaded: common_helper
DEBUG - 2014-09-01 20:41:21 --> Database Driver Class Initialized
ERROR - 2014-09-01 20:41:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 20:41:21 --> Session Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Helper loaded: string_helper
DEBUG - 2014-09-01 20:41:21 --> Session routines successfully run
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Controller Class Initialized
DEBUG - 2014-09-01 20:41:21 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 20:41:21 --> Helper loaded: form_helper
DEBUG - 2014-09-01 20:41:21 --> Form Validation Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 20:41:21 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 20:41:21 --> Model Class Initialized
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 20:41:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 20:41:21 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 20:41:21 --> Helper loaded: text_helper
DEBUG - 2014-09-01 20:41:21 --> Final output sent to browser
DEBUG - 2014-09-01 20:41:21 --> Total execution time: 0.1621
DEBUG - 2014-09-01 21:16:44 --> Config Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:16:44 --> URI Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Router Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Output Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Security Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Input Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:16:44 --> Language Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Language Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Config Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Loader Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:16:44 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:16:44 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:16:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:16:44 --> Session Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:16:44 --> Session routines successfully run
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Controller Class Initialized
DEBUG - 2014-09-01 21:16:44 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:16:44 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:16:44 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 21:16:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:16:44 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:16:44 --> Model Class Initialized
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 21:16:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:16:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:16:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:16:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:16:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:16:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:16:44 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:16:44 --> Final output sent to browser
DEBUG - 2014-09-01 21:16:44 --> Total execution time: 0.1690
DEBUG - 2014-09-01 21:17:21 --> Config Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:17:21 --> URI Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Router Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Output Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Security Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Input Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:17:21 --> Language Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Language Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Config Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Loader Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:17:21 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:17:21 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:17:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:17:21 --> Session Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:17:21 --> Session routines successfully run
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Controller Class Initialized
DEBUG - 2014-09-01 21:17:21 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:17:21 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:17:21 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:17:21 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:17:21 --> Model Class Initialized
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:17:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:17:21 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:17:21 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:17:21 --> Final output sent to browser
DEBUG - 2014-09-01 21:17:21 --> Total execution time: 0.1296
DEBUG - 2014-09-01 21:18:24 --> Config Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:18:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:18:24 --> URI Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Router Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Output Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Security Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Input Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:18:24 --> Language Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Language Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Config Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Loader Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:18:24 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:18:24 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:18:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:18:24 --> Session Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:18:24 --> Session routines successfully run
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Controller Class Initialized
DEBUG - 2014-09-01 21:18:24 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:18:24 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:18:24 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:18:24 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:18:24 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:18:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:18:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:18:24 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:18:24 --> Final output sent to browser
DEBUG - 2014-09-01 21:18:24 --> Total execution time: 0.1315
DEBUG - 2014-09-01 21:18:51 --> Config Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:18:51 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:18:51 --> URI Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Router Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Output Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Security Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Input Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:18:51 --> Language Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Language Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Config Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Loader Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:18:51 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:18:51 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:18:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:18:51 --> Session Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:18:51 --> Session routines successfully run
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Controller Class Initialized
DEBUG - 2014-09-01 21:18:51 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:18:51 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:18:51 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:18:51 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:18:51 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:18:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:18:51 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:18:51 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:18:51 --> Final output sent to browser
DEBUG - 2014-09-01 21:18:51 --> Total execution time: 0.1289
DEBUG - 2014-09-01 21:18:57 --> Config Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:18:57 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:18:57 --> URI Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Router Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Output Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Security Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Input Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:18:57 --> Language Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Language Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Config Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Loader Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:18:57 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:18:57 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:18:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:18:57 --> Session Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:18:57 --> Session routines successfully run
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Controller Class Initialized
DEBUG - 2014-09-01 21:18:57 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:18:57 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:18:57 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:18:57 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:18:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:18:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:18:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:18:57 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:18:57 --> Final output sent to browser
DEBUG - 2014-09-01 21:18:57 --> Total execution time: 0.1162
DEBUG - 2014-09-01 21:19:20 --> Config Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:19:20 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:19:20 --> URI Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Router Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Output Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Security Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Input Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:19:20 --> Language Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Language Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Config Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Loader Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:19:20 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:19:20 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:19:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:19:20 --> Session Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:19:20 --> Session routines successfully run
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Controller Class Initialized
DEBUG - 2014-09-01 21:19:20 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:19:20 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:19:20 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:19:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:20 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:19:20 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Config Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:19:32 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:19:32 --> URI Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Router Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Output Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Security Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Input Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:19:32 --> Language Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Language Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Config Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Loader Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:19:32 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:19:32 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:19:32 --> Session Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:19:32 --> Session routines successfully run
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Controller Class Initialized
DEBUG - 2014-09-01 21:19:32 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:19:32 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:19:32 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:19:32 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:32 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:19:32 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Config Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:19:52 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:19:52 --> URI Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Router Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Output Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Security Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Input Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:19:52 --> Language Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Language Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Config Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Loader Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:19:52 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:19:52 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:19:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:19:52 --> Session Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:19:52 --> Session routines successfully run
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Controller Class Initialized
DEBUG - 2014-09-01 21:19:52 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:19:52 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:19:52 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:19:52 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:19:52 --> Model Class Initialized
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:19:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:19:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:19:52 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:19:52 --> Final output sent to browser
DEBUG - 2014-09-01 21:19:52 --> Total execution time: 0.1462
DEBUG - 2014-09-01 21:20:53 --> Config Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:20:53 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:20:53 --> URI Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Router Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Output Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Security Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Input Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:20:53 --> Language Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Language Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Config Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Loader Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:20:53 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:20:53 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:20:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:20:53 --> Session Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:20:53 --> Session routines successfully run
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:20:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:20:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:20:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Controller Class Initialized
DEBUG - 2014-09-01 21:20:53 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:20:53 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:20:53 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:20:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:20:53 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:20:53 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Config Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:22:08 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:22:08 --> URI Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Router Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Output Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Security Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Input Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:22:08 --> Language Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Language Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Config Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Loader Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:22:08 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:22:08 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:22:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:22:08 --> Session Class Initialized
DEBUG - 2014-09-01 21:22:08 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:22:08 --> Session routines successfully run
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> Controller Class Initialized
DEBUG - 2014-09-01 21:22:09 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:22:09 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:22:09 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:22:09 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:22:09 --> Model Class Initialized
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:22:09 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:22:09 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:22:09 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:22:09 --> Final output sent to browser
DEBUG - 2014-09-01 21:22:09 --> Total execution time: 0.1352
DEBUG - 2014-09-01 21:23:00 --> Config Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:23:00 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:23:00 --> URI Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Router Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Output Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Security Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Input Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:23:00 --> Language Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Language Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Config Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Loader Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:23:00 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:23:00 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:23:00 --> Session Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:23:00 --> Session routines successfully run
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Controller Class Initialized
DEBUG - 2014-09-01 21:23:00 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:23:00 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:23:00 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:23:00 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:23:00 --> Model Class Initialized
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:23:00 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:23:00 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:23:00 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:23:00 --> Final output sent to browser
DEBUG - 2014-09-01 21:23:00 --> Total execution time: 0.1346
DEBUG - 2014-09-01 21:25:13 --> Config Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:25:13 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:25:13 --> URI Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Router Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Output Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Security Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Input Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:25:13 --> Language Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Language Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Config Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Loader Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:25:13 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:25:13 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:25:13 --> Session Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:25:13 --> Session routines successfully run
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:25:13 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:25:13 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:25:13 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Controller Class Initialized
DEBUG - 2014-09-01 21:25:13 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:25:13 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:25:13 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:25:13 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:25:13 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:25:13 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Config Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:26:11 --> URI Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Router Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Output Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Security Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Input Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:26:11 --> Language Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Language Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Config Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Loader Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:26:11 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:26:11 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:26:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:26:11 --> Session Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:26:11 --> Session routines successfully run
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Controller Class Initialized
DEBUG - 2014-09-01 21:26:11 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:26:11 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:26:11 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:26:11 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:26:11 --> Model Class Initialized
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:26:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:26:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:26:11 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:26:11 --> Final output sent to browser
DEBUG - 2014-09-01 21:26:11 --> Total execution time: 0.1330
DEBUG - 2014-09-01 21:58:04 --> Config Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:58:04 --> URI Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Router Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Output Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Security Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Input Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:58:04 --> Language Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Language Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Config Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Loader Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:58:04 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:58:04 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:58:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:58:04 --> Session Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:58:04 --> Session routines successfully run
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Controller Class Initialized
DEBUG - 2014-09-01 21:58:04 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:58:04 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:58:04 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
ERROR - 2014-09-01 21:58:04 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 21:58:04 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 21:58:04 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:58:04 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:58:04 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 21:58:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:58:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:58:04 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:58:04 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:58:04 --> Final output sent to browser
DEBUG - 2014-09-01 21:58:04 --> Total execution time: 0.1752
DEBUG - 2014-09-01 21:58:38 --> Config Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:58:38 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:58:38 --> URI Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Router Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Output Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Security Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Input Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:58:38 --> Language Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Language Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Config Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Loader Class Initialized
DEBUG - 2014-09-01 21:58:38 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:58:38 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:58:38 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:58:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:58:39 --> Session Class Initialized
DEBUG - 2014-09-01 21:58:39 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:58:39 --> Session routines successfully run
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> Controller Class Initialized
DEBUG - 2014-09-01 21:58:39 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:58:39 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:58:39 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Undefined property: stdClass::$id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Undefined property: stdClass::$id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Undefined property: stdClass::$id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:58:39 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:58:39 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 21:58:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:58:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:58:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:58:39 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:58:39 --> Final output sent to browser
DEBUG - 2014-09-01 21:58:39 --> Total execution time: 0.1674
DEBUG - 2014-09-01 21:58:56 --> Config Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:58:56 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:58:56 --> URI Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Router Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Output Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Security Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Input Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:58:56 --> Language Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Language Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Config Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Loader Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:58:56 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:58:56 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:58:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:58:56 --> Session Class Initialized
DEBUG - 2014-09-01 21:58:56 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:58:56 --> Session routines successfully run
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> Controller Class Initialized
DEBUG - 2014-09-01 21:58:57 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:58:57 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:58:57 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
ERROR - 2014-09-01 21:58:57 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 21:58:57 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 21:58:57 --> Severity: Notice  --> Undefined variable: msr_id C:\xampp\htdocs\vmv2\application\helpers\common_helper.php 92
ERROR - 2014-09-01 21:58:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:58:57 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:58:57 --> Model Class Initialized
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 21:58:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 21:58:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:58:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:58:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:58:57 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:58:57 --> Final output sent to browser
DEBUG - 2014-09-01 21:58:57 --> Total execution time: 0.1790
DEBUG - 2014-09-01 21:59:18 --> Config Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Hooks Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Utf8 Class Initialized
DEBUG - 2014-09-01 21:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 21:59:18 --> URI Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Router Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Output Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Security Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Input Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 21:59:18 --> Language Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Language Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Config Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Loader Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Helper loaded: url_helper
DEBUG - 2014-09-01 21:59:18 --> Helper loaded: common_helper
DEBUG - 2014-09-01 21:59:18 --> Database Driver Class Initialized
ERROR - 2014-09-01 21:59:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 21:59:18 --> Session Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Helper loaded: string_helper
DEBUG - 2014-09-01 21:59:18 --> Session routines successfully run
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Controller Class Initialized
DEBUG - 2014-09-01 21:59:18 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 21:59:18 --> Helper loaded: form_helper
DEBUG - 2014-09-01 21:59:18 --> Form Validation Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 21:59:18 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 21:59:18 --> Model Class Initialized
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 21:59:18 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 21:59:18 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 21:59:18 --> Helper loaded: text_helper
DEBUG - 2014-09-01 21:59:18 --> Final output sent to browser
DEBUG - 2014-09-01 21:59:18 --> Total execution time: 0.1335
DEBUG - 2014-09-01 22:08:34 --> Config Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:08:34 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:08:34 --> URI Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Router Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Output Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Security Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Input Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:08:34 --> Language Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Language Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Config Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Loader Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:08:34 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:08:34 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:08:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:08:34 --> Session Class Initialized
DEBUG - 2014-09-01 22:08:34 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:08:34 --> Session routines successfully run
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> Controller Class Initialized
DEBUG - 2014-09-01 22:08:35 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:08:35 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:08:35 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
ERROR - 2014-09-01 22:08:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:08:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:08:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:08:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:08:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:08:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:08:35 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:08:35 --> Model Class Initialized
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:08:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:08:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:08:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:08:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:08:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:08:35 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:08:35 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:08:35 --> Final output sent to browser
DEBUG - 2014-09-01 22:08:35 --> Total execution time: 0.1908
DEBUG - 2014-09-01 22:13:39 --> Config Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:13:39 --> URI Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Router Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Output Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Security Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Input Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:13:39 --> Language Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Language Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Config Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Loader Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:13:39 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:13:39 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:13:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:13:39 --> Session Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:13:39 --> Session routines successfully run
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Controller Class Initialized
DEBUG - 2014-09-01 22:13:39 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:13:39 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:13:39 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
ERROR - 2014-09-01 22:13:39 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 58
ERROR - 2014-09-01 22:13:39 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 58
ERROR - 2014-09-01 22:13:39 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 58
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:13:39 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:13:39 --> Model Class Initialized
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:13:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:13:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:13:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:13:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:13:39 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:13:39 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:13:39 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:13:39 --> Final output sent to browser
DEBUG - 2014-09-01 22:13:39 --> Total execution time: 0.1671
DEBUG - 2014-09-01 22:43:16 --> Config Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:43:16 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:43:16 --> URI Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Router Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Output Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Security Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Input Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:43:16 --> Language Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Language Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Config Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Loader Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:43:16 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:43:16 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:43:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:43:16 --> Session Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:43:16 --> Session routines successfully run
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Controller Class Initialized
DEBUG - 2014-09-01 22:43:16 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:43:16 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:43:16 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 59
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 59
ERROR - 2014-09-01 22:43:16 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 59
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:43:16 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:43:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:43:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:43:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:43:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:43:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:43:16 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:43:16 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:43:16 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:43:16 --> Final output sent to browser
DEBUG - 2014-09-01 22:43:16 --> Total execution time: 0.3150
DEBUG - 2014-09-01 22:44:45 --> Config Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:44:45 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:44:45 --> URI Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Router Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Output Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Security Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Input Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:44:45 --> Language Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Language Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Config Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Loader Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:44:45 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:44:45 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:44:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:44:45 --> Session Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:44:45 --> Session routines successfully run
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:45 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:45 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:45 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Controller Class Initialized
DEBUG - 2014-09-01 22:44:45 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:44:45 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:44:45 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:44:45 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:45 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:44:45 --> Model Class Initialized
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:44:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:44:46 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:44:46 --> Model Class Initialized
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:44:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:44:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:44:46 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:44:46 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:44:46 --> Final output sent to browser
DEBUG - 2014-09-01 22:44:46 --> Total execution time: 0.2076
DEBUG - 2014-09-01 22:46:33 --> Config Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:46:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:46:33 --> URI Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Router Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Output Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Security Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Input Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:46:33 --> Language Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Language Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Config Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Loader Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:46:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:46:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:46:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:46:33 --> Session Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:46:33 --> Session routines successfully run
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Controller Class Initialized
DEBUG - 2014-09-01 22:46:33 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:46:33 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:46:33 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 76
ERROR - 2014-09-01 22:46:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:46:33 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:46:33 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:46:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:46:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:46:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:46:33 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:46:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:46:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:46:33 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:46:33 --> Final output sent to browser
DEBUG - 2014-09-01 22:46:33 --> Total execution time: 0.1744
DEBUG - 2014-09-01 22:46:56 --> Config Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:46:56 --> URI Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Router Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Output Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Security Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Input Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:46:56 --> Language Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Language Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Config Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Loader Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:46:56 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:46:56 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:46:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:46:56 --> Session Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:46:56 --> Session routines successfully run
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Controller Class Initialized
DEBUG - 2014-09-01 22:46:56 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:46:56 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:46:56 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
ERROR - 2014-09-01 22:46:56 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:56 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:56 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:56 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:46:56 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:46:56 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:46:56 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:46:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:46:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:46:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:46:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:46:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:46:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:46:56 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:46:56 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:46:56 --> Final output sent to browser
DEBUG - 2014-09-01 22:46:56 --> Total execution time: 0.1568
DEBUG - 2014-09-01 22:50:25 --> Config Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:50:25 --> URI Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Router Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Output Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Security Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Input Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:50:25 --> Language Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Language Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Config Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Loader Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:50:25 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:50:25 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:50:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:50:25 --> Session Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:50:25 --> Session routines successfully run
DEBUG - 2014-09-01 22:50:25 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:25 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:50:25 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:25 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:50:25 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:25 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:50:25 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Controller Class Initialized
DEBUG - 2014-09-01 22:50:25 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:50:26 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:50:26 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:50:26 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:50:26 --> Model Class Initialized
ERROR - 2014-09-01 22:50:26 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:50:26 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:50:26 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:50:26 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:50:26 --> Model Class Initialized
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:50:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:50:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:50:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:50:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:50:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:50:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:50:26 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:50:26 --> Final output sent to browser
DEBUG - 2014-09-01 22:50:26 --> Total execution time: 0.1696
DEBUG - 2014-09-01 22:53:16 --> Config Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:53:16 --> URI Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Router Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Output Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Security Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Input Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:53:16 --> Language Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Language Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Config Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Loader Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:53:16 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:53:16 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:53:16 --> Session Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:53:16 --> Session routines successfully run
DEBUG - 2014-09-01 22:53:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:16 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:53:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:16 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:53:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:16 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:53:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Controller Class Initialized
DEBUG - 2014-09-01 22:53:16 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:53:17 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:53:17 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:53:17 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:53:17 --> Model Class Initialized
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 73
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\models\crud_model.php 80
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 75
ERROR - 2014-09-01 22:53:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 77
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:53:17 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:53:17 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:53:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:53:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:53:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:53:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:53:17 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:53:17 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:53:17 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:53:17 --> Final output sent to browser
DEBUG - 2014-09-01 22:53:17 --> Total execution time: 0.3902
DEBUG - 2014-09-01 22:53:40 --> Config Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:53:40 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:53:40 --> URI Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Router Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Output Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Security Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Input Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:53:40 --> Language Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Language Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Config Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Loader Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:53:40 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:53:40 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:53:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:53:40 --> Session Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:53:40 --> Session routines successfully run
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Controller Class Initialized
DEBUG - 2014-09-01 22:53:40 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:53:40 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:53:40 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
ERROR - 2014-09-01 22:53:40 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:40 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:53:40 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:53:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:53:40 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:53:40 --> Model Class Initialized
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:53:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:53:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:53:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:53:40 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:53:40 --> Final output sent to browser
DEBUG - 2014-09-01 22:53:40 --> Total execution time: 0.1633
DEBUG - 2014-09-01 22:56:22 --> Config Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:56:22 --> URI Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Router Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Output Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Security Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Input Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:56:22 --> Language Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Language Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Config Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Loader Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:56:22 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:56:22 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:56:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:56:22 --> Session Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:56:22 --> Session routines successfully run
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Controller Class Initialized
DEBUG - 2014-09-01 22:56:22 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:56:22 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:56:22 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:56:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:22 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:56:22 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Config Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:56:36 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:56:36 --> URI Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Router Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Output Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Security Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Input Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:56:36 --> Language Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Language Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Config Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Loader Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:56:36 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:56:36 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:56:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:56:36 --> Session Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:56:36 --> Session routines successfully run
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Controller Class Initialized
DEBUG - 2014-09-01 22:56:36 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:56:36 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:56:36 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
ERROR - 2014-09-01 22:56:36 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:56:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:56:36 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:56:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
ERROR - 2014-09-01 22:56:36 --> Severity: Notice  --> Undefined property: stdClass::$msr_id C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 74
ERROR - 2014-09-01 22:56:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\vmv2\application\modules\user\models\user_model.php 64
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:56:36 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:56:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:4) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:56:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:56:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:56:36 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:56:36 --> Final output sent to browser
DEBUG - 2014-09-01 22:56:36 --> Total execution time: 0.2124
DEBUG - 2014-09-01 22:56:56 --> Config Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:56:56 --> URI Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Router Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Output Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Security Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Input Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:56:56 --> Language Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Language Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Config Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Loader Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:56:56 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:56:56 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:56:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:56:56 --> Session Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:56:56 --> Session routines successfully run
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Controller Class Initialized
DEBUG - 2014-09-01 22:56:56 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:56:56 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:56:56 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:56:56 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:56:56 --> Model Class Initialized
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:56:56 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:56:56 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:56:56 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:56:56 --> Final output sent to browser
DEBUG - 2014-09-01 22:56:56 --> Total execution time: 0.1418
DEBUG - 2014-09-01 22:57:06 --> Config Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:57:06 --> URI Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Router Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Output Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Security Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Input Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:57:06 --> Language Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Language Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Config Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Loader Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:57:06 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:57:06 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:57:06 --> Session Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:57:06 --> Session routines successfully run
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Controller Class Initialized
DEBUG - 2014-09-01 22:57:06 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:57:06 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:57:06 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:57:06 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:57:06 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:57:06 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:57:06 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:57:06 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:57:06 --> Final output sent to browser
DEBUG - 2014-09-01 22:57:06 --> Total execution time: 0.1435
DEBUG - 2014-09-01 22:57:30 --> Config Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:57:30 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:57:30 --> URI Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Router Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Output Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Security Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Input Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:57:30 --> Language Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Language Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Config Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Loader Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:57:30 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:57:30 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:57:30 --> Session Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:57:30 --> Session routines successfully run
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Controller Class Initialized
DEBUG - 2014-09-01 22:57:30 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:57:30 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:57:30 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:57:30 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:57:30 --> Model Class Initialized
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:57:30 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:57:30 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:57:30 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:57:30 --> Final output sent to browser
DEBUG - 2014-09-01 22:57:30 --> Total execution time: 0.1306
DEBUG - 2014-09-01 22:58:52 --> Config Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:58:52 --> URI Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Router Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Output Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Security Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Input Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:58:52 --> Language Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Language Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Config Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Loader Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:58:52 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:58:52 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:58:52 --> Session Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:58:52 --> Session routines successfully run
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Controller Class Initialized
DEBUG - 2014-09-01 22:58:52 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:58:52 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:58:52 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:58:52 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:58:52 --> Model Class Initialized
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:58:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:58:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:58:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:58:52 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:58:52 --> Final output sent to browser
DEBUG - 2014-09-01 22:58:52 --> Total execution time: 0.1571
DEBUG - 2014-09-01 22:59:42 --> Config Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Hooks Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Utf8 Class Initialized
DEBUG - 2014-09-01 22:59:42 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 22:59:42 --> URI Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Router Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Output Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Security Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Input Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 22:59:42 --> Language Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Language Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Config Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Loader Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Helper loaded: url_helper
DEBUG - 2014-09-01 22:59:42 --> Helper loaded: common_helper
DEBUG - 2014-09-01 22:59:42 --> Database Driver Class Initialized
ERROR - 2014-09-01 22:59:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 22:59:42 --> Session Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Helper loaded: string_helper
DEBUG - 2014-09-01 22:59:42 --> Session routines successfully run
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Controller Class Initialized
DEBUG - 2014-09-01 22:59:42 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 22:59:42 --> Helper loaded: form_helper
DEBUG - 2014-09-01 22:59:42 --> Form Validation Class Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 22:59:42 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 22:59:42 --> Model Class Initialized
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 22:59:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 22:59:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 22:59:42 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 22:59:42 --> Helper loaded: text_helper
DEBUG - 2014-09-01 22:59:42 --> Final output sent to browser
DEBUG - 2014-09-01 22:59:42 --> Total execution time: 0.1598
DEBUG - 2014-09-01 23:00:08 --> Config Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:00:08 --> URI Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Router Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Output Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Security Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Input Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:00:08 --> Language Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Language Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Config Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Loader Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:00:08 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:00:08 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:00:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:00:08 --> Session Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:00:08 --> Session routines successfully run
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Controller Class Initialized
DEBUG - 2014-09-01 23:00:08 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:00:08 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:00:08 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
ERROR - 2014-09-01 23:00:08 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:08 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:08 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:08 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:08 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 47
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:00:08 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:00:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:00:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:00:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:00:08 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:00:08 --> Final output sent to browser
DEBUG - 2014-09-01 23:00:08 --> Total execution time: 0.1586
DEBUG - 2014-09-01 23:00:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:00:24 --> URI Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Router Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Output Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Security Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Input Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:00:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Loader Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:00:24 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:00:24 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:00:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:00:24 --> Session Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:00:24 --> Session routines successfully run
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Controller Class Initialized
DEBUG - 2014-09-01 23:00:24 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:00:24 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:00:24 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'sales' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 49
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'quota' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Illegal string offset 'end_month' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:00:24 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:00:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:00:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:00:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:00:24 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:00:24 --> Final output sent to browser
DEBUG - 2014-09-01 23:00:24 --> Total execution time: 0.1600
DEBUG - 2014-09-01 23:00:42 --> Config Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:00:42 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:00:42 --> URI Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Router Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Output Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Security Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Input Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:00:42 --> Language Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Language Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Config Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Loader Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:00:42 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:00:42 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:00:42 --> Session Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:00:42 --> Session routines successfully run
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Controller Class Initialized
DEBUG - 2014-09-01 23:00:42 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:00:42 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:00:42 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
ERROR - 2014-09-01 23:00:42 --> Severity: Notice  --> Uninitialized string offset: 3 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:42 --> Severity: Notice  --> Uninitialized string offset: 4 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:00:42 --> Severity: Notice  --> Uninitialized string offset: 3 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 50
ERROR - 2014-09-01 23:00:42 --> Severity: Notice  --> Uninitialized string offset: 4 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:00:42 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:00:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:00:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:00:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:00:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:00:42 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:00:42 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:00:42 --> Final output sent to browser
DEBUG - 2014-09-01 23:00:42 --> Total execution time: 0.1469
DEBUG - 2014-09-01 23:01:42 --> Config Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:01:42 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:01:42 --> URI Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Router Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Output Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Security Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Input Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:01:42 --> Language Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Language Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Config Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Loader Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:01:42 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:01:42 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:01:42 --> Session Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:01:42 --> Session routines successfully run
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Controller Class Initialized
DEBUG - 2014-09-01 23:01:42 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:01:42 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:01:42 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:01:42 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:01:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:01:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:01:42 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:01:42 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:01:42 --> Final output sent to browser
DEBUG - 2014-09-01 23:01:42 --> Total execution time: 0.1449
DEBUG - 2014-09-01 23:02:21 --> Config Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:02:21 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:02:21 --> URI Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Router Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Output Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Security Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Input Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:02:21 --> Language Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Language Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Config Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Loader Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:02:21 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:02:21 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:02:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:02:21 --> Session Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:02:21 --> Session routines successfully run
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Controller Class Initialized
DEBUG - 2014-09-01 23:02:21 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:02:21 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:02:21 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:02:21 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:02:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:02:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:02:21 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:02:21 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:02:21 --> Final output sent to browser
DEBUG - 2014-09-01 23:02:21 --> Total execution time: 0.1292
DEBUG - 2014-09-01 23:02:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:02:58 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:02:58 --> URI Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Router Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Output Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Security Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Input Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:02:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Loader Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:02:58 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:02:58 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:02:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:02:58 --> Session Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:02:58 --> Session routines successfully run
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Controller Class Initialized
DEBUG - 2014-09-01 23:02:58 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:02:58 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:02:58 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:02:58 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:02:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:02:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:02:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:02:58 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:02:58 --> Final output sent to browser
DEBUG - 2014-09-01 23:02:58 --> Total execution time: 0.1356
DEBUG - 2014-09-01 23:03:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:03:24 --> URI Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Router Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Output Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Security Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Input Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:03:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Loader Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:03:24 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:03:24 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:03:24 --> Session Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:03:24 --> Session routines successfully run
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Controller Class Initialized
DEBUG - 2014-09-01 23:03:24 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:03:24 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:03:24 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:03:24 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:03:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:03:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:03:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:03:24 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:03:24 --> Final output sent to browser
DEBUG - 2014-09-01 23:03:24 --> Total execution time: 0.1405
DEBUG - 2014-09-01 23:03:55 --> Config Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:03:55 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:03:55 --> URI Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Router Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Output Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Security Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Input Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:03:55 --> Language Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Language Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Config Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Loader Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:03:55 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:03:55 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:03:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:03:55 --> Session Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:03:55 --> Session routines successfully run
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Controller Class Initialized
DEBUG - 2014-09-01 23:03:55 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:03:55 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:03:55 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
ERROR - 2014-09-01 23:03:55 --> Severity: Notice  --> Uninitialized string offset: 3 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:03:55 --> Severity: Notice  --> Uninitialized string offset: 4 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
ERROR - 2014-09-01 23:03:55 --> Severity: Notice  --> Uninitialized string offset: 3 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 51
ERROR - 2014-09-01 23:03:55 --> Severity: Notice  --> Uninitialized string offset: 4 C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 52
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:03:55 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:03:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:03:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:03:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:03:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:03:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:03:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:03:55 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:03:55 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:03:55 --> Final output sent to browser
DEBUG - 2014-09-01 23:03:55 --> Total execution time: 0.1338
DEBUG - 2014-09-01 23:04:36 --> Config Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:04:36 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:04:36 --> URI Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Router Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Output Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Security Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Input Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:04:36 --> Language Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Language Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Config Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Loader Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:04:36 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:04:36 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:04:36 --> Session Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:04:36 --> Session routines successfully run
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Controller Class Initialized
DEBUG - 2014-09-01 23:04:36 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:04:36 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:04:36 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:04:36 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:04:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:04:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:04:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:04:36 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:04:36 --> Final output sent to browser
DEBUG - 2014-09-01 23:04:36 --> Total execution time: 0.1400
DEBUG - 2014-09-01 23:04:44 --> Config Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:04:44 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:04:44 --> URI Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Router Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Output Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Security Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Input Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:04:44 --> Language Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Language Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Config Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Loader Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:04:44 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:04:44 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:04:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:04:44 --> Session Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:04:44 --> Session routines successfully run
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Controller Class Initialized
DEBUG - 2014-09-01 23:04:44 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:04:44 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:04:44 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Illegal string offset 'area' C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:04:44 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:04:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:04:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:04:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:04:44 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:04:44 --> Final output sent to browser
DEBUG - 2014-09-01 23:04:44 --> Total execution time: 0.1504
DEBUG - 2014-09-01 23:04:57 --> Config Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:04:57 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:04:57 --> URI Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Router Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Output Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Security Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Input Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:04:57 --> Language Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Language Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Config Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Loader Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:04:57 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:04:57 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:04:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:04:57 --> Session Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:04:57 --> Session routines successfully run
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Controller Class Initialized
DEBUG - 2014-09-01 23:04:57 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:04:57 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:04:57 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
ERROR - 2014-09-01 23:04:57 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:57 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:57 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:57 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:04:57 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:04:57 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:04:57 --> Model Class Initialized
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:04:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:04:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:04:57 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:04:57 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:04:57 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:04:57 --> Final output sent to browser
DEBUG - 2014-09-01 23:04:57 --> Total execution time: 0.1523
DEBUG - 2014-09-01 23:05:07 --> Config Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:05:07 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:05:07 --> URI Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Router Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Output Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Security Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Input Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:05:07 --> Language Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Language Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Config Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Loader Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:05:07 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:05:07 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:05:07 --> Session Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:05:07 --> Session routines successfully run
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Controller Class Initialized
DEBUG - 2014-09-01 23:05:07 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:05:07 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:05:07 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:05:07 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:05:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:05:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:05:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:05:07 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:05:08 --> Final output sent to browser
DEBUG - 2014-09-01 23:05:08 --> Total execution time: 0.1496
DEBUG - 2014-09-01 23:05:29 --> Config Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:05:29 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:05:29 --> URI Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Router Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Output Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Security Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Input Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:05:29 --> Language Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Language Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Config Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Loader Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:05:29 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:05:29 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:05:29 --> Session Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:05:29 --> Session routines successfully run
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Controller Class Initialized
DEBUG - 2014-09-01 23:05:29 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:05:29 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:05:29 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:05:29 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:05:29 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:05:29 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:05:29 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:05:29 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:05:29 --> Final output sent to browser
DEBUG - 2014-09-01 23:05:29 --> Total execution time: 0.1390
DEBUG - 2014-09-01 23:05:52 --> Config Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:05:52 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:05:52 --> URI Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Router Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Output Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Security Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Input Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:05:52 --> Language Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Language Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Config Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Loader Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:05:52 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:05:52 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:05:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:05:52 --> Session Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:05:52 --> Session routines successfully run
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Controller Class Initialized
DEBUG - 2014-09-01 23:05:52 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:05:52 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:05:52 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
ERROR - 2014-09-01 23:05:52 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:05:52 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:05:52 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:05:52 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:05:52 --> Severity: Notice  --> Undefined variable: val C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:05:52 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:05:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:05:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:05:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:05:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:05:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:05:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:05:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:05:52 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:05:52 --> Final output sent to browser
DEBUG - 2014-09-01 23:05:52 --> Total execution time: 0.1369
DEBUG - 2014-09-01 23:06:07 --> Config Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:06:07 --> URI Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Router Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Output Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Security Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Input Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:06:07 --> Language Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Language Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Config Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Loader Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:06:07 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:06:07 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:06:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:06:07 --> Session Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:06:07 --> Session routines successfully run
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Controller Class Initialized
DEBUG - 2014-09-01 23:06:07 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:06:07 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:06:07 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:06:07 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:06:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:06:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:06:07 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:06:07 --> Final output sent to browser
DEBUG - 2014-09-01 23:06:07 --> Total execution time: 0.1507
DEBUG - 2014-09-01 23:06:14 --> Config Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:06:14 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:06:14 --> URI Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Router Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Output Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Security Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Input Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:06:14 --> Language Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Language Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Config Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Loader Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:06:14 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:06:14 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:06:14 --> Session Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:06:14 --> Session routines successfully run
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Controller Class Initialized
DEBUG - 2014-09-01 23:06:14 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:06:14 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:06:14 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
ERROR - 2014-09-01 23:06:14 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:06:14 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:06:14 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:06:14 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
ERROR - 2014-09-01 23:06:14 --> Severity: Notice  --> Undefined variable: area C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 48
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:06:14 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:06:14 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:06:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:06:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:06:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:06:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:06:14 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:06:14 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:06:15 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:06:15 --> Final output sent to browser
DEBUG - 2014-09-01 23:06:15 --> Total execution time: 0.1866
DEBUG - 2014-09-01 23:06:20 --> Config Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:06:20 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:06:20 --> URI Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Router Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Output Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Security Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Input Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:06:20 --> Language Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Language Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Config Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Loader Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:06:20 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:06:20 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:06:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:06:20 --> Session Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:06:20 --> Session routines successfully run
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Controller Class Initialized
DEBUG - 2014-09-01 23:06:20 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:06:20 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:06:20 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:06:20 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:06:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:06:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:06:20 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:06:20 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:06:20 --> Final output sent to browser
DEBUG - 2014-09-01 23:06:20 --> Total execution time: 0.1380
DEBUG - 2014-09-01 23:07:52 --> Config Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:07:52 --> URI Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Router Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Output Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Security Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Input Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:07:52 --> Language Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Language Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Config Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Loader Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:07:52 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:07:52 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:07:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:07:52 --> Session Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:07:52 --> Session routines successfully run
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Controller Class Initialized
DEBUG - 2014-09-01 23:07:52 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:07:52 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:07:52 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:07:52 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:07:52 --> Model Class Initialized
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:07:52 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:07:52 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:07:52 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:07:52 --> Final output sent to browser
DEBUG - 2014-09-01 23:07:52 --> Total execution time: 0.1367
DEBUG - 2014-09-01 23:08:05 --> Config Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:08:05 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:08:05 --> URI Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Router Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Output Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Security Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Input Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:08:05 --> Language Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Language Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Config Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Loader Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:08:05 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:08:05 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:08:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:08:05 --> Session Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:08:05 --> Session routines successfully run
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Controller Class Initialized
DEBUG - 2014-09-01 23:08:05 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:08:05 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:08:05 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:08:05 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:08:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:08:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:08:05 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:08:05 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:08:05 --> Final output sent to browser
DEBUG - 2014-09-01 23:08:05 --> Total execution time: 0.1379
DEBUG - 2014-09-01 23:09:11 --> Config Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:09:11 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:09:11 --> URI Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Router Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Output Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Security Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Input Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:09:11 --> Language Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Language Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Config Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Loader Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:09:11 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:09:11 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:09:11 --> Session Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:09:11 --> Session routines successfully run
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Controller Class Initialized
DEBUG - 2014-09-01 23:09:11 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:09:11 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:09:11 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
ERROR - 2014-09-01 23:09:11 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 59
ERROR - 2014-09-01 23:09:11 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 59
ERROR - 2014-09-01 23:09:11 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 59
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:09:11 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:09:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:09:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:09:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:09:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:09:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:09:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:09:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:09:11 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:09:11 --> Final output sent to browser
DEBUG - 2014-09-01 23:09:11 --> Total execution time: 0.1553
DEBUG - 2014-09-01 23:10:11 --> Config Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:10:11 --> URI Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Router Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Output Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Security Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Input Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:10:11 --> Language Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Language Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Config Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Loader Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:10:11 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:10:11 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:10:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:10:11 --> Session Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:10:11 --> Session routines successfully run
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Controller Class Initialized
DEBUG - 2014-09-01 23:10:11 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:10:11 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:10:11 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:10:11 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:10:11 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:10:11 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:10:11 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:10:11 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:10:11 --> Final output sent to browser
DEBUG - 2014-09-01 23:10:11 --> Total execution time: 0.1435
DEBUG - 2014-09-01 23:10:22 --> Config Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:10:22 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:10:22 --> URI Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Router Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Output Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Security Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Input Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:10:22 --> Language Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Language Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Config Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Loader Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:10:22 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:10:22 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:10:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:10:22 --> Session Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:10:22 --> Session routines successfully run
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Controller Class Initialized
DEBUG - 2014-09-01 23:10:22 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:10:22 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:10:22 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:10:22 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:10:22 --> Model Class Initialized
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:10:22 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:10:22 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:10:22 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:10:22 --> Final output sent to browser
DEBUG - 2014-09-01 23:10:22 --> Total execution time: 0.1320
DEBUG - 2014-09-01 23:12:10 --> Config Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:12:10 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:12:10 --> URI Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Router Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Output Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Security Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Input Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:12:10 --> Language Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Language Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Config Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Loader Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:12:10 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:12:10 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:12:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:12:10 --> Session Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:12:10 --> Session routines successfully run
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Controller Class Initialized
DEBUG - 2014-09-01 23:12:10 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:12:10 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:12:10 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:12:10 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:12:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:12:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:12:10 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:12:10 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:12:10 --> Final output sent to browser
DEBUG - 2014-09-01 23:12:10 --> Total execution time: 0.1379
DEBUG - 2014-09-01 23:20:40 --> Config Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:20:40 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:20:40 --> URI Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Router Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Output Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Security Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Input Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:20:40 --> Language Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Language Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Config Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Loader Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:20:40 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:20:40 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:20:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:20:40 --> Session Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:20:40 --> Session routines successfully run
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Controller Class Initialized
DEBUG - 2014-09-01 23:20:40 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:20:40 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:20:40 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:20:40 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:20:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:20:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:20:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:20:40 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:20:40 --> Final output sent to browser
DEBUG - 2014-09-01 23:20:40 --> Total execution time: 0.1447
DEBUG - 2014-09-01 23:20:50 --> Config Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:20:50 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:20:50 --> URI Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Router Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Output Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Security Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Input Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:20:50 --> Language Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Language Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Config Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Loader Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:20:50 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:20:50 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:20:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:20:50 --> Session Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:20:50 --> Session routines successfully run
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Controller Class Initialized
DEBUG - 2014-09-01 23:20:50 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:20:50 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:20:50 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:20:50 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:20:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:20:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:20:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:20:50 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:20:50 --> Final output sent to browser
DEBUG - 2014-09-01 23:20:50 --> Total execution time: 0.1496
DEBUG - 2014-09-01 23:22:59 --> Config Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:22:59 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:22:59 --> URI Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Router Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Output Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Security Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Input Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:22:59 --> Language Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Language Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Config Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Loader Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:22:59 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:22:59 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:22:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:22:59 --> Session Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:22:59 --> Session routines successfully run
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Controller Class Initialized
DEBUG - 2014-09-01 23:22:59 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:22:59 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:22:59 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
ERROR - 2014-09-01 23:22:59 --> Severity: Notice  --> Undefined variable: day C:\xampp\htdocs\vmv2\application\modules\sales\controllers\sales.php 69
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:22:59 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:22:59 --> Model Class Initialized
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:22:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:22:59 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:22:59 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:22:59 --> Final output sent to browser
DEBUG - 2014-09-01 23:22:59 --> Total execution time: 0.1508
DEBUG - 2014-09-01 23:23:26 --> Config Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:23:26 --> URI Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Router Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Output Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Security Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Input Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:23:26 --> Language Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Language Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Config Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Loader Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:23:26 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:23:26 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:23:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:23:26 --> Session Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:23:26 --> Session routines successfully run
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Controller Class Initialized
DEBUG - 2014-09-01 23:23:26 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:23:26 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:23:26 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:23:26 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:23:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:23:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:23:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:23:26 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:23:26 --> Final output sent to browser
DEBUG - 2014-09-01 23:23:26 --> Total execution time: 0.1353
DEBUG - 2014-09-01 23:25:26 --> Config Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:25:26 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:25:26 --> URI Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Router Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Output Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Security Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Input Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:25:26 --> Language Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Language Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Config Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Loader Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:25:26 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:25:26 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:25:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:25:26 --> Session Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:25:26 --> Session routines successfully run
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Controller Class Initialized
DEBUG - 2014-09-01 23:25:26 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:25:26 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:25:26 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:25:26 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:25:26 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:25:26 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:25:26 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:25:26 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:25:26 --> Final output sent to browser
DEBUG - 2014-09-01 23:25:26 --> Total execution time: 0.1391
DEBUG - 2014-09-01 23:25:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:25:58 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:25:58 --> URI Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Router Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Output Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Security Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Input Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:25:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Loader Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:25:58 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:25:58 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:25:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:25:58 --> Session Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:25:58 --> Session routines successfully run
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Controller Class Initialized
DEBUG - 2014-09-01 23:25:58 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:25:58 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:25:58 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:25:58 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:25:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:25:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:25:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:25:58 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:25:58 --> Final output sent to browser
DEBUG - 2014-09-01 23:25:58 --> Total execution time: 0.1311
DEBUG - 2014-09-01 23:30:51 --> Config Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:30:51 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:30:51 --> URI Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Router Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Output Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Security Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Input Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:30:51 --> Language Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Language Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Config Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Loader Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:30:51 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:30:51 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:30:51 --> Session Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:30:51 --> Session routines successfully run
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Controller Class Initialized
DEBUG - 2014-09-01 23:30:51 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:30:51 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:30:51 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
ERROR - 2014-09-01 23:30:51 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:30:51 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:30:51 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:30:51 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:30:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:30:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:30:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:30:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:30:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:30:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:30:51 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:30:51 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:30:51 --> Final output sent to browser
DEBUG - 2014-09-01 23:30:51 --> Total execution time: 0.1452
DEBUG - 2014-09-01 23:33:02 --> Config Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:33:02 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:33:02 --> URI Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Router Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Output Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Security Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Input Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:33:02 --> Language Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Language Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Config Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Loader Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:33:02 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:33:02 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:33:02 --> Session Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:33:02 --> Session routines successfully run
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Controller Class Initialized
DEBUG - 2014-09-01 23:33:02 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:33:02 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:33:02 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
ERROR - 2014-09-01 23:33:02 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:33:02 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:33:02 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:33:02 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:33:02 --> Model Class Initialized
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:33:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:33:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:33:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:33:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:33:02 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:33:02 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:33:02 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:33:02 --> Final output sent to browser
DEBUG - 2014-09-01 23:33:02 --> Total execution time: 0.1422
DEBUG - 2014-09-01 23:34:07 --> Config Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:34:07 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:34:07 --> URI Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Router Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Output Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Security Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Input Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:34:07 --> Language Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Language Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Config Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Loader Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:34:07 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:34:07 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:34:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:34:07 --> Session Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:34:07 --> Session routines successfully run
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Controller Class Initialized
DEBUG - 2014-09-01 23:34:07 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:34:07 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:34:07 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
ERROR - 2014-09-01 23:34:07 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:34:07 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:34:07 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:34:07 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:34:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:34:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:34:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:34:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:34:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:34:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:34:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:34:07 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:34:07 --> Final output sent to browser
DEBUG - 2014-09-01 23:34:07 --> Total execution time: 0.1461
DEBUG - 2014-09-01 23:34:53 --> Config Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:34:53 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:34:53 --> URI Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Router Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Output Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Security Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Input Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:34:53 --> Language Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Language Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Config Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Loader Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:34:53 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:34:53 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:34:53 --> Session Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:34:53 --> Session routines successfully run
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Controller Class Initialized
DEBUG - 2014-09-01 23:34:53 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:34:53 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:34:53 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:34:53 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:34:53 --> Model Class Initialized
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:34:53 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:34:53 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:34:53 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:34:53 --> Final output sent to browser
DEBUG - 2014-09-01 23:34:53 --> Total execution time: 0.1499
DEBUG - 2014-09-01 23:35:49 --> Config Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:35:49 --> URI Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Router Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Output Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Security Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Input Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:35:49 --> Language Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Language Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Config Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Loader Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:35:49 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:35:49 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:35:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:35:49 --> Session Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:35:49 --> Session routines successfully run
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Controller Class Initialized
DEBUG - 2014-09-01 23:35:49 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:35:49 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:35:49 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
ERROR - 2014-09-01 23:35:49 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:35:49 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:35:49 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:35:49 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:35:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:35:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:35:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:35:49 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:35:49 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:35:49 --> Final output sent to browser
DEBUG - 2014-09-01 23:35:49 --> Total execution time: 0.1439
DEBUG - 2014-09-01 23:35:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:35:58 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:35:58 --> URI Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Router Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Output Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Security Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Input Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:35:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Loader Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:35:58 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:35:58 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:35:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:35:58 --> Session Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:35:58 --> Session routines successfully run
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Controller Class Initialized
DEBUG - 2014-09-01 23:35:58 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:35:58 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:35:58 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:35:58 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:35:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:35:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:35:59 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:35:59 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:35:59 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:35:59 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:35:59 --> Final output sent to browser
DEBUG - 2014-09-01 23:35:59 --> Total execution time: 0.1486
DEBUG - 2014-09-01 23:36:34 --> Config Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:36:34 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:36:34 --> URI Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Router Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Output Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Security Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Input Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:36:34 --> Language Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Language Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Config Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Loader Class Initialized
DEBUG - 2014-09-01 23:36:34 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:36:34 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:36:35 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:36:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:36:35 --> Session Class Initialized
DEBUG - 2014-09-01 23:36:35 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:36:35 --> Session routines successfully run
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> Controller Class Initialized
DEBUG - 2014-09-01 23:36:35 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:36:35 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:36:35 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
ERROR - 2014-09-01 23:36:35 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:35 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:35 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:35 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:35 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:35 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:36:35 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:36:35 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:36:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:36:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:36:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:36:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:36:35 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:36:35 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:36:35 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:36:35 --> Final output sent to browser
DEBUG - 2014-09-01 23:36:35 --> Total execution time: 0.1501
DEBUG - 2014-09-01 23:36:49 --> Config Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:36:49 --> URI Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Router Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Output Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Security Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Input Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:36:49 --> Language Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Language Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Config Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Loader Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:36:49 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:36:49 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:36:49 --> Session Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:36:49 --> Session routines successfully run
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Controller Class Initialized
DEBUG - 2014-09-01 23:36:49 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:36:49 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:36:49 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
ERROR - 2014-09-01 23:36:49 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:49 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
ERROR - 2014-09-01 23:36:49 --> Severity: Notice  --> Undefined variable: district C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 7
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:36:49 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:36:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:36:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:36:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:36:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:36:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:36:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:36:49 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:36:49 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:36:49 --> Final output sent to browser
DEBUG - 2014-09-01 23:36:49 --> Total execution time: 0.1495
DEBUG - 2014-09-01 23:37:40 --> Config Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:37:40 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:37:40 --> URI Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Router Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Output Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Security Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Input Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:37:40 --> Language Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Language Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Config Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Loader Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:37:40 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:37:40 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:37:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:37:40 --> Session Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:37:40 --> Session routines successfully run
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Controller Class Initialized
DEBUG - 2014-09-01 23:37:40 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:37:40 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:37:40 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:37:40 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:37:40 --> Model Class Initialized
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:37:40 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:37:40 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:37:40 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:37:40 --> Final output sent to browser
DEBUG - 2014-09-01 23:37:40 --> Total execution time: 0.1256
DEBUG - 2014-09-01 23:42:50 --> Config Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:42:50 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:42:50 --> URI Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Router Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Output Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Security Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Input Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:42:50 --> Language Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Language Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Config Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Loader Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:42:50 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:42:50 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:42:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:42:50 --> Session Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:42:50 --> Session routines successfully run
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Controller Class Initialized
DEBUG - 2014-09-01 23:42:50 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:42:50 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:42:50 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:42:50 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:42:50 --> Model Class Initialized
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:42:50 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:42:50 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:42:50 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:42:50 --> Final output sent to browser
DEBUG - 2014-09-01 23:42:50 --> Total execution time: 0.1411
DEBUG - 2014-09-01 23:47:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:47:58 --> URI Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Router Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Output Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Security Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Input Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:47:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Language Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Config Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Loader Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:47:58 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:47:58 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:47:58 --> Session Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:47:58 --> Session routines successfully run
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Controller Class Initialized
DEBUG - 2014-09-01 23:47:58 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:47:58 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:47:58 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:47:58 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:47:58 --> Model Class Initialized
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:47:58 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:47:58 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:47:58 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:47:58 --> Final output sent to browser
DEBUG - 2014-09-01 23:47:58 --> Total execution time: 0.1654
DEBUG - 2014-09-01 23:50:08 --> Config Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:50:08 --> URI Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Router Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Output Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Security Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Input Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:50:08 --> Language Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Language Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Config Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Loader Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:50:08 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:50:08 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:50:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:50:08 --> Session Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:50:08 --> Session routines successfully run
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Controller Class Initialized
DEBUG - 2014-09-01 23:50:08 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:50:08 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:50:08 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:50:08 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:50:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:50:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:50:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:50:08 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:50:08 --> Final output sent to browser
DEBUG - 2014-09-01 23:50:08 --> Total execution time: 0.1315
DEBUG - 2014-09-01 23:50:51 --> Config Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:50:51 --> URI Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Router Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Output Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Security Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Input Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:50:51 --> Language Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Language Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Config Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Loader Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:50:51 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:50:51 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:50:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:50:51 --> Session Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:50:51 --> Session routines successfully run
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Controller Class Initialized
DEBUG - 2014-09-01 23:50:51 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:50:51 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:50:51 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:50:51 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:50:51 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:50:51 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:50:51 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:50:51 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:50:51 --> Final output sent to browser
DEBUG - 2014-09-01 23:50:51 --> Total execution time: 0.1676
DEBUG - 2014-09-01 23:50:55 --> Config Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:50:55 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:50:55 --> URI Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Router Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Output Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Security Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Input Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:50:55 --> Language Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Language Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Config Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Loader Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:50:55 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:50:55 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:50:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:50:55 --> Session Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:50:55 --> Session routines successfully run
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Controller Class Initialized
DEBUG - 2014-09-01 23:50:55 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:50:55 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:50:55 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:50:55 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:50:55 --> Model Class Initialized
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:50:55 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:50:55 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:50:55 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:50:55 --> Final output sent to browser
DEBUG - 2014-09-01 23:50:55 --> Total execution time: 0.1433
DEBUG - 2014-09-01 23:51:06 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:06 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:06 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:06 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:06 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:06 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:06 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:06 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:06 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:06 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:06 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:06 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:06 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:06 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:06 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:06 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:06 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:06 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:07 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:07 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:07 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:07 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:07 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:07 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:07 --> Total execution time: 0.1407
DEBUG - 2014-09-01 23:51:09 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:09 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:09 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:09 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:09 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:09 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:09 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:09 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:09 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:09 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:09 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:09 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:09 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:09 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:09 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:09 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:09 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:10 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:10 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:10 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:10 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:10 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:10 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:10 --> Total execution time: 0.1401
DEBUG - 2014-09-01 23:51:21 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:21 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:21 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:21 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:21 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:21 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:21 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:21 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:21 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:21 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:21 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:21 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:21 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:21 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:21 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:21 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:21 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:21 --> Total execution time: 0.1390
DEBUG - 2014-09-01 23:51:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:24 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:24 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:24 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:24 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:24 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:24 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:24 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:24 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:24 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:24 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:24 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:24 --> Total execution time: 0.1321
DEBUG - 2014-09-01 23:51:27 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:27 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:27 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:27 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:27 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:27 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:27 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:27 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:27 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:27 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:27 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:27 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:27 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:27 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:27 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:27 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:27 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:28 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:28 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:28 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:28 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:28 --> Total execution time: 0.1586
DEBUG - 2014-09-01 23:51:31 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:31 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:31 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:31 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:31 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:31 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:31 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:31 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:31 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:31 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:31 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:31 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:31 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:31 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:31 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:31 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:31 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:31 --> Total execution time: 0.1400
DEBUG - 2014-09-01 23:51:34 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:34 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:34 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:34 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:34 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:34 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:34 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:34 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:34 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:34 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:34 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:34 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:34 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:34 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:34 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:34 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:34 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:34 --> Total execution time: 0.1535
DEBUG - 2014-09-01 23:51:38 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:51:38 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:51:38 --> URI Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Router Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Output Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Security Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Input Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:51:38 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Language Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Config Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Loader Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:51:38 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:51:38 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:51:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:51:38 --> Session Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:51:38 --> Session routines successfully run
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Controller Class Initialized
DEBUG - 2014-09-01 23:51:38 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:51:38 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:51:38 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:51:38 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:51:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:51:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:51:38 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:51:38 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:51:38 --> Final output sent to browser
DEBUG - 2014-09-01 23:51:38 --> Total execution time: 0.1410
DEBUG - 2014-09-01 23:52:01 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:52:01 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:52:01 --> URI Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Router Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Output Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Security Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Input Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:52:01 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Loader Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:52:01 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:52:01 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:52:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:52:01 --> Session Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:52:01 --> Session routines successfully run
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Controller Class Initialized
DEBUG - 2014-09-01 23:52:01 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:52:01 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:52:01 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:52:01 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:52:01 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:52:01 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:52:01 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:52:01 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:52:01 --> Final output sent to browser
DEBUG - 2014-09-01 23:52:01 --> Total execution time: 0.1543
DEBUG - 2014-09-01 23:52:05 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:52:05 --> URI Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Router Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Output Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Security Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Input Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:52:05 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Loader Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:52:05 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:52:05 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:52:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:52:05 --> Session Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:52:05 --> Session routines successfully run
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Controller Class Initialized
DEBUG - 2014-09-01 23:52:05 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:52:05 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:52:05 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:52:05 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:52:05 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:52:05 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:52:05 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:52:05 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:52:05 --> Final output sent to browser
DEBUG - 2014-09-01 23:52:05 --> Total execution time: 0.1560
DEBUG - 2014-09-01 23:52:38 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:52:38 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:52:38 --> URI Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Router Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Output Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Security Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Input Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:52:38 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Loader Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:52:38 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:52:38 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:52:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:52:38 --> Session Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:52:38 --> Session routines successfully run
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Controller Class Initialized
DEBUG - 2014-09-01 23:52:38 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:52:38 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:52:38 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:52:38 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:52:38 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:52:38 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:52:38 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:52:38 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:52:38 --> Final output sent to browser
DEBUG - 2014-09-01 23:52:38 --> Total execution time: 0.1369
DEBUG - 2014-09-01 23:52:41 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:52:41 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:52:41 --> URI Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Router Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Output Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Security Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Input Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:52:41 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Loader Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:52:41 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:52:41 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:52:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:52:41 --> Session Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:52:41 --> Session routines successfully run
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Controller Class Initialized
DEBUG - 2014-09-01 23:52:41 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:52:41 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:52:41 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:52:41 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:52:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:52:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:52:41 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:52:41 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:52:41 --> Final output sent to browser
DEBUG - 2014-09-01 23:52:41 --> Total execution time: 0.1269
DEBUG - 2014-09-01 23:52:44 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:52:44 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:52:44 --> URI Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Router Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Output Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Security Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Input Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:52:44 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Language Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Config Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Loader Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:52:44 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:52:44 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:52:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:52:44 --> Session Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:52:44 --> Session routines successfully run
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Controller Class Initialized
DEBUG - 2014-09-01 23:52:44 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:52:44 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:52:44 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:52:44 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:52:44 --> Model Class Initialized
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:52:44 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:52:44 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:52:44 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:52:44 --> Final output sent to browser
DEBUG - 2014-09-01 23:52:44 --> Total execution time: 0.1454
DEBUG - 2014-09-01 23:54:23 --> Config Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:54:23 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:54:23 --> URI Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Router Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Output Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Security Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Input Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:54:23 --> Language Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Language Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Config Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Loader Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:54:23 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:54:23 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:54:23 --> Session Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:54:23 --> Session routines successfully run
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Controller Class Initialized
DEBUG - 2014-09-01 23:54:23 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:54:23 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:54:23 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:54:23 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:54:23 --> Model Class Initialized
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:54:23 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:54:23 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:54:23 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:54:23 --> Final output sent to browser
DEBUG - 2014-09-01 23:54:23 --> Total execution time: 0.1534
DEBUG - 2014-09-01 23:55:20 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:55:20 --> URI Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Router Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Output Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Security Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Input Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:55:20 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Loader Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:55:20 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:55:20 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:55:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:55:20 --> Session Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:55:20 --> Session routines successfully run
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Controller Class Initialized
DEBUG - 2014-09-01 23:55:20 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:55:20 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:55:20 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:55:20 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:55:20 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:55:20 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:55:20 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:55:20 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:55:20 --> Final output sent to browser
DEBUG - 2014-09-01 23:55:20 --> Total execution time: 0.1588
DEBUG - 2014-09-01 23:55:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:55:24 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:55:24 --> URI Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Router Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Output Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Security Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Input Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:55:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Loader Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:55:24 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:55:24 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:55:24 --> Session Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:55:24 --> Session routines successfully run
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Controller Class Initialized
DEBUG - 2014-09-01 23:55:24 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:55:24 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:55:24 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:55:24 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:55:24 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:55:24 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:55:24 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:55:24 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:55:24 --> Final output sent to browser
DEBUG - 2014-09-01 23:55:24 --> Total execution time: 0.1392
DEBUG - 2014-09-01 23:55:37 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:55:37 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:55:37 --> URI Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Router Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Output Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Security Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Input Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:55:37 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Loader Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:55:37 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:55:37 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:55:37 --> Session Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:55:37 --> Session routines successfully run
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Controller Class Initialized
DEBUG - 2014-09-01 23:55:37 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:55:37 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:55:37 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:55:37 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:55:37 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:55:37 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:55:37 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:55:37 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:55:37 --> Final output sent to browser
DEBUG - 2014-09-01 23:55:37 --> Total execution time: 0.1508
DEBUG - 2014-09-01 23:55:47 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:55:47 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:55:47 --> URI Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Router Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Output Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Security Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Input Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:55:47 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Language Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Config Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Loader Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:55:47 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:55:47 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:55:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:55:47 --> Session Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:55:47 --> Session routines successfully run
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Controller Class Initialized
DEBUG - 2014-09-01 23:55:47 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:55:47 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:55:47 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:55:47 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:55:47 --> Model Class Initialized
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:55:47 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:55:47 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:55:47 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:55:47 --> Final output sent to browser
DEBUG - 2014-09-01 23:55:47 --> Total execution time: 0.2176
DEBUG - 2014-09-01 23:56:33 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:56:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:56:33 --> URI Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Router Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Output Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Security Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Input Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:56:33 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Loader Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:56:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:56:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:56:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:56:33 --> Session Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:56:33 --> Session routines successfully run
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Controller Class Initialized
DEBUG - 2014-09-01 23:56:33 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:56:33 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:56:33 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:56:33 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:56:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:56:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:56:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:56:33 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:56:33 --> Final output sent to browser
DEBUG - 2014-09-01 23:56:33 --> Total execution time: 0.2261
DEBUG - 2014-09-01 23:56:36 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:56:36 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:56:36 --> URI Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Router Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Output Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Security Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Input Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:56:36 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Loader Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:56:36 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:56:36 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:56:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:56:36 --> Session Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:56:36 --> Session routines successfully run
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Controller Class Initialized
DEBUG - 2014-09-01 23:56:36 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:56:36 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:56:36 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:56:36 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:56:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:56:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:56:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:56:36 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:56:36 --> Final output sent to browser
DEBUG - 2014-09-01 23:56:36 --> Total execution time: 0.1344
DEBUG - 2014-09-01 23:56:42 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:56:42 --> URI Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Router Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Output Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Security Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Input Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:56:42 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Loader Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:56:42 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:56:42 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:56:42 --> Session Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:56:42 --> Session routines successfully run
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Controller Class Initialized
DEBUG - 2014-09-01 23:56:42 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:56:42 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:56:42 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:56:42 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:56:42 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:56:42 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:56:42 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:56:42 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:56:42 --> Final output sent to browser
DEBUG - 2014-09-01 23:56:42 --> Total execution time: 0.1523
DEBUG - 2014-09-01 23:56:46 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:56:46 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:56:46 --> URI Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Router Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Output Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Security Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Input Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:56:46 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Language Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Config Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Loader Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:56:46 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:56:46 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:56:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:56:46 --> Session Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:56:46 --> Session routines successfully run
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Controller Class Initialized
DEBUG - 2014-09-01 23:56:46 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:56:46 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:56:46 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:56:46 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:56:46 --> Model Class Initialized
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:56:46 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:56:46 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:56:46 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:56:46 --> Final output sent to browser
DEBUG - 2014-09-01 23:56:46 --> Total execution time: 0.1331
DEBUG - 2014-09-01 23:57:49 --> Config Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:57:49 --> URI Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Router Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Output Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Security Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Input Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:57:49 --> Language Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Language Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Config Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Loader Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:57:49 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:57:49 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:57:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:57:49 --> Session Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:57:49 --> Session routines successfully run
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Controller Class Initialized
DEBUG - 2014-09-01 23:57:49 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:57:49 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:57:49 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
ERROR - 2014-09-01 23:57:49 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 46
ERROR - 2014-09-01 23:57:49 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 46
ERROR - 2014-09-01 23:57:49 --> Severity: Notice  --> Undefined variable: district_id C:\xampp\htdocs\vmv2\application\modules\sales\views\dashboard_advance.php 46
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:57:49 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:57:49 --> Model Class Initialized
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/menu/views/menu.php
ERROR - 2014-09-01 23:57:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:57:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:57:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
ERROR - 2014-09-01 23:57:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\vmv2\application\modules\sales\views\index.php:5) C:\xampp\htdocs\vmv2\system\libraries\Session.php 675
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:57:49 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:57:49 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:57:49 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:57:49 --> Final output sent to browser
DEBUG - 2014-09-01 23:57:49 --> Total execution time: 0.1516
DEBUG - 2014-09-01 23:58:28 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:58:28 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:58:28 --> URI Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Router Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Output Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Security Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Input Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:58:28 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Loader Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:58:28 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:58:28 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:58:28 --> Session Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:58:28 --> Session routines successfully run
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Controller Class Initialized
DEBUG - 2014-09-01 23:58:28 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:58:28 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:58:28 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:58:28 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:58:28 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:58:28 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:58:28 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:58:28 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:58:28 --> Final output sent to browser
DEBUG - 2014-09-01 23:58:28 --> Total execution time: 0.1332
DEBUG - 2014-09-01 23:58:33 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:58:33 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:58:33 --> URI Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Router Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Output Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Security Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Input Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:58:33 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Loader Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:58:33 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:58:33 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:58:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:58:33 --> Session Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:58:33 --> Session routines successfully run
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Controller Class Initialized
DEBUG - 2014-09-01 23:58:33 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:58:33 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:58:33 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:58:33 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:58:33 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:58:33 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:58:33 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:58:33 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:58:33 --> Final output sent to browser
DEBUG - 2014-09-01 23:58:33 --> Total execution time: 0.1399
DEBUG - 2014-09-01 23:58:36 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:58:36 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:58:36 --> URI Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Router Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Output Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Security Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Input Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:58:36 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Loader Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:58:36 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:58:36 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:58:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:58:36 --> Session Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:58:36 --> Session routines successfully run
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Controller Class Initialized
DEBUG - 2014-09-01 23:58:36 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:58:36 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:58:36 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:58:36 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:58:36 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:58:36 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:58:36 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:58:36 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:58:36 --> Final output sent to browser
DEBUG - 2014-09-01 23:58:36 --> Total execution time: 0.1287
DEBUG - 2014-09-01 23:58:41 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:58:41 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:58:41 --> URI Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Router Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Output Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Security Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Input Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:58:41 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Language Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Config Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Loader Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:58:41 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:58:41 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:58:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:58:41 --> Session Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:58:41 --> Session routines successfully run
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Controller Class Initialized
DEBUG - 2014-09-01 23:58:41 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:58:41 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:58:41 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:58:41 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:58:41 --> Model Class Initialized
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:58:41 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:58:41 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:58:41 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:58:41 --> Final output sent to browser
DEBUG - 2014-09-01 23:58:41 --> Total execution time: 0.1462
DEBUG - 2014-09-01 23:59:04 --> Config Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:59:04 --> URI Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Router Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Output Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Security Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Input Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:59:04 --> Language Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Language Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Config Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Loader Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:59:04 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:59:04 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:59:04 --> Session Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:59:04 --> Session routines successfully run
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Controller Class Initialized
DEBUG - 2014-09-01 23:59:04 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:59:04 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:59:04 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:59:04 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:59:04 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:59:04 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:59:04 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:59:04 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:59:04 --> Final output sent to browser
DEBUG - 2014-09-01 23:59:04 --> Total execution time: 0.1312
DEBUG - 2014-09-01 23:59:08 --> Config Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Hooks Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Utf8 Class Initialized
DEBUG - 2014-09-01 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2014-09-01 23:59:08 --> URI Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Router Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Output Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Security Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Input Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-09-01 23:59:08 --> Language Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Language Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Config Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Loader Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Helper loaded: url_helper
DEBUG - 2014-09-01 23:59:08 --> Helper loaded: common_helper
DEBUG - 2014-09-01 23:59:08 --> Database Driver Class Initialized
ERROR - 2014-09-01 23:59:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\vmv2\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-09-01 23:59:08 --> Session Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Helper loaded: string_helper
DEBUG - 2014-09-01 23:59:08 --> Session routines successfully run
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/setting/models/setting_model.php
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/user/models/user_model.php
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/permission/models/permission_model.php
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Controller Class Initialized
DEBUG - 2014-09-01 23:59:08 --> Sales MX_Controller Initialized
DEBUG - 2014-09-01 23:59:08 --> Helper loaded: form_helper
DEBUG - 2014-09-01 23:59:08 --> Form Validation Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/batch/models/batch_model.php
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/sales/models/sales_model.php
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/sales/views/dashboard_advance.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/sales/views/index.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/views/default/includes/header.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/controllers/../modules/menu/controllers/menu.php
DEBUG - 2014-09-01 23:59:08 --> Menu MX_Controller Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/menu/models/menu_model.php
DEBUG - 2014-09-01 23:59:08 --> Model Class Initialized
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/menu/views/menu.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/views/default/includes/notification.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/modules/menu/views/sub_menu.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/views/default/includes/footer.php
DEBUG - 2014-09-01 23:59:08 --> File loaded: application/views/default/index.php
DEBUG - 2014-09-01 23:59:08 --> Language file loaded: language/english/profiler_lang.php
DEBUG - 2014-09-01 23:59:08 --> Helper loaded: text_helper
DEBUG - 2014-09-01 23:59:08 --> Final output sent to browser
DEBUG - 2014-09-01 23:59:08 --> Total execution time: 0.1364
