<?php

class Report_model extends CI_Model{
}

?>