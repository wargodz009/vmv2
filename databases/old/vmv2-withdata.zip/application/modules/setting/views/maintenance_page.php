<br />
<div class="row">
	<div class="container-fluid">
		<div class="form-group">
			<a href="<?=base_url();?>setting/backup" class="btn btn-default">DOWNLOAD DATABASE BACKUP</a>
			<span class="help-block">Save a local copy of the database</span>
		</div>
		<div class="form-group">
			<a href="<?=base_url();?>setting/reset" class="btn btn-danger confirm" rel="are you sure you want to reset the database?">RESET DATABASE</a>
			<span class="help-block">Delete all data on the database.</span>
		</div>
	</div>
</div>