<div class="container-fluid">
	<div class="row">
		<div class="col-md-6"><?php echo modules::run('sales/dashboard'); ?></div>
		<div class="col-md-6"><?php echo modules::run('collection/dashboard'); ?></div>
	</div>
</div>