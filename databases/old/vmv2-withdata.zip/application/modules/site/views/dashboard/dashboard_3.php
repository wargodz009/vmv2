<div class="container-fluid">
	<div class="row">
		<div class="col-md-12"><?php echo modules::run('batch/dashboard'); ?></div>
	</div>
</div>