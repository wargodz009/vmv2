<html>
<head>
</head>
<body>
<table style="margin-top: 75px;width: 750px;">
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td><span style="margin-left:100px;">Sampaguita Hospital</span></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><span style="margin-left:-100px;">Aug 17 2014</span></td>
</tr>
<tr>
	<td><span style="margin-bottom:50px;margin-left:100px;">address line here</span></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td><span style="margin-left:-100px;">so #</span></td>
</tr>
<tr style="height: 25px;">
	<td></td>
	<td colspan=3><span  style="padding-top: 10px;">msr name full name</span></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td style="padding-top: 40px;">name</td>
	<td></td>
	<td>lot #</td>
	<td>date</td>
	<td>quantity</td>
	<td>price</td>
	<td>total</td>
	<td></td>
</tr>
<tr>
	<td>description</td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td>less discount</td>
	<td>(-10%)</td>
	<td>3000</td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
</tr>
<tr>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td></td>
	<td>total</td>
</tr>
</table>
</body>
</html>