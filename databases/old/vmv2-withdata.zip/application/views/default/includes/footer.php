  <div class="container pagination-centered">
  	<hr />
	<p><?=$this->setting_model->get_setting('footer_copyright');?></p>
	</div>

  </body>
</html>